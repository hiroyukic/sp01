﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SwingWeight
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();



            //chart1.ChartArea1.Ax.AxisY.MaximumSize. = 400;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // プロット
            PlotSinCos();
        }

        private void PlotSinCos()
        {
            // 1.Seriesの追加
            chart1.Series.Clear();
            chart1.Series.Add("sin");
            chart1.Series.Add("cos");

            chart1.Series.Add("cos2");

            // 2.グラフのタイプの設定
            chart1.Series["sin"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series["cos"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            chart1.Series["cos2"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            // 3.座標の入力
            //for (double theta = 0.0; theta <= 2 * Math.PI; theta += Math.PI / 360)
            //{
            //    chart1.Series["sin"].Points.AddXY(theta, Math.Sin(theta));
            //    chart1.Series["cos"].Points.AddXY(theta, Math.Cos(theta));

            //                chart1.Series["cos2"].Points.AddXY(theta, Math.Cos(theta*2));
            //           }


            double weight0 = 310;
            double bp0 = 31.2 ;
            double vibrationFreq = 1.38;
            double swingWeight = 0.0;

            // 3.座標の入力
            for (double theta = 28.0; theta <= 35.0; theta += 1.0)
            {
                //chart1.Series["sin"].Points.AddXY(theta, Math.Sin(theta));
                chart1.Series["cos"].Points.AddXY(theta, Math.Cos(theta));
                //chart1.Series["cos2"].Points.AddXY(theta, Math.Cos(theta * 2));

                //swingWeight = getDataSet4SwingWeight(weight0 / 1000, bp0 / 10, vibrationFreq);
                //swingWeight = getDataSet4SwingWeight(weight0 / 1000,  bp0, vibrationFreq);
                swingWeight = getDataSet4SwingWeight(weight0 / 1000,  theta, vibrationFreq);

                //chart1.Series["sin"].Points.AddXY(swingWeight, theta);
                chart1.Series["sin"].Points.AddXY(theta, swingWeight );

                System.Diagnostics.Debug.WriteLine(theta + ", " + swingWeight);


            }




        }



        

    // ------------------------------------------------------------------------
    // <summary>
    //     スイングウエイトの算出関数</summary>
    // <param name="weight">
    //     質量[g]</param>
    // <param name="glength">
    //     バランスポイント[cm]</param>
    // <param name="cycleTime">
    //     振動周期[sec]</param>  
    // ------------------------------------------------------------------------
    private double getDataSet4SwingWeight(Double weight, Double glength , Double  cycleTime )
        {

            //Dim ds As New DataSet
            //Dim dt As New DataTable

        Double Ig1;
        Double Ig2;

            Ig1 = (weight * 980 * glength * System.Math.Pow(cycleTime, 2)) / (4 * System.Math.Pow(3.1415, 2));
            Ig2 = weight * System.Math.Pow(glength, 2);

        //'慣性モーメント　Ig = Ig1 - Ig2
        Double Ig;
            Ig = Ig1 - Ig2;

        //'慣性モーメント（軸まわり）　Io = Ig + Lg^2 * M
            Double Io;

            //'Io = Ig + ((glength - 7.5) ^ 2) * weight
            //'2019.01.14 補正　※Lafino測定値　309.5g/31.2cm/sw:285
            //Io = Ig + ((glength - 10.8) ^ 2) * weight
            Io = Ig + (System.Math.Pow((glength - 10.8), 2)) * weight;
        //System.Diagnostics.Debug.WriteLine(Io)

        return Io ;

    }

    }
}
