﻿using System;
using System.Windows.Forms;
using Tamir.SharpSsh;
using Tamir.SharpSsh.jsch;

namespace Win2LinuxSsh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // button1 を [Enter] ボタンに設定
            this.AcceptButton = this.button1;

            // サーバー名
            comboBox1.Items.Add("IWTUSRA3");
            comboBox1.Items.Add("MYGUSRA3");
            comboBox1.Items.Add("AKTUSRA3");
            comboBox1.Items.Add("");

            //textBox2.Text= "root";
            //textBox3.Text= "metsyspasswd";
            //textBox4.Text= "bin/fjLog.sh";

            // コマンド入力　オートコンプリート設定
            AutoCompleteStringCollection sAutoList = new AutoCompleteStringCollection();
            textBox4.AutoCompleteMode = AutoCompleteMode.Suggest;
            textBox4.AutoCompleteSource = AutoCompleteSource.CustomSource;
            textBox4.AutoCompleteCustomSource = sAutoList;
            sAutoList.Add("ls bin");
            sAutoList.Add("ls -lt /tmp/tomcat*.log");
            sAutoList.Add("cat /usr/tomcat8f/logs/catalina.out");
            sAutoList.Add("cat /usr/tomcat8m/logs/catalina.out");
            sAutoList.Add("cat /usr/tomcat8f/logs/fileJuju_log4j.log");
            sAutoList.Add("cat /usr/tomcat8m/logs/masterMainte_log4j.log");
            sAutoList.Add("ls /usr/tomcat8f/logs");
            sAutoList.Add("ls /usr/tomcat8m/logs");
            sAutoList.Add("bin/fjLog.sh");
            sAutoList.Add("bin/fjCatLog.sh");
            sAutoList.Add("bin/mmLog.sh");
            sAutoList.Add("bin/mmCatLog.sh");
            sAutoList.Add("bin/fjStart.sh");
            sAutoList.Add("bin/fjStop.sh");
            sAutoList.Add("bin/mmStart.sh");
            sAutoList.Add("bin/mmStop.sh");
        }

        private void button1_Click(object sender, System.EventArgs e)
        {

            textBox1.Text ="" ;

            String server;
            try
            {
                server = comboBox1.SelectedItem.ToString() ;
            } catch (Exception ) {
                server = "";
            }
            String user = textBox2.Text;
            String pass = textBox3.Text;
            String command = textBox4.Text;

            //入力チェック
            String message = "";
            if(server.Length == 0)
            {
                message = ">サーバーが指定されていません。";
            } else if(user.Length == 0) {
                message = ">ユーザーが指定されていません。";
            } else if(pass.Length == 0) {
                message = ">パスワードが指定されていません。";
            } else if(command.Length == 0) {
                message = ">コマンドが指定されていません。";
            }

            if(message.Length > 0)
            {
                textBox1.Text = message;
                return;
            }

            //カーソル変更
            this.Cursor = Cursors.WaitCursor;

            //リモート実行
            String result = executeCommand(server, user, pass, command, 22);

            //まずはバイト配列に変換する
            //byte[] bytesUTF8 = System.Text.Encoding.Default.GetBytes(result);
            //バイト配列をUTF8の文字コードとしてStringに変換する
            //string stringSJIS = System.Text.Encoding.UTF8.GetString(bytesUTF8);
            //textBox1.Text = stringSJIS;

            //result.Replace("\n", "\r\n").Replace("\r\r", "\r");
            //result=ConvertEncoding(result, dest);

            //実行結果表示
            //※改行コードで分割し、１行づつテキストボックスに追加　※テキストボックス内で改行コードが機能しないため
            string[] lines = result.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                textBox1.Text += lines[i] + "\r\n";
            }

            //カーソル戻す
            this.Cursor = Cursors.Arrow;
        }


        private string executeCommand(string serverHost, string userName, string pass, string command, int tcpPort)
        {
            SshExec ssh = new SshExec(serverHost, userName, pass);
            string result = null;

            try
            {
                ssh.Connect(tcpPort);
                result = ssh.RunCommand(command);
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }
            finally
            {
                if (null != ssh)
                {
                    ssh.Close();
                }
            }
            return result;
        }


    public static string ConvertEncoding(string src, System.Text.Encoding destEnc)
    {
            //byte[] src_temp = System.Text.Encoding.ASCII.GetBytes(src);
            byte[] src_temp = System.Text.Encoding.UTF8.GetBytes(src);


            string str;

            //Shift JISとして文字列に変換
            str = System.Text.Encoding.GetEncoding(932).GetString(src_temp);
        byte[] dest_temp = System.Text.Encoding.Convert(System.Text.Encoding.ASCII, destEnc, src_temp);
        string ret = destEnc.GetString(dest_temp);

            //JISとして変換
            str = System.Text.Encoding.GetEncoding(50220).GetString(src_temp);
        dest_temp = System.Text.Encoding.Convert(System.Text.Encoding.ASCII, destEnc, src_temp);
        ret = destEnc.GetString(dest_temp);

            //EUCとして変換
            //str = System.Text.Encoding.GetEncoding(51932).GetString(src_temp);
            str = System.Text.Encoding.GetEncoding("EUC-JP").GetString(src_temp);
        dest_temp = System.Text.Encoding.Convert(System.Text.Encoding.ASCII, destEnc, src_temp);
        ret = destEnc.GetString(dest_temp);

            //UTF-8として変換
            str = System.Text.Encoding.UTF8.GetString(src_temp);
        dest_temp = System.Text.Encoding.Convert(System.Text.Encoding.ASCII, destEnc, src_temp);
        ret = destEnc.GetString(dest_temp);

            // EUC-JPのテキストエンコーディング処理オブジェクト
            //var eucJpEnc = Encoding.GetEncoding("EUC-JP");
            // バイト列をテキストにデコード
            //var decodedText = eucJpEnc.GetString(eucJpBin);

            // UTF-8 -> Shift-JIS 変換（byte形）
            System.Text.Encoding utf8Enc = System.Text.Encoding.GetEncoding("EUC-JP");
            string utf8str = utf8Enc.GetString(src_temp );
            byte[] bytesData = System.Text.Encoding.GetEncoding("Shift_JIS").GetBytes(utf8str);
            ret = destEnc.GetString(bytesData);

            //byte[] dest_temp = System.Text.Encoding.Convert(System.Text.Encoding.ASCII, destEnc, src_temp);
            //string ret = destEnc.GetString(dest_temp);
            return ret;
    }

    }

}

