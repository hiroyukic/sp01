
var MyComponent = React.createClass({
	displayName: 'my compo',
	render: function() {
		return ( React.createElement('p', {}, 'JSXを使わないサンプル'));
	}
});

ReactDOM.render(
	React.createElement(MyComponent, {}, null),
	document.getElementById('msg')
);


