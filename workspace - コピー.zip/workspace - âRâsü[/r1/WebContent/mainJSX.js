
var MyComponent = React.createClass({
	displayName: 'my component',
	render: function() {
		return ( <p> React のサンプル</p>);
	}
});

ReactDOM.render(
	<MyComponent/>,
	document.getElementById('msg')
);



