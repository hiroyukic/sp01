var MyComponent = React.createClass({
	displayName: 'my component',
	hanleOnClick:function(event) {
		alert('クリック！');
	},
	render: function() {
		return(<input type="button" value="click" onClick={this.handleOnClick} />);
	}
});


ReactDOM.render(
	<MyComponent msg="ボタンをクリックして下さい。"/>,
	document.getElementById('msg')

);




