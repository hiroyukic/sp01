var MyComponent = React.createClass({
	displayName: 'my component',
	render: function() {
		return ( <h2> React のサンプル</h2>);
	}
});

ReactDOM.render(
	<MyComponent/>,
	document.getElementById('msg')

);




