﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Drawing.Printing;
using System.Windows.Forms;
using System.Drawing;


namespace SwingWeight
{
    class Print
    {
        #region プリンターの初期設定
        protected void initializePrinterSettings(System.Drawing.Printing.PrintDocument PrintDocument1)
        {
            //プリンタ名の取得
            string defaultPrinterName = PrintDocument1.PrinterSettings.PrinterName;
            PrintDocument1.DefaultPageSettings.PrinterSettings.PrinterName = defaultPrinterName;
            int paperIndex = 0;
            foreach (PaperSize ps in PrintDocument1.PrinterSettings.PaperSizes)
            {
                if (ps.PaperName.Contains("A4"))//用紙のサイズ指定
                {
                    break;
                }
                paperIndex++;
            }
            PrintDocument1.DefaultPageSettings.PaperSize =
                PrintDocument1.PrinterSettings.PaperSizes[paperIndex];
            PrintDocument1.DefaultPageSettings.Landscape = true;          //横向きならtrue
            //PrintDocument1.DefaultPageSettings.Color = true;              //カラー印刷ならtrue
            PrintDocument1.DefaultPageSettings.Color = false;
        }
        #endregion

        #region 印刷イベントハンドラ　 印刷時の縮小倍率の決定
        public void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //拡大率を指定．
            float zoom = 1;
            float padding = 30;
            if (this.memoryImage.Width > e.Graphics.VisibleClipBounds.Width)
            {
                zoom = e.Graphics.VisibleClipBounds.Width /
                    this.memoryImage.Width;
            }
            if ((this.memoryImage.Height + padding) * zoom > e.Graphics.VisibleClipBounds.Height)
            {
                zoom = e.Graphics.VisibleClipBounds.Height / (this.memoryImage.Height + padding);
            }
            //new Font("MS UI Gothic", 8), Brushes.Black, new Point(0, 0));
            //e.Graphics.DrawString("Swing Weight Calculator  " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), new Font("メイリオ", 8), Brushes.Black, new Point(0, 0));
            //e.Graphics.DrawString("Swing Weight Calculator  [" + this.title  + "]    " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), new Font("メイリオ", 8), Brushes.Black, new Point(0, 0));

            //印刷タイトル
            String timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
          　//e.Graphics.DrawString(timestamp + " Swing Weight Calculator  [" + this.title + "]" , new Font("メイリオ", 8), Brushes.Black, new Point(0, 0));
            e.Graphics.DrawString( " Swing Weight Calculator  " + timestamp  + "   [ " + this.title + " ]" , new Font("メイリオ", 8), Brushes.Black, new Point(0, 0));
                
            // フォントサイズは適当な値を指定して下さい。
            //EventArgsのGraphicsにデータを書き込むとそれが印刷される．
            e.Graphics.DrawImage(this.memoryImage, 0, padding,
                                                   this.memoryImage.Width * zoom,
                                                   this.memoryImage.Height * zoom);
        }
        #endregion

        #region 印刷処理
        //フォームのイメージを保存する変数
        public Bitmap memoryImage;
        /// 

        /// フォームのイメージを印刷する
        /// 

        /// イメージを印刷するフォーム
        public void PrintForm(Form frm)
        {
            //フォームのイメージを取得する
            memoryImage = CaptureControl(frm);
            //フォームのイメージを印刷する
            System.Drawing.Printing.PrintDocument PrintDocument1 = new System.Drawing.Printing.PrintDocument();
            initializePrinterSettings(PrintDocument1);
            PrintDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler( printDocument1_PrintPage);
            //PrintPreviewDialogオブジェクトの作成
            PrintPreviewDialog printPreviewDialog1 = new PrintPreviewDialog();
            printPreviewDialog1.Document = PrintDocument1;
            // 表示倍率を2倍にする
            printPreviewDialog1.PrintPreviewControl.Zoom = 1.1;
            //ダイアログの表示サイズを指定
            printPreviewDialog1.ClientSize = new System.Drawing.Size(900, 600);
            printPreviewDialog1.Location = new System.Drawing.Point(30, 30);
            //表示
            printPreviewDialog1.ShowDialog();
            //直接印刷
            //PrintDocument1.Print();
            //後処理
            memoryImage.Dispose();
        }
        #endregion

        #region コントロールのイメージを取得する
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern bool BitBlt(IntPtr hdcDest,
             int nXDest, int nYDest, int nWidth, int nHeight,
             IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);

        public const int SRCCOPY = 0xCC0020;
        public Bitmap CaptureControl(Control ctrl)
        {
            Graphics g = ctrl.CreateGraphics();
            Bitmap img = new Bitmap(ctrl.ClientRectangle.Width, ctrl.ClientRectangle.Height, g);
            Graphics memg = Graphics.FromImage(img);
            IntPtr dc1 = g.GetHdc();
            IntPtr dc2 = memg.GetHdc();
            BitBlt(dc2, 0, 0, img.Width, img.Height, dc1, 0, 0, SRCCOPY);
            g.ReleaseHdc(dc1);
            memg.ReleaseHdc(dc2);
            memg.Dispose();
            g.Dispose();
            return img;
        }
        #endregion

        #region PrintDocument1のPrintPageイベントハンドラ
        public void PrintDocument1_PrintPage(object sender,
             System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }
        #endregion

        #region 印刷タイトル
        String title;
        public void setTitle(String title)
        {
            this.title = title;
        }
        #endregion


    }
}
