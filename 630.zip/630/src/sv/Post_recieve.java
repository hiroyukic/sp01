package sv;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;

@SuppressWarnings("serial")
@WebServlet(name = "download", urlPatterns = { "/download" })

public class Post_recieve extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		// PrintWriter out = response.getWriter();

		String tmp;

		String name = "";
		tmp = request.getParameter("name");
		if (tmp == null || tmp.length() == 0) {
			name = "未設定です";
		} else {
			name = tmp;
		}

		String text;
		tmp = request.getParameter("text");
		if (tmp == null || tmp.length() == 0) {
			text = "未設定です";
		} else {
			text = tmp;
		}

		String jaCode;
		tmp = request.getParameter("jacode");
		if (tmp == null || tmp.length() == 0) {
			jaCode = "未設定です";
		} else {
			jaCode = tmp;
		}

		String tempoCode;
		tmp = request.getParameter("tenpoCode");
		if (tmp == null || tmp.length() == 0) {
			tempoCode = "未設定です";
		} else {
			tempoCode = tmp;
		}

		String cyohyoCode;
		tmp = request.getParameter("cyohyocode");
		if (tmp == null || tmp.length() == 0) {
			cyohyoCode = "未設定です";
		} else {
			cyohyoCode = tmp;
		}

		String kijyunDate;
		tmp = request.getParameter("kijyunDate");
		if (tmp == null || tmp.length() == 0) {
			kijyunDate = "未設定です";
		} else {
			kijyunDate = tmp;
		}

		///////////////////////
		//download(response);
		download(response, jaCode, tempoCode, cyohyoCode, kijyunDate) ;

		///////////////////////
		//RequestDispatcher dispatcher = request.getRequestDispatcher("/sv.Table.jsp");
		//RequestDispatcher dispatcher = request.getRequestDispatcher("/sv.Table.jsp");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/ajax/g102.jsp");
		dispatcher.forward(request, response);

	}

	private void download(HttpServletResponse response, String jaCode, String tempoCode, String cyohyoCode, String kijyunDate) throws IOException {

		ServletOutputStream op = null;
		DataInputStream in = null;
		// String fileName = "KGSDA160.cab";
		// String filePath = "D:/tmp/" + fileName;

		//String fileName = "KGSDA228.20150223.cab";
		//String filePath = "D:/FILEROOT/HTTP/3003001/KGSDA228/KGSDA228.20150223.cab";

		String fileName = cyohyoCode + kijyunDate + ".cab";
		String filePath = "D:/FILEROOT/HTTP/" + jaCode + tempoCode + "/" + cyohyoCode + "/" + cyohyoCode +  "." +    kijyunDate  + ".cab";

		try {
			java.io.File file = new File(filePath);
			if (file.exists()) {
				// レスポンスヘッダーの作成
				response.setContentType("application/octet-stream");
				response.setContentLength((int) file.length());
				// ファイル名の設定ISO_8859_1にエンコード
				response.setHeader("Content-Disposition",
						"inline; filename=\"" + new String(fileName.getBytes("UTF-8"), "ISO_8859_1") + "\"");
				// ファイルの読み込み
				int bytes = 0;
				op = response.getOutputStream();
				byte[] bbuf = new byte[1024];
				in = new DataInputStream(new FileInputStream(file));
				while ((in != null) && ((bytes = in.read(bbuf)) != -1)) {
					op.write(bbuf, 0, bytes);
				}
				op.flush();
				//
				IOUtils.closeQuietly(op);
				IOUtils.closeQuietly(in);
			} else {
				System.out.println("[PostReceieve] File not found. file=" + filePath);

			}
		} catch (Exception e) {
			e.printStackTrace();
			//org.apache.catalina.connector.ClientAbortException: java.io.IOException: 確立された接続がホスト コンピューターのソウトウェアによって中止されました。

		} finally {
			//IOUtils.closeQuietly(op);
			//IOUtils.closeQuietly(in);
		}
	}

}
