﻿package pjt.fw;

/**
 * テーブル管理ビーン<BR><BR>
 * RDB上のテーブルをオブジェクトしてメモリー上にキャッシュするインコア・テーブル機能を提供し
 *ます。テーブル管理ビーンは、最初に呼び出された時点からstaticクラスとしてJVMに常駐します。
 *<BR><BR>
 * 管理対象は環境設定ファイル（"tablemgr.properties"）に登録します。<BR><BR>
 *　[tablemgr.propertiesの形式]<BR>
 *　objectName=propertiesファイルの名前<BR>
 * objectName　　　　　　　　:　管理対象を識別する任意の名前<BR>
 * propertiesファイルの名前　:　テーブルの作成方法を指定する（テーブル情報プロパティ)<BR>
 * ファイル名およびファイル形式は、java.util.PropertyResourceBundleクラスの実装に準じます。
 *<BR><BR>
 *　[テーブル情報プロパティの形式]<BR>
 *　Type=SINGLE | MULTI<BR>
 *　Sql=キーと値を取得するSQL文<BR>
 * Type　　： "SINGLE"はキーと値が１対１に対応するテーブルの場合に指定します。<BR>
 * 　　　　： "MULTI"は１つのキーが１つ以上の値を持つテーブルの場合に指定します。<BR>
 * Sql 　　：　キーと値を取得するSQL文を指定します。結果セットの第１列がキー、第２列が値とし<BR>
 * 　　　　　　て扱われます。<BR>
 *<BR>
 * pjt.fwパッケージでは、以下のオブジェクトを使用しています。<BR>
 * <LI>acclevelオブジェクト</LI><BR>
 *　セッション管理機能で使用 ページのアクセスレベル情報(SINGLE)<BR>
 * <LI>directオブジェクト</LI><BR>
 *　セッション管理機能で使用 ページが直接URI指定呼び出された時のアクセスの可否を管理(SINGLE)<BR>
 * <LI>linkオブジェクト</LI><BR>
 *　セッション管理機能で使用 ページ間のリンクの妥当性情報(MULTI)<BR>
 * <LI>nocacheオブジェクト</LI><BR>
 *　セッション管理機能で使用 出力ページのキャッシュ属性情報(SINGLE)<BR>
 * <LI>sesscntlオブジェクト</LI><BR>
 *　セッション管理機能で使用 セッション・オブシェクトの作成可否を管理(SINGLE)<BR>
 * <LI>erruriオブジェクト</LI><BR>
 *　汎用エラーハンドラで使用 ユーザーエラー発生時の表示ページ情報を管理(SINGLE)<BR>
 * <LI>msglinkオブジェクト</LI><BR>
 *　汎用エラーハンドラで使用 ユーザーエラー発生時のエラー表示後のリンク先情報を管理(SINGLE)<BR>
 * <LI>usermsgオブジェクト</LI><BR>
 *　エラー表示で使用　　　　 メッセージ番号とメッセージ・テキストを管理(SINGLE)<BR>
 *<BR>
 * 上記以外に任意のオブジェクトを追加することが可能です。テーブル管理機能は初期のロード以外に
 *はDBアクセスを行わないためレスポンスの向上に寄与しますが、一度作成されたオブジェクトは常駐
 *するため大量のデータを保持した場合はメモリー使用量に大きな影響を与えることに注意してください
 *。<BR>
 *
 * @author IBM Japan, Ltd. System Solution Center No.1 Systems Engineering
 * @version 1.0
 *
 */

public interface TableMgr {

/**
 * 指定されたオブジェクトに指定されたキーが存在するかどうかをテストします。
 * @return boolean キーが存在する場合=true,存在しない場合=false
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @exception java.lang.SystemErrorException 例外記述:指定されたオブジェクトが存在しない場合にthrow
 */
boolean containsKey(java.lang.String objName, java.lang.String key) throws SystemErrorException;
/**
 * 指定されたオブジェクトに指定されたキーの値が存在するかテストします。
 * @return boolean 値が存在する場合=true,存在しない場合=false
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @param val java.lang.String 値
 * @exception java.lang.SystemErrorException 例外記述：指定されたオブジェクトが存在しない場合にthrow
 */
boolean containsVal(java.lang.String objName, java.lang.String key, java.lang.String val)
	throws SystemErrorException;
/**
 * 指定されたオブジェクトに指定されたキーの値を取得します。<BR>
 * 指定されたキーが存在しない場合は、nullを戻します。<BR>
 * SINGLEタイプの専用のメソッドです。MULTIタイプの場合は、getValuesメソッドを使用して下さい。<BR>
 * @return java.lang.String 指定されたキーの値
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @exception java.lang.SystemErrorException 例外記述：指定されたオブジェクトが存在しない場合にthrow
 */
String getValue(String objName, String key) throws SystemErrorException;
/**
 * 指定されたオブジェクトに指定されたキーの値を取得します。<BR>
 * 指定されたキーが存在しない場合は、nullを戻します。<BR>
 * MULTIタイプの専用のメソッドです。SINGLEタイプの場合は、getValueメソッドを使用して下さい。<BR>
 * @return java.util.Vector 指定されたキーの値のVectorオブジェクト
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @exception java.lang.SystemErrorException 例外記述：指定されたオブジェクトが存在しない場合にthrow
 */
java.util.Vector getValues(java.lang.String objName, java.lang.String key) throws SystemErrorException;
}
