﻿/*
 * 日付関連汎用ユーティリティ
 *
 * 修正履歴
 * V010.0	2012/05/30	T.itoh		元号変更対応準備のため日付関連モジュールをまとめます。
 *
 */

package fw;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * 日付関連汎用ユーティリティ
 * @varsion 10.00
 * @auther T.Itoh
 */
public class UtilDate {

	/**
	 * UtilDate コンストラクター・コメント。
	 */
	public UtilDate() {
		super();
	}


	/* **********************************************************************************
	 *
	 * 日付チェック関連モジュール
	 *
	 * *********************************************************************************/

	/**
	 * 日付の妥当性チェックを行います。
	 * 妥当:'true'、非妥当：'false'
	 *
	 * @param yy int 西暦年
	 * @param mm int 月
	 * @param dd int 日
	 * <br>
	 * 作成日 : (2003/01/16 16:32:54)
	 * Calendarクラスが勝手に正しい日付に変換することを利用します。
	 * 2010/02/30→2010/03/02
	 *
	 */
	public static boolean CheckDate(int yy,int mm,int dd) {
		//実在日への変換
		Calendar cl = new GregorianCalendar(yy,mm,dd);
		//実在日チェック
		if (cl.get(Calendar.YEAR) != yy
			| cl.get(Calendar.MONTH) != mm
			| cl.get(Calendar.DATE) != dd) {
			return false;
		} else {
			return true;
		}

	}

	/*　** 使い方サンプル　メイン ***
	public static void main(String args[]) {
		int yy = Integer.parseInt(args[0]);
		int mm = Integer.parseInt(args[1]) - 1;
		int dd = Integer.parseInt(args[2]);

		if (CheckDate(yy,mm,dd) == false){
			System.out.println("妥当でない日付です。");

			//想定日の出力
			Calendar cl = new GregorianCalendar(yy,mm,dd);
			int data = cl.get(Calendar.MONTH) + 1;
			System.out.println("ほんとは："
							+ cl.get(Calendar.YEAR)+"年"
							+ data + "月"
							+ cl.get(Calendar.DATE) + "日");
		} else {
			System.out.println("妥当な日付です。");
		}
	}
	*/

	/**
	 * 日付（日付の形式も含め）の妥当性チェックを行います。
	 * 妥当:'true'、非妥当：'false'
	 *
	 * @param date8 String 西暦年月日(yyyyMMdd)
	 *<br>
	 * 作成日 : (2003/01/16 16:32:54)
	 */
	public static boolean isValidDate(String sDate) {

		if(sDate == null) return false;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setLenient(false);

		try{
			Date date = sdf.parse(sDate);
			return true;
		}catch (ParseException e){
			return false;
		}


	}

	/**
	 * d0(yyyymmdd) よりも d1(yyyymmdd) が未来日付であれば "true"
	 * ※d0 = d1 の場合、"false" (同一日付は、未来日付とはみなさない。）
	 *
	 * @return boolean
	 * @param d0 String 'YYYYMMDD'
	 * @param d1 String 'YYYYMMDD'
	 *
	 * 作成日 : (2003/09/09 12:22:05)
	 */
	public static  boolean isFuturerDate(String d0, String d1) throws UserErrorException {

		if (d0.length() != 8 || d1.length() != 8) {
			FjLog.L0.writeLog(
				"CLASS=pjt.fw.Util.withInYear, 日付ﾃﾞｰﾀが８桁でありません.");
			return false;
		}

		// ﾊﾟﾗﾒｰﾀの真偽性ﾁｪｯｸ
		if(isValidDate(d0)==false) return false;
		if(isValidDate(d1)==false) return false;

		// 同一日付は、未来日付とみなす(true)
		//if(d0.equals(d1)) return true;

		/*
		 * d0
		 */
		Date date_0 = null;
		Calendar tempdate = Calendar.getInstance();
		SimpleDateFormat sdf = (SimpleDateFormat) DateFormat.getDateInstance();
		sdf.applyPattern("yyyyMMdd");
		try {
			date_0 = sdf.parse(d0); //振替日
		} catch (ParseException e) {
			throw new IllegalArgumentException();
		}

		/*
		 * d1
		 */
		Date date_1 = null;
		try {
			date_1 = sdf.parse(d1);
		} catch (ParseException e) {
			throw new IllegalArgumentException();
		}

		/*
		 * "d1"が"d0"の未来日付である場合には　true を返す。
		 */
		if (date_1.after(date_0)) {
			return true;     //未来日付である。
		} else {
			return false;
		}
	}

	/**
	 * 第１パラメータで渡された日付（振替日）の１年前の日付よりも
	 * 第２パラメータで渡された日付（起算日）が
	 * 後の日付であった場合に'true'を返す。それ以外は、全て'false'を返す。
	 *
	 * ※　d0:振替日、d1:起算日
	 *
	 * @return boolean
	 * @param d0 String 'YYYYMMDD'
	 * @param d1 String 'YYYYMMDD'
	 *
	 * 作成日 : (2003/09/03 16:22:05)
	 */
	public static  boolean isLessThanOneYear(String d0, String d1) throws UserErrorException {

		if (d0.length() != 8 || d1.length() != 8) {
			FjLog.L0.writeLog(
				"CLASS=pjt.fw.Util.withInYear, 日付ﾃﾞｰﾀが８桁でありません.");
			return false;
		}

		// ﾊﾟﾗﾒｰﾀの真偽性ﾁｪｯｸ
		if(isValidDate(d0)==false) return false;
		if(isValidDate(d1)==false) return false;

		/*
		 * 振替日(d0)の1年前のCalendarを算出する
		 */
		Date date_0 = null;
		Calendar tempdate = Calendar.getInstance();
		SimpleDateFormat sdf = (SimpleDateFormat) DateFormat.getDateInstance();
		sdf.applyPattern("yyyyMMdd");
		try {
			date_0 = sdf.parse(d0); //振替日
		} catch (ParseException e) {
			throw new IllegalArgumentException();
		}
		Calendar calendar_0 = Calendar.getInstance();
		calendar_0.setTime(date_0);
		calendar_0.roll(Calendar.YEAR, -1);

		/*
		 * 起算日(d1)のCalendarを算出する
		 */
		Date date_1 = null;
		try {
			date_1 = sdf.parse(d1); //起算日
		} catch (ParseException e) {
			throw new IllegalArgumentException();
		}
		Calendar calendar_1 = Calendar.getInstance();
		calendar_1.setTime(date_1);

		/*
		 * calendar_1（起算日） の時刻が、calendar_0（振替日の１年前の日付）　
		 * よりも後である場合には　true を返す。
		 */
		if (calendar_1.after(calendar_0)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * この日付が現在日付より後にあるかどうかを判定します。<br>
	 * 引数 Dateが"00000000","999999999","ｽﾍﾟｰｽ"の場合は true<br>
	 * 現在日付よりも引数 Date が未来（大きい）場合は true<br>
	 * 現在日付よりも引数 Date が過去（小さい）場合もしくは等しい場合は false
	 *
	 * @param date8 String "YYYYMMDD"形式の日付
	 *<br>
	 * 作成日 : (2004/03/05 13:55:34)
	 *
	 */
	public static boolean chkDateAfter(String date8) {

		if (date8.equals("00000000")) return true;
		if (date8.equals("99999999")) return true;
		if (date8.trim().length() == 0) return true;

		Date tempdate = new Date();
		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyyMMdd");
		ParsePosition pos = new ParsePosition(0);
		Date rtdate = sdf.parse(date8,pos);

		return rtdate.after(tempdate) ;

	}

	/**
	 * 入力日付が現在日付より後にあるかどうかを判定します。<br>
	 * 現在日付よりも入力日付が遅い場合、もしくは、等しい場合だけ true、
	 * そうでない場合は false
	 *
	 * @param date8 String (yyyymmdd)
	 *
	 * 作成日 : (2002/12/20 13:55:34)c
	 *
	 */
	public static boolean dateAfter(String date8) {

		if(isValidDate(date8)==false) return false;

		Date tempdate = new Date();

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyyMMdd");
		ParsePosition pos = new ParsePosition(0);

		Date rtdate = sdf.parse(date8,pos);

		String t = dateToDate8(tempdate);
		if(date8.equals(t)) {
			return true;
		}else{
			return rtdate.after(tempdate) ;
		}

	}

	/**
	 * 入力日付と現在日付を比較します。<br>
	 * 入力日付が現在日付と等しい場合は値 0。
	 * 入力日付が現在日付より前の場合は 0 より小さい値。
	 * 入力日付が現在日付より後の場合は 0 より大きい値。
	 *
	 * @param date8 String (yyyymmdd)
	 *
	 * 作成日 : (2002/12/20 13:55:34)c
	 *
	 */
	public static int dateCompareTo(String date8) {
		Date tempdate = new Date();

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyyMMdd");
		ParsePosition pos = new ParsePosition(0);

		Date rtdate = sdf.parse(date8,pos);

		return rtdate.compareTo(tempdate) ;

	}

	/**
	 * 日付の比較を行います。<br>
	 * 日付１＜日付２：－１、
	 * 日付１＝日付２：０、
	 * 日付１＞日付２：１
	 *
	 * @param datestr1 String (yyyymmdd)
	 * @param datestr2 String (yyyymmdd)
	 *
	 *  datestr1 < datestr2   -1"
	 *  datestr1 = datestr2   0
	 *  datestr1 > datestr2   1
	 *<br>
	 * 作成日 : (2003/03/10 13:55:34)
	 *
	 */
	public static int dateCompareTo(String datestr1, String datestr2) {

		/*
		 * date1
		 */
		SimpleDateFormat sdf1 = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf1.applyPattern("yyyyMMdd");
		ParsePosition pos1 = new ParsePosition(0);
		Date date1 = sdf1.parse(datestr1,pos1);

		/*
		 * date2
		 */
		SimpleDateFormat sdf2 = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf2.applyPattern("yyyyMMdd");
		ParsePosition pos2 = new ParsePosition(0);
		Date date2 = sdf2.parse(datestr2,pos2);

		return date1.compareTo(date2) ;
	}


	/* **********************************************************************************
	 *
	 * 日付操作関連モジュール
	 *
	 * *********************************************************************************/

	/**
	 * ８桁の西暦日付の加算を行います。<br>
	 * ﾊﾟﾗﾒｰﾀYMD にて年、月、日の加算を区別します。
	 * ex.
	 *  String ans = dateAdd("DATE","20030228",1)
	 *  この時、ans = "20030301" となる。
	 * ﾊﾟﾗﾒｰﾀ異常、Exception発生時には、Null を返します。
	 *
	 * @param YMD String   "YEAR", "MONTH", "DATE"
	 * @param date8 String (yyyymmdd)
	 * @return String "yyyymmdd"
	 *
	 * 作成日 : (2002/03/05 17:08:13)
	 *
	 */
	public static String dateAdd(String YMD, String date8, int delta) {

		try {
			Date date = date8ToDate(date8);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);

			/*
			 * 日付の加算
			 */
			if (YMD.equals("DATE")) {
				cal.add(Calendar.DATE, delta);
			} else
				if (YMD.equals("MONTH")) {
					cal.add(Calendar.MONTH, delta);
			} else
				if (YMD.equals("YEAR")) {
					cal.add(Calendar.YEAR, delta);
			} else {
				 return null;
			}


			/*
			 * return 処理
			 */
			Date date_return = cal.getTime();
			String date8_return = dateToDate8(date_return);

			/*
			 * 日付妥当ﾁｪｯｸ
			 */
			if (isValidDate(date8_return)) {
				return date8_return;
			} else {
				return null;
			}

		} catch (Exception e) {
			return null;
		}

	}

	/**
	 * 日付を進めます。(String型)
	 *
	 * @param day String 入力日付
	 * @param delta int 進める日数
	 * @return String 出力日付　
	 * <br>
	 * 作成日 : (2003/04/09 19:43:13)
	 *
	 */
	public static String getDay(String day,int delta) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date date = null;
		try{
			date = sdf.parse(day);
		} catch (ParseException e) {
			throw new IllegalArgumentException();
		}
		return sdf.format(getDay(date,delta));

	}

	/**
	 * 日付を進めます。(Date型)
	 *
	 * @param day Date 入力日付
	 * @param delta int 進める日数
	 * @return Date 出力日付　
	 * <br>
	 * 作成日 : (2003/04/09 19:43:13)
	 *
	 */
	public static Date getDay(Date day,int delta) {

		Calendar cal = Calendar.getInstance();
		cal.setTime(day);
		cal.add(Calendar.DATE,delta);
		return cal.getTime();

	}

	/**
	 * 日付を１日進めます。(String型)
	 *
	 * @param day String 入力日付
	 * @param delta int 進める日数
	 * @return String 出力日付　
	 * 日付を進めます。(Date型)
	 * <br>
	 * 作成日 : (2003/04/09 19:43:13)
	 *
	 */
	public static String getNextDay(String day) {

		return getDay(day,1);

	}

	/**
	 * 日付１日を進めます。(Date型)
	 *
	 * @param day Date 入力日付
	 * @param delta int 進める日数
	 * @return Date 出力日付　
	 * <br>
	 * 作成日 : (2003/04/09 19:43:13)
	 *
	 */
	public static Date getNextDay(Date day) {

		return getDay(day,1);

	}

	/**
	 * 指定された年月(yyyymm)より月末日(yyyymmdd)を求めます。
	 *
	 * @param date String yyyymm
	 * @return String yyyymmdd
	 * <br>
	 * 作成日 : (2004/01/21 16:12:37)
	 *
	 */

	public static String createGetsumatsubi(String date) {

		String work = date + "01";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();

		try {
			cal.setTime(sdf.parse(work));
		} catch (ParseException e) {
			throw new IllegalArgumentException();
		}

		return date + cal.getActualMaximum(Calendar.DATE);

	}

	/**
	 * 現在日(yyyymmdd)を求めます。
	 *
	 * @return String yyyymmdd
	 * <br>
	 * 作成日 : (2002/04/23 19:58:49)
	 *
	 */
	public static String nowStrdate() {

		Date now = new Date();
		String today = dateToDate8(now);
		return today;

	}


	/* **********************************************************************************
	 *
	 * 日付変換関連モジュール
	 *
	 * *********************************************************************************/

	/**
	 * ４桁の日付(MM/dd)にシステム日付の年を付加してDate型に変換します。<br>
	 * 日付は不正の場合はNULLが返ります。
	 *
	 * @param date4 String MM/dd
	 * @return Date
	 *
	 */
	public static Date date4SlashToDate(String date4){

		//システム日付の年を取得
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int year = cal.get(Calendar.YEAR);
		String date8 = year + "/" + date4;

		// 入力月日にシステム日付の年を付加し日付型に変換
		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyy/MM/dd");
		ParsePosition pos = new ParsePosition(0);
		return sdf.parse(date8,pos);

	}

	/**
	 * ４桁の日付(MMdd)をDate型に変換して返します。<br>
	 * 年の値はシステム日付を含む前後一年の内でシステム日付に一番近くなるように選択します。
	 *
	 * @param date4 String (MMdd)　
	 * @return Date
	 *
	 *		システム日付	入力日付(mmdd)	出力日付(yyyymmdd)
	 *		2012/06/20			05/02		2012/05/02
	 *		2012/06/20			07/02		2012/07/02
	 *		2012/06/20			11/02		2012/11/02
	 *		2012/06/20			12/02		2011/12/02
	 *		2012/10/20			04/02		2012/04/02
	 *		2012/10/20			03/02		2013/03/02
	 *		見やすいようにスラッシュを付けましたが実際は付けません。
	 *
	 */
	public static Date date4ToDate(String date4){

		// 入力日付のカレンダー情報を作成します。
		String Indate4 = "2000" + date4;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		Calendar dataCal = Calendar.getInstance();
		Date dataDate = null;
		try {
			// 入力日付を日付型に変換します。日付が妥当でない場合はExceptionが発生します。
			dataDate = sdf.parse(Indate4);
		} catch (ParseException e) {
			throw new IllegalArgumentException();
		}
		dataCal.setTime(dataDate);
		int dataMonth = dataCal.get(Calendar.MONTH);

		// 入力日付のカレンダー情報のクローンを作成します。
		Calendar date1 = (Calendar)dataCal.clone();
		Calendar date2 = (Calendar)dataCal.clone();

		// システム日付のカレンダー情報を作成します。
		Calendar current = Calendar.getInstance();
		int sysMonth = current.get(Calendar.MONTH);

		// システム日付の月と入力日付の月を比較します。
		if (sysMonth >= dataMonth) {
			// システム日付の月 >= 入力日付の月の場合は当年を基準とします。
			date1.set(Calendar.YEAR,current.get(Calendar.YEAR));
			date2.set(Calendar.YEAR,current.get(Calendar.YEAR) + 1);
		} else {
			// システム日付の月 > 入力日付の月の場合は前年を基準とします。
			date1.set(Calendar.YEAR,current.get(Calendar.YEAR) - 1);
			date2.set(Calendar.YEAR,current.get(Calendar.YEAR));
		}

		// システム日付の年月と入力日付の年月の差から
		// システム日付に一番近くなるように入力日付の年を選択します。
		int currentYM = current.get(Calendar.YEAR) * 12 + current.get(Calendar.MONTH);
		int date1YM = date1.get(Calendar.YEAR) * 12 + date1.get(Calendar.MONTH);
		if (Math.abs(currentYM - date1YM) <= 6) {
			return date1.getTime();
		} else {
			return date2.getTime();
		}
	}

	/**
	 * ４桁の日付(MMdd)をスラッシュ付４桁の日付(M/d)に変換して返します。<br>
	 * 年の値はシステム日付を含む前後一年の内でシステム日付に一番近くなるように選択します。
	 *
	 * @param date4 String (MMdd)　
	 * @return String ４桁の日付(M/d)
	 *
	 *	システム日付	入力日付(MMdd)	出力日付(M/d)
	 *	2011/02/20			02/29		3/1
	 *	2012/02/20			02/29		2/29
	 *
	 */
	public static String date4ToDate4Slash(String str) {

		Date date = date4ToDate(str);
		return dateToDate4Slash(date);

	}

	/**
	 * ４桁の日付(MMdd)をスラッシュ付４桁の日付(MM/dd)に変換して返します。<br>
	 * 年の値はシステム日付を含む前後一年の内でシステム日付に一番近くなるように選択します。
	 *
	 * @param date4 String (MMdd)　
	 * @return String ４桁の日付(MM/dd)
	 *
	 *	システム日付	入力日付(MMdd)	出力日付(MM/dd)
	 *	2011/02/20			02/29		03/01
	 *	2012/02/20			02/29		02/29
	 *
	 */
	public static String date4ToDate4Slash2(String str) {

		Date date = date4ToDate(str);
		return dateToDate4Slash2(date);

	}

	/**
	 * ４桁の日付(MMdd)を８桁の日付(yyyyMMdd)に変換して返します。<br>
	 * 年の値はシステム日付を含む前後一年の内でシステム日付に一番近くなるように選択します。
	 *
	 * @param date4 String (MMdd)　
	 * @return String ８桁の日付(yyyyMMdd)
	 *
	 * 変換例はdate4ToDateを参照してください。
	 *
	 */
	public static String date4ToDate8(String date4) {

		return(dateToDate8(date4ToDate(date4)));

	}

	/**
	 * ８桁の日付(yyyyMMdd)をDate型に変換します。<br>
	 * 日付は不正の場合はNULLが返ります。
	 *
	 * @param date8 String yyyyMMdd
	 * @return Date
	 *
	 */
	public static Date date8ToDate(String date8){

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();

		sdf.applyPattern("yyyyMMdd");
		ParsePosition pos = new ParsePosition(0);
		return sdf.parse(date8,pos);

	}

	/**
	 * スラッシュ付８桁の日付(yyyy/MM/dd)をDate型に変換します。<br>
	 * 日付は不正の場合はNULLが返ります。
	 *
	 * @param date8 String yyyyMMdd
	 * @return Date
	 *
	 */
	public static Date slashDate8ToDate(String date8){

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();

		sdf.applyPattern("yyyy/MM/dd");
		ParsePosition pos = new ParsePosition(0);
		return sdf.parse(date8,pos);

	}

	/**
	 * ８桁の日付(yyyyMMdd)をスラッシュ付８桁の日付(yyyy/M/d)に変換して返します。<br>
	 * 日付は不正の場合はNULLが返ります。
	 *
	 * @param str String (yyyyMMdd)　
	 * @return String ８桁の日付(yyyy/M/d)
	 *
	 */
	public static String date8ToDate8Slash(String str) {

		Date date = date8ToDate(str);
		if (date == null){
			return null;
		}else{
			return dateToDate8Slash(date);
		}

	}

	/**
	 * ８桁の日付(yyyyMMdd)をスラッシュ付８桁の日付(yyyy/MM/dd)に変換して返します。<br>
	 * 日付は不正の場合はNULLが返ります。
	 *
	 * @param str String (yyyyMMdd)　
	 * @return String ８桁の日付(yyyy/MM/dd)
	 *
	 */
	public static String date8ToDate8Slash2(String str) {

		Date date = date8ToDate(str);
		if (date == null){
			return null;
		}else{
			return dateToDate8Slash2(date);
		}

	}
	/**
	 * 日付(Date型)をスラッシュ付月日(M/d)で返します
	 *
	 * @param date date
	 * @return String 月日(M/d)
	 *
	 */
	public static String dateToDate4Slash(Date date) {

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("M/d");
		return sdf.format(date);

	}

	/**
	 * 日付(Date型)をスラッシュ付月日(MM/dd)で返します
	 *
	 * @param date date
	 * @return String 月日(MM/Dd)
	 *
	 */
	public static String dateToDate4Slash2(Date date) {

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("MM/dd");
		return sdf.format(date);

	}

	/**
	 * 日付(Date型)を年月日(yyyyMMdd)で返します
	 *
	 * @param date date
	 * @return String 年月日(yyyyMMdd)
	 *
	 * * @param
	 *  * @return
	 *
	 */
	public static String dateToDate8(Date date) {

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyyMMdd");
		return sdf.format(date);

	}

	/**
	 * 日付(Date型)をスラッシュ付年月日(yyyy/M/d)で返します
	 *
	 * @param date date
	 * @return String 年月日(yyyy/M/d)
	 *
	 */
	public static String dateToDate8Slash(Date date) {

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyy/M/d");
		return sdf.format(date);

	}

	/**
	 * 日付(Date型)をスラッシュ付年月日(yyyy/MM/dd)で返します
	 *
	 * @param date date
	 * @return String 年月日(yyyy/MM/dd)
	 *
	 */
	public static String dateToDate8Slash2(Date date) {

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyy/MM/dd");
		return sdf.format(date);

	}

	/**
	 * 日付(Date型)を年月日時分秒(yyyyMMddddHHmmss)で返します
	 *
	 * @param date date
	 * @return String 年月日時分秒(yyyyMMddddHHmmss)
	 *
	 */
	public static String dateToTsFormat(Date date) {

		SimpleDateFormat sdf = (SimpleDateFormat)DateFormat.getDateInstance();
		sdf.applyPattern("yyyyMMddHHmmss");
		return sdf.format(date);
	}


	/* **********************************************************************************
	 *
	 * 日付変換関連モジュール
	 *
	 * *********************************************************************************/

	/**
	 * 西暦を和暦に変換します。<br>
	 * 日付の妥当性がない場合は６桁のスペースが返ります。
	 * ex: 20020625 -> 140625
	 *
	 * @param Date8 String 西暦年月日(yyyymmdd)
	 * @return String 和暦年月日(yymmdd)
	 * <br>
	 * 修正日 : V010.0 (2012/06/30)
	 * 元号変更対応のため全面書き直し
	 *
	 */
	public static String date8ToWareki(String date8) {

		String wareki = "      ";
		String work = UtilWareki.getJPDate(date8);	// 元号付和暦

		if (work != null) {
			wareki = work.substring(1);
		}

		return wareki;
	}


	/**
	 * 西暦をスラッシュ付和暦に変換します。<br>
	 * 日付の妥当性がない場合は８桁のスペースが返ります。
	 * ex: 20020625 -> 14/06/25
	 *
	 * @param Date8 String 西暦年月日(yyyymmdd)
	 * @return String 和暦年月日(yy/mm/dd)
	 * <br>
	 * 修正日 : V010.0 (2012/06/30)
	 * 元号変更対応のため全面書き直し
	 *
	 */
	public static String date8ToWarekiSlash(String date8) {

		String wareki = "        ";
		String work = UtilWareki.getJPDate(date8);	// 元号付和暦

		if (work != null) {
			wareki = work.substring(1,3) + "/";
			wareki = wareki + work.substring(3,5) + "/";
			wareki = wareki + work.substring(5,7);
		}

		return wareki;
	}

//	public static String date8ToWarekiSlash(String str) {
//
//		int val,tpval;
//		String tp;
//		StringBuffer sb = new StringBuffer();
//
//		tp = Wareki.getTransferParameter(str);
//
//		val = Integer.parseInt(str.substring(0,4));
//		tpval = Integer.parseInt(tp.substring(0,4));
//		int wareki = val - tpval + 1;
//		sb.append(wareki + "/");
//		sb.append(str.substring(4,6) + "/");
//		sb.append(str.substring(6));
//
//		return sb.toString();
//	}


	/**
	 * 西暦を日本語表記和暦に変換します。<br>
	 * 日付の妥当性がない場合は０桁のスペースが返ります。
	 * ex: 20120606 -> 平成24年 6月 6日
	 *
	 * @param Date8 String 西暦年月日(yyyymmdd)
	 * @return String 和暦年月日(平成y年m月d日)
	 * <br>
	 * 作成日 : V010.0 (2012/06/30)
	 *
	 */
	public static String date8ToWarekiJp(String date8) {

		String wareki = "";
		String work = UtilWareki.getJPDate(date8);	// 元号付和暦

		if (work != null) {
			String work1 = work.substring(1,3);
			if (work1.substring(0,1).equals("0")) {
				work1 = " " + work1.substring(1,2);
			}
			String work2 = work.substring(3,5);
			if (work2.substring(0,1).equals("0")) {
				work2 = " " + work2.substring(1,2);
			}
			String work3 = work.substring(5,7);
			if (work3.substring(0,1).equals("0")) {
				work3 = " " + work3.substring(1,2);
			}
			wareki = UtilWareki.getJPname(work.substring(0,1));
			wareki = wareki + work1 + "年";
			wareki = wareki + work2 + "月";
			wareki = wareki + work3 + "日";
		}

		return wareki;
	}



	/**
	 * ６桁の和暦日付を西暦日付(Date型)に変換します。<br>
	 * 和暦を平成とした西暦日付と新元号とした西暦日付を作成し、
	 * 現在日付に近い方の日付を使用します。
	 *
	 * @param wareki String 和暦年月日(yymmdd)
	 * @return Date 西暦年月日(yyyymmdd)
	 * <br>
	 * 修正日 : V010.0 (2012/06/30)
	 * 元号変更対応のため全面書き直し
	 *
	 *
	 * 元号変更日：2055/05/05(H670505) とした時の出力例
	 *	システム日付	入力日付		出力日付
	 *	2011/02/20			67/05/04→2055/05/04
	 *	2012/02/20			67/05/04→2055/05/04
	 *		67/05/04→2055/05/04
	 *		67/05/05→2055/05/05
	 *		01/05/05→2055/05/05
	 */
	public static Date datewarekiToDate(String wareki) {

		if(wareki == null) return null;
		if(wareki.trim().length() == 0) return null;

		// 当日日付を西暦で取得します。
		String DateNow = dateToDate8(new Date());

		// 入力日付を平成で西暦に変換します。
		String DateOld = UtilWareki.getUSDate(UtilWareki.getJPinitial(3) + wareki);
		if (DateOld == null) return null;

		// 入力日付を新元号で西暦に変換します。
		String DateNew = UtilWareki.getUSDate(UtilWareki.getJPinitial(4) + wareki);
		if (DateNew == null) return null;

		// 入力平成日付と当日日付の差の絶対値と
		// 入力新元号日付と当日日付の差の絶対値を比較し
		// 差の少ない元号の日付を妥当とし西暦で出力します。
		String DateOut = null;
		int intNow = Integer.parseInt(DateNow);
		int intOld = Integer.parseInt(DateOld);
		int intNew = Integer.parseInt(DateNew);
		if (Math.abs(intNow - intOld) <= Math.abs(intNow - intNew)) {
			DateOut = DateOld;
		}else{
			DateOut = DateNew;
		}
		// 西暦日付の真偽性ﾁｪｯｸ
		if(isValidDate(DateOut) == false) return null;

		return date8ToDate(DateOut);

	}


	/**
	 * ６桁の和暦日付を８桁の西暦日付に変換します。<br>
	 * 和暦を平成とした西暦日付と新元号とした西暦日付を作成し、
	 * 現在日付に近い方の日付を使用します。
	 *
	 * @param wareki String 和暦年月日(yymmdd)
	 * @return String 西暦年月日(yyyymmdd)
	 *
	 */
	public static String datewarekiToDate8(String wareki) {

		if(wareki == null) return null;
		if(wareki.trim().length() == 0) return null;

		Date date = datewarekiToDate(wareki);
		if(date == null) return null; // 和暦変換不能ﾃﾞｰﾀの場合、NULL を返す。

		return dateToDate8(date);

	}

	/**
	 * ６桁の和暦日付を西暦日付(Date型)に変換します。<br>
	 * 和暦を平成とした西暦日付と新元号とした西暦日付を作成し、
	 * 現在日付に近い方の日付を使用します。
	 *
	 * @param wareki String 和暦年月日(yymmdd)
	 * @return Date 西暦年月日(yyyymmdd)
	 * <br>
	 * 修正履歴
	 * R005.0 2005/08/04 口座確認専用委託者対応により新規追加	H.TASHIRO
	 * ※(datewarekiToDate8(String)から日付の真偽性ﾁｪｯｸをはずしたﾊﾞｰｼﾞｮﾝ)
	 * 修正日 : V010.0 (2012/06/30)
	 * 元号変更対応のため全面書き直し
	 *
	 */
	public static String date6ToDate8(String wareki) {

		if(wareki == null) return null;
		if(wareki.trim().length() == 0) return null;

		// 当日日付を西暦で取得します。
		String DateNow = dateToDate8(new Date());

		// 入力日付を平成で西暦に変換します。
		String DateOld = UtilWareki.getUSDate(UtilWareki.getJPinitial(3) + wareki);
		if (DateOld == null) return null;

		// 入力日付を新元号で西暦に変換します。
		String DateNew = UtilWareki.getUSDate(UtilWareki.getJPinitial(4) + wareki);
		if (DateNew == null) return null;

		// 入力平成日付と当日日付の差の絶対値と
		// 入力新元号日付と当日日付の差の絶対値を比較し
		// 差の少ない元号の日付を妥当とし西暦で出力します。
		String DateOut = null;
		int intNow = Integer.parseInt(DateNow);
		int intOld = Integer.parseInt(DateOld);
		int intNew = Integer.parseInt(DateNew);
		if (Math.abs(intNow - intOld) <= Math.abs(intNow - intNew)) {
			DateOut = DateOld;
		}else{
			DateOut = DateNew;
		}

		return DateOut;

	}




}
