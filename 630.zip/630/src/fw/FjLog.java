package fw;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FjLog {
	  /** FooLoggerクラスの唯一のインスタンス */
	  //private FooLogger _instance = null;
	 private static FjLog _instance = null;

	  /** ロガー */
	  //private Log _logger = null;
	  private Logger _logger = null;

	  /** ロックオブジェクト */
	  private static Object _syncRoot = new Object();

	  /**
	   * コンストラクタ
	   * インスタンス化できないようにスコープをprivateにする
	   */
	  private FjLog() {
	    //_logger = Log4jFactory.getLog("log4jの設定ファイルで設定したcategory名");
	    _logger = LogManager.getLogger();
	  }

	  /**
	   * FooLoggerインスタンス取得メソッド
	   * このメソッドでのみ、インスタンスを取得できる
	   * @return FooLogger
	   */
	  private static FjLog getInstance() {
	    // ダブルチェックロッキング
	    if( _instance == null ) {
	      synchronized( _syncRoot ) {
	        if( _instance == null ) {
	          _instance = new FjLog();
	        }
	      }
	    }
	    return _instance;
	  }

	  /**
	   * Logger取得プロパティ
	   */
	  public Logger getLogger() {
	    return _logger;
	  }

	  public static void  debug(String msg) {
			FjLog.getInstance().getLogger().debug(msg);
	  }

	  public static void info(String msg) {
			FjLog.getInstance().getLogger().info("{}", msg);
	  }

	  public static void warn(String msg) {
			FjLog.getInstance().getLogger().warn("{}", msg);
	  }

	  public static void error(String msg) {
			FjLog.getInstance().getLogger().error("{}", msg);
	  }

	  public static void trace(String msg) {
			FjLog.getInstance().getLogger().error(msg);
	  }


		public static void main(String[] args) {
			FjLog.trace("start");
			FjLog.debug("debugです");
			FjLog.info("info2です");
			FjLog.warn("warnです");
			FjLog.error("errorです");
			FjLog.trace("traceです");
			FjLog.trace("end");
		}
	}


//public class log42 {
//
//
//	//getLoggerの引数はロガー名を指定する。
//	//log4j2では、ロガー名の指定が省略可能になった。
//	private Logger logger = org.apache.logging.log4j.LogManager.getLogger();
//
//	void runSample() {
//
//		logger.trace("Start"); //2017/01/21 06:02:17.154 [main] TRACE  test1.Sample Start
//
//		int a = 1;
//		int b = 2;
//		String c = null;
//
//		logger.debug("debug"); //2017/01/21 06:02:17.157 [main] DEBUG  test1.Sample debug
//		logger.info("info={}",a); //2017/01/21 06:02:17.159 [main] INFO   test1.Sample info=1
//		logger.warn("warn={},={}" ,a,b); //2017/01/21 06:02:17.159 [main] WARN   test1.Sample warn=1,=2
//		logger.error("error={}",c); //2017/01/21 06:02:17.171 [main] ERROR  test1.Sample error=null
//
//        logger.trace("End"); //2017/01/21 06:02:17.172 [main] TRACE  test1.Sample End
//
//
//	}
//
//
//public static void main(String[] args) {
//	log42 s = new log42();
//	s.runSample();
//}
//
//}
