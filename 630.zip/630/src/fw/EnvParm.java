﻿package fw;

import java.util.Enumeration;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;

/**
 * 環境パラメータ管理ビーン<BR>
 * <BR>
 * 環境依存パラメータを取得するビーン
 * 環境依存のパラメータの集中管理<BR>
 * 環境設定ファイル（省略時:"fj.properties"）から設定値を取得。<BR>
 * ファイル名およびファイル形式は、java.util.PropertyResourceBundleクラスの実装に準じる。
 *
 * @see java.util.PropertyResourceBundle
 * @author c
 * @since 2017/05/31
 */
public class EnvParm {

	//プロパティファイル格納ディレクトリ
	private String propertyeDir = new String("resources");
	// プロパティファイル名称（デフォルト）
	private String fieldPropertyFileName = new String("fj");
	private PropertyResourceBundle properties = null;

	/**
	 * PropertyFileNameプロパティに設定されたファイル名で初期化。
	 */
//	public EnvParm() {
//		super();
//		String propertyFileName = System.getProperty("fj.propertyFile.name");
//		if (propertyFileName != null) {
//			fieldPropertyFileName = propertyFileName;
//		}
//		/* PropertyFileNameプロパティに設定されたファイルを取得 */
//		loadProperty(propertyeDir + "/" + fieldPropertyFileName);
//	}

	/**
	 * 引数で指定されたプロパティ・ファイルを使用して初期化。
	 *
	 * @param propertyFile
	 *            java.lang.String 環境設定ファイルとして使用するファイル名（注意！.properties拡張子は指定しない）
	 */
	public EnvParm(String propertyFile) {
		this.fieldPropertyFileName = propertyFile;
		boolean bool = loadProperty(propertyeDir + "." + fieldPropertyFileName);
		if(!bool){

		}
	}

	/**
	 * PropertyFileNameプロパティに設定されたファイルを取得する。
	 */
	//public void loadProperty(String propertyFile) {
	public boolean loadProperty(String propertyFile) {
		try {
			Locale locale = new Locale("ja");
			/**  "resource/fj.properties"を読み込む　※".properties"拡張子は付加しない。 */
			//properties = (PropertyResourceBundle) PropertyResourceBundle.getBundle("aa", locale);
			properties = (PropertyResourceBundle) PropertyResourceBundle.getBundle(propertyFile, locale);

		} catch (MissingResourceException e) {
			String className = Thread.currentThread().getStackTrace()[1].getClassName() ;
			String msg = new String(className + " : " + "環境設定用 propertyファイルが配置していません。 propertyFile=" +  propertyFile );
			FjLog.error(msg);
			System.err.println(msg);
			e.printStackTrace();
			properties = null;
			return false;
		}
		return true;
	}

	/**
	 * 引数で指定されたプロパティのキーの値を検索する。
	 *
	 * @return java.lang.String 指定されたキーの値。
	 * @param key
	 *            java.lang.String プロパティのキー名
	 *
	 * @see 存在しない場合はnull)
	 */
	public String getProperty(String key) {

		if (properties != null) {
			try {
				return properties.getString(key);
			} catch (MissingResourceException e) {
				return null;
			}
		}
		return null;
	}

	/**
	 * 引数で指定されたプロパティのキーの値を検索する。
	 *
	 * @return java.lang.String 指定されたキーの値。
	 * @param key
	 *            java.lang.String プロパティのキー名
	 * @param defaultValue
	 *            java.lang.String キーが存在しない場合のディフォルト値
	 *
	 * @see 存在しない場合は defaultValue
	 */
	public String getProperty(String key, String defaultValue) {
		String work = null;
		if (properties != null) {
			// return properties.getProperty(key, defaultValue);
			try {
				work = properties.getString(key);
			} catch (MissingResourceException e) {
				return defaultValue;
			}

			if (work == null) {
				work = defaultValue;
			}
			return work;
		}
		return null;
	}

	/**
	 * propertyFileName プロパティー (java.lang.String) 値を取得する。
	 *
	 * @return propertyFileName プロパティーの値。
	 * @see #setPropertyFileName
	 */
	public String getPropertyFileName() {
		return fieldPropertyFileName;
	}

	/**
	 * プロパティ・ファイルに含まれるキー名を全て検索する。
	 *
	 * @return java.util.Enumeration プロパティ・ファイルに含まれるキー名の列挙
	 */
	public Enumeration propertyNames() {
		if (properties != null) {
			return properties.getKeys();
		}
		return null;
	}

	/**
	 * propertyFileName プロパティー (java.lang.String) 値を設定する。
	 *
	 * @param propertyFileName
	 *            プロパティーの新しい値です。
	 * @see #getPropertyFileName
	 */
	public void setPropertyFileName(String propertyFileName) {
		fieldPropertyFileName = propertyFileName;
	}

	/**
	 * テストドライバ
	 *
	 * @see "fj.properties"ファイルは、resourcesディレクトリ直下に配置する。
	 */
public static void main(String[] args) {
		// fieldPropertyFileName = propertyFileName;
		EnvParm param = new EnvParm("fj");

		String paramName = "fj.JdbcUtil.JdbcDriverName";
		String prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);

		paramName = "fj.JdbcUtil.JdbcURL";
		prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);

		paramName = "fj.JdbcUtil.JdbcUserID";
		prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);

		paramName = "fj.JdbcUtil.JdbcPassword";
		prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);

		// 日本語取得
		paramName = "fj.kenID";
		prm = param.getProperty(paramName);
		try{
			prm = new String( prm.getBytes( "ISO-8859-1" ) , "JISAutoDetect" );
		} catch (Exception e){

		}

		System.out.println(paramName + ":" + prm);
	}
}
