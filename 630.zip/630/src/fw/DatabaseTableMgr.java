﻿package pjt.fw;

import java.util.*;
import java.sql.*;

/**
 * テーブル管理ビーン<BR><BR>
 * RDB上のテーブルをオブジェクトしてメモリー上にキャッシュするインコア・テーブル機能を提供し
 *ます。テーブル管理ビーンは、最初に呼び出された時点からstaticクラスとしてJVMに常駐します。
 *<BR><BR>
 * 管理対象は環境設定ファイル（"tablemgr.properties"）に登録します。<BR><BR>
 *　[tablemgr.propertiesの形式]<BR>
 *　objectName=propertiesファイルの名前<BR>
 * objectName　　　　　　　　:　管理対象を識別する任意の名前<BR>
 * propertiesファイルの名前　:　テーブルの作成方法を指定する（テーブル情報プロパティ)<BR>
 * ファイル名およびファイル形式は、java.util.PropertyResourceBundleクラスの実装に準じます。
 *<BR><BR>
 *　[テーブル情報プロパティの形式]<BR>
 *　Type=SINGLE | MULTI<BR>
 *　Sql=キーと値を取得するSQL文<BR>
 * Type　　： "SINGLE"はキーと値が１対１に対応するテーブルの場合に指定します。<BR>
 * 　　　　： "MULTI"は１つのキーが１つ以上の値を持つテーブルの場合に指定します。<BR>
 * Sql 　　：　キーと値を取得するSQL文を指定します。結果セットの第１列がキー、第２列が値とし<BR>
 * 　　　　　　て扱われます。<BR>
 *<BR>
 * pjt.fwパッケージでは、以下のオブジェクトを使用しています。<BR>
 * <LI>acclevelオブジェクト</LI><BR>
 *　セッション管理機能で使用 ページのアクセスレベル情報(SINGLE)<BR>
 * <LI>directオブジェクト</LI><BR>
 *　セッション管理機能で使用 ページが直接URI指定呼び出された時のアクセスの可否を管理(SINGLE)<BR>
 * <LI>linkオブジェクト</LI><BR>
 *　セッション管理機能で使用 ページ間のリンクの妥当性情報(MULTI)<BR>
 * <LI>nocacheオブジェクト</LI><BR>
 *　セッション管理機能で使用 出力ページのキャッシュ属性情報(SINGLE)<BR>
 * <LI>sesscntlオブジェクト</LI><BR>
 *　セッション管理機能で使用 セッション・オブシェクトの作成可否を管理(SINGLE)<BR>
 * <LI>erruriオブジェクト</LI><BR>
 *　汎用エラーハンドラで使用 ユーザーエラー発生時の表示ページ情報を管理(SINGLE)<BR>
 * <LI>msglinkオブジェクト</LI><BR>
 *　汎用エラーハンドラで使用 ユーザーエラー発生時のエラー表示後のリンク先情報を管理(SINGLE)<BR>
 * <LI>usermsgオブジェクト</LI><BR>
 *　エラー表示で使用　　　　 メッセージ番号とメッセージ・テキストを管理(SINGLE)<BR>
 *<BR>
 * 上記以外に任意のオブジェクトを追加することが可能です。テーブル管理機能は初期のロード以外に
 *はDBアクセスを行わないためレスポンスの向上に寄与しますが、一度作成されたオブジェクトは常駐
 *するため大量のデータを保持した場合はメモリー使用量に大きな影響を与えることに注意してください
 *。<BR>
 *
 * @author IBM Japan, Ltd. System Solution Center No.1 Systems Engineering
 * @version 1.0
 *
 */

public class DatabaseTableMgr implements TableMgr{

	private static PropertyResourceBundle tableList;	// tablemgr.properties
	private static java.util.Hashtable tablePtr;		// table object list (object name, Hashtable)
	private static fw.JDBCUtil jUtil;

/**
 * \ッドの記述を挿入してください。
 * 作成日 : (2002/04/03 19:46:02)
 */
private DatabaseTableMgr() {

	loadAllTables();

}



/**
 * 指定されたオブジェクトに指定されたキーが存在するかどうかをテストします。
 * @return boolean キーが存在する場合=true,存在しない場合=false
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @exception java.lang.SystemErrorException 例外記述:指定されたオブジェクトが存在しない場合にthrow
 */
public boolean containsKey(java.lang.String objName, java.lang.String key) throws SystemErrorException {

	Hashtable hashobj = (Hashtable) tablePtr.get(objName);	// get hash obj
	if (hashobj == null) {
		// service stop or invalid objname
		throw new IllegalArgumentException("Invalid Object Name (" + objName + ")");
	}
	return (hashobj.containsKey(key));

}
/**
 * 指定されたオブジェクトに指定されたキーの値が存在するかテストします。
 * @return boolean 値が存在する場合=true,存在しない場合=false
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @param val java.lang.String 値
 * @exception java.lang.SystemErrorException 例外記述：指定されたオブジェクトが存在しない場合にthrow
 */
public boolean containsVal(java.lang.String objName, java.lang.String key, java.lang.String val)
	throws SystemErrorException {

	Hashtable hashobj = (Hashtable) tablePtr.get(objName);	// get hash obj
	if (hashobj == null) {
		// service stop or invalid objname
		throw new IllegalArgumentException("Invalid Object Name (" + objName + ")");
	}
	Object obj = hashobj.get(key);
	if (obj == null) {
		return false;
	}
	if (obj instanceof String) {
		if (((String) obj).equals(val)) {					// SINGLE TABLE
			return true;
		} else {
			return false;
		}
	} else {												// MULTI TABLE
		Vector vecobj = (Vector) hashobj.get(key);			// get Vector obj
		return (vecobj.contains(val));
	}
}
/**
 * 指定されたオブシェクトをDBからロードし初期化します。
 * @param objName java.lang.String オブジェクト名
 * @exception java.util.MissingResourceException 例外記述：テーブル情報プロパティ・ファイルが見つからない。
 */
private synchronized void createTable(String objName) throws MissingResourceException {

	boolean single = true;
	String tempVal;

	// テーブル情報のプロパティファイルの取得
	PropertyResourceBundle tableAttr;
	String tablePropFile = tableList.getString(objName);
	tableAttr = (PropertyResourceBundle) PropertyResourceBundle.getBundle(tablePropFile);
	if (tableAttr.getString("Type").equals("MULTI")) {
		single = false;
	}

	// データのロードとオブジェクトの生成
	Hashtable hashobj = new Hashtable();
	Vector vecobj = null;
	String prevKey = "";
	String key;
	try {
		jUtil.setSQL(tableAttr.getString("Sql"));
		jUtil.executeQuery();
		while (jUtil.next()) {
			key = jUtil.getString(1).trim();			// get key value
			if (single) {
				tempVal = jUtil.getString(2);
				if (! jUtil.wasNull()) {
					hashobj.put(key, tempVal.trim());	// save to Hashtable
				}
			} else {
				if (!(key.equals(prevKey))) {			// change key value ?
					vecobj = new Vector();				// create new Vector obj
					hashobj.put(key, vecobj);			// save key&Vector to Hash
					prevKey = key;
				}
				tempVal = jUtil.getString(2);
				if (! jUtil.wasNull()) {				// get value & save to Vector obj
					vecobj.addElement(tempVal.trim());
				}
			}	// end if single
		} // end while
		tablePtr.put(objName, hashobj);					// set table ptr

	} catch (SQLException e) {
		FjLog.L0.writeLog("TableMgr::createTable() SQLException");
		//System.err.println("TableMgr::createTable() SQLException");
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
	} catch (Exception e) {
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
	} finally {
		try {
			if (jUtil != null) {
				jUtil.close();
				jUtil.freeConnection();
				jUtil = null;
			}
		} catch (SQLException e) {
			FjLog.L0.writeLog("TableMgr::createTable() SQLException");
			//System.err.println("TableMgr::createTable() SQLException");
			FjLog.L0.printStackTrace(e);
			//e.printStackTrace();
		}
	}

}
/**
 * オブジェクト管理テーブルのリファレンスを戻します。
 * @return java.util.Hashtable
 */
private Hashtable getTablePtr() {
	return tablePtr;
}
/**
 * 指定されたオブジェクトに指定されたキーの値を取得します。<BR>
 * 指定されたキーが存在しない場合は、nullを戻します。<BR>
 * SINGLEタイプの専用のメソッドです。MULTIタイプの場合は、getValuesメソッドを使用して下さい。<BR>
 * @return java.lang.String 指定されたキーの値
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @exception java.lang.SystemErrorException 例外記述：指定されたオブジェクトが存在しない場合にthrow
 */
public String getValue(String objName, String key) throws SystemErrorException {

	Hashtable hashobj = (Hashtable) tablePtr.get(objName);	// get hash obj
	if (hashobj == null) {
		// service stop or invalid objname
		throw new IllegalArgumentException("Invalid Object Name (" + objName + ")");
	}
	Object obj = hashobj.get(key);							// get value
	if (obj == null) {
		return null;
	} else if (obj instanceof String) {
		return (String) obj;
	} else {												// MULTI TABLE
		throw new IllegalArgumentException("Invalid Object type (" + objName + ")");
	}

}
/**
 * 指定されたオブジェクトに指定されたキーの値を取得します。<BR>
 * 指定されたキーが存在しない場合は、nullを戻します。<BR>
 * MULTIタイプの専用のメソッドです。SINGLEタイプの場合は、getValueメソッドを使用して下さい。<BR>
 * @return java.util.Vector 指定されたキーの値のVectorオブジェクト
 * @param objName java.lang.String オブジェクト名
 * @param key java.lang.String キー名
 * @exception java.lang.SystemErrorException 例外記述：指定されたオブジェクトが存在しない場合にthrow
 */
public java.util.Vector getValues(java.lang.String objName, java.lang.String key) throws SystemErrorException {

	Hashtable hashobj = (Hashtable) tablePtr.get(objName);	// get hash obj
	if (hashobj == null) {
		// service stop or invalid objname
		throw new IllegalArgumentException("Invalid Object Name (" + objName + ")");
	}
	Object obj = hashobj.get(key);							// get Values
	if (obj == null) {
		return null;
	}
	if (obj instanceof String) {
		throw new IllegalArgumentException("Invalid Object type (" + objName + ")");
	} else {												// MULTI TABLE
		Vector vecobj = (Vector) hashobj.get(key);
		return ((Vector) vecobj.clone());
	}
}
/**
 * 全てのオブジェクトをDBからロードし初期化します。
 */
private void loadAllTables() {

	Enumeration enum1;
	String objName, propName;

	// TableMgr設定ファイル(tablemgr.properties)のロード

	try {
		tableList = (PropertyResourceBundle) PropertyResourceBundle.getBundle("tablemgr");

		// テーブル管理情報の初期化
		tablePtr = new Hashtable();
		enum1 = tableList.getKeys();

		while (enum1.hasMoreElements()) {
			objName = (String) enum1.nextElement();		// Table Object Name
			propName = tableList.getString(objName);	// Table Property file name

			jUtil = new JDBCUtil();
			try {
				createTable(objName);					// Load table
			} catch (MissingResourceException e) {
				e.printStackTrace();
			} finally {
				jUtil.freeConnection();
				jUtil = null;
			}
		}
	} catch (MissingResourceException e) {
		FjLog.L0.writeLog("*** tablemgr.properties load error ***");
		//System.err.println("*** tablemgr.properties load error ***");
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
	} catch (ClassNotFoundException e) {
		FjLog.L0.writeLog("*** JDBC Driver not found");
		//System.out.println("*** JDBC Driver not found");
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
		return;
	} catch (SQLException e) {
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
	} catch (Exception e) {
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
	}
}
/**
 * 指定されたオブシェクトをDBからロードし初期化します。
 */
private void loadTable(String objName) {

	try {
		jUtil = new JDBCUtil();
		try {
			createTable(objName);					// Load table
		} catch (MissingResourceException e) {
			e.printStackTrace();
		} finally {
			jUtil.freeConnection();
		}
	} catch (ClassNotFoundException e) {
		FjLog.L0.writeLog("TableMgr::loadTable() JDBC Driver not found");
		//System.err.println("TableMgr::loadTable() JDBC Driver not found");
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
		return;
	} catch (SQLException e) {
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
	} catch (Exception e) {
		FjLog.L0.printStackTrace(e);
		//e.printStackTrace();
	}
	jUtil = null;

}
/**
 * 全てのオブジェクトを破棄します。
 */
private void stopAllTables() {

	Enumeration enum1 = tablePtr.keys();				// get object name list
	String objName;

	while (enum1.hasMoreElements()) {
		objName = (String) enum1.nextElement();		// Table Object Name
		stopTable(objName);							// stop table
	}

}
/**
 * 指定されたオブシェクトを破棄します。
 * @param objName java.lang.String
 */
private void stopTable(java.lang.String objName) {

	tablePtr.remove(objName);

}
}
