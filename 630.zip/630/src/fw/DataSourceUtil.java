package fw;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * JDBC接続管理ビーン<BR>
 * <BR>
 * JDBC接続管理ビーンは、WAS接続管理機能の使用の有無をアプリケーションから隠匿する。<BR>
 * また、Facedeデザイン・パターンを使用し、JDBCのConnectionクラス、Statementクラス
 * (PreparedStatementクラスを内部的に使用)、ResultSetクラスを内部的に管理することによって
 * 少ないステップ数でJDBCアクセスのアプリケーションを作成することができます。<BR>
 * <BR>
 * ［JDBC接続管理を使用したコーディング例]<BR>
 * try {<BR>
 * // JDBC接続管理のインタンス化<BR>
 * jUtil = new JDBCUtil();<BR>
 * try {<BR>
 * // SQLのセット<BR>
 * // 内部的にはDBの接続が行われていない場合この時点で接続<BR>
 * jUtil.setSQL("SELECT A,B FROM TABLE WHERE Z=?");<BR>
 * jUtil.setString(1,"XXX"); // パラメータ・マーカーに検索条件をセット<BR>
 * // 検索の実行<BR>
 * jUtil.executeQuery();<BR>
 * while (jUtil.next()) { // カーサーのセット<BR>
 * System.out.println(jUtil.getString(1)); //結果の取得<BR>
 * System.out.println(jUtil.getString(2));<BR>
 * }<BR>
 * jUtil.close(); // 結果セットとステートメントのclose<BR>
 * } catch (Exception e) {<BR>
 * e.printStackTrace();<BR>
 * } finally {<BR>
 * jUtil.freeConnection(); // 接続の解放<BR>
 * }<BR>
 * } catch (Exception e) {<BR>
 * e.printStackTrace();<BR>
 * }<BR>
 * jUtil = null;<BR>
 * <BR>
 * <BR>
 * [環境設定ファイル]<BR>
 * 環境設定ファイル（省略時:"iccfwenv.properties"）の以下の設定値が影響する。<BR>
 * <BR>
 * <LI>デフォルト JDBCドライバ名</LI><BR>
 * キー：fj.JdbcUtil.JdbcDriverName<BR>
 * 値 ：デフォルトで使用するJDBCドライバを指定する。<BR>
 * <LI>デフォルト JDBC URL</LI><BR>
 * キー：fj.JdbcUtil.JdbcURL<BR>
 * 値 ：デフォルトで使用するJDBC URLを指定する。<BR>
 * <LI>デフォルト JDBC ユーザーID</LI><BR>
 * キー：fj.JdbcUtil.JdbcUserID<BR>
 * 値 ：デフォルトで使用するJDBCのユーザーIDを指定する。<BR>
 * <LI>デフォルト JDBC パスワード</LI><BR>
 * キー：fj.JdbcUtil.JdbcPassword<BR>
 * 値 ：デフォルトで使用するJDBCのパスワードを指定する。<BR>
 * <BR>
 * <LI>WAS接続マネジャーの使用</LI><BR>
 * キー：fj.JdbcUtil.UseConnMgr<BR>
 * 値 ：TRUE － DBアクセスにWAS接続マネジャーを使用する。<BR>
 * FALSE － DBアクセスにWAS接続マネジャーを使用しません。(default)<BR>
 * <LI>WAS接続マネジャーの使用時のプール名</LI><BR>
 * キー：fj.JdbcUtil.ConnMgrPoolName<BR>
 * 値 ：WAS接続マネジャーを使用する場合のプール名を指定する。<BR>
 *
 * @see java.sql
 *
 */
public class DataSourceUtil {

	private boolean fieldUseConnMgr = false;
	private String fieldJdbcDriverName = new String();
	private String fieldJdbcUrl = new String();
	private String fieldJdbcUserID = new String();
	private String fieldJdbcPassword = new String();

	private Connection conn = null;
	private DataSource ds = null;

	private PreparedStatement sqlStmt = null;
	private ResultSet sqlResult = null;

	/**
	 * JDBCUtil コンストラクター<BR>
	 * 環境設定パラメータを取得し、各種プロパティを初期化する。<BR>
	 * JDBCドライバーをロードする。<BR>
	 *
	 * @exception java.lang.ClassNotFoundException
	 *                例外記述：JDBCドライバが見つからない場合
	 */
	//public DataSourceUtil() throws ClassNotFoundException {
	public DataSourceUtil() {
		super();

//		String work;

//		EnvParm parm = new EnvParm("fj");
//		fieldJdbcDriverName = parm.getProperty("fj.JdbcUtil.JdbcDriverName");
//		fieldJdbcUrl = parm.getProperty("fj.JdbcUtil.JdbcURL");
//		fieldJdbcUserID = parm.getProperty("fj.JdbcUtil.JdbcUserID");
//		fieldJdbcPassword = parm.getProperty("fj.JdbcUtil.JdbcPassword");
//		work = parm.getProperty("fj.JdbcUtil.UseConnMgr");
//
//		if (work != null) {
//			if (work.equals("TRUE")) {
//				fieldUseConnMgr = true;
//			}
//		}
//
//
//
//		DataSource ds = null;
//		try {
//			InitialContext initCtx = new InitialContext();
//			// Tomcatで管理されたデータベース接続をJNDI経由で取得。
//			// java:comp/env/を必ずつける。
//			ds = (DataSource) initCtx.lookup("java:comp/env/jdbc/TKJDWDB");
//		} catch (Exception e) {
//			//throw new SystemErrorException(e);
//			e.printStackTrace();
//		}
//
//		try (Connection connection = ds.getConnection()) {
//			// 接続が正しく完了するとコンソールにメッセージを出力
//			//log("接続を開きました");
//
//		} catch(Exception e) {
//			// 例外が発生したときはサーブレット例外にしてエラーとする。
//			//throw new SystemErrorException(e);
//			e.printStackTrace();
//		}
//		//request.getRequestDispatcher("/complete.html").forward(request, response);
//
//


	}

	/**
	 * \ッドの記述を挿入してください。 )
	 *
	 * @return boolean
	 * @param row
	 *            int
	 * @throws SystemErrorException
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public Connection getConnection() throws SystemErrorException {

//		EnvParm parm = new EnvParm("fj");
//		fieldJdbcUrl = parm.getProperty("fj.JdbcUtil.JdbcURL");

		DataSource ds = null;
		Connection connection = null;
		try {
			InitialContext initCtx = new InitialContext();
			// Tomcatで管理されたデータベース接続をJNDI経由で取得。
			// java:comp/env/を必ずつける。                 jdbc/TKJDWDB"
			ds = (DataSource) initCtx.lookup("java:comp/env/jdbc/TKJDWDB");
		} catch (NamingException e) {
			e.printStackTrace();
			throw new SystemErrorException(e);
		}

		try {
			connection = ds.getConnection();
			// 接続が正しく完了するとコンソールにメッセージを出力
			//log("接続を開きました");
		} catch(Exception e) {
			// 例外が発生したときはサーブレット例外にしてエラーとする。
			//throw new SystemErrorException(e);
			e.printStackTrace();
		}
		//request.getRequestDispatcher("/complete.html").forward(request, response);


		return connection;

	}



	/**
	 * ResultSetクラスのcloseメソッド、PreparedStatementクラスのcloseメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void close() throws SQLException {

		if (sqlResult != null) {
			sqlResult.close();
			sqlResult = null;
		}
		if (sqlStmt != null) {
			sqlStmt.close();
			sqlStmt = null;
		}
	}

	/**
	 * ResultSetクラスのcloseメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void closeResultSet() throws SQLException {

		sqlResult.close();

	}

	/**
	 * Connectionクラスのcommitメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void commit() throws SQLException {

		if (conn != null) {
			conn.commit();
		}

	}

	/**
	 * PreparedStatementクラスのexecuteQueryメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception iccfw.SystemErrorException
	 *                例外記述：DB接続マネージャの接続でタイムアウトが発生した場合
	 */
	public void executeQuery() throws SQLException {

		sqlResult = sqlStmt.executeQuery();

	}

	/**
	 * PreparedStatementクラスのexecuteUpdateメソッドを実行する。
	 *
	 * @return int SQL文で変更された行の数
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception iccfw.SystemErrorException
	 *                例外記述：DB接続マネージャの接続でタイムアウトが発生した場合
	 */
	public int executeUpdate() throws SQLException {

		return (sqlStmt.executeUpdate());

	}

	/**
	 * ResultSetクラスのfindColumnメソッドを実行する。
	 *
	 * @return int 列番号
	 * @param colName
	 *            java.lang.String 検索する列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int findColumn(java.lang.String colName) throws SQLException {

		return (sqlResult.findColumn(colName));

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが有効な行にある場合は true、結果セットに行がない場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean first() throws java.sql.SQLException {

		return (sqlResult.first());

	}

	/**
	 * DB接続を解放する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 *                例外記述：接続マネージャでのエラーが発生した場合
	 */
	public void freeConnection() throws SQLException {

		if (sqlStmt != null) {
			close();
		}
		if (conn != null) {
			conn.close();
			conn = null;
		}
	}



	/**
	 * テストドライバ
	 *
	 * @see "\src\fj.properties"
	 */
	public static void main(String[] args) {

		DataSourceUtil ds = null;
		Connection connection = null;
		try {
			// コネクション取得
			ds = new DataSourceUtil();
			connection = ds.getConnection();

			// SQL
			String sql = " SELECT AADCYOCD, AADCYONM, AADSEDAI FROM TAAD000 ";
			StringBuffer sb = new StringBuffer(sql);


			PreparedStatement statement = connection.prepareStatement(sql);

			// 実行
			ResultSet rs = statement.executeQuery();

			// 結果
			int i = 0;
			while (rs.next()) {
				i++;
				System.out.println(" i = " + i);
				System.out.println("[1] = " + rs.getString("AADCYOCD").trim());
				System.out.println("[2] = " + rs.getString("AADCYONM").trim());
				System.out.println("[3] = " + rs.getString("AADSEDAI").trim());
			}

			// コネクション・クローズ
			connection.close();

		} catch (Exception e) {
			String className = Thread.currentThread().getStackTrace()[1].getClassName() ;
			String msg = new String(className + " : " + "SQLの実行エラー "  + e.getMessage() );
			FjLog.error(msg);
			System.err.println(msg);
			e.printStackTrace();
		} finally {
			System.out.println("jdbcurl = " );
			try {
				if (connection != null) {
					connection.close();
					connection = null;
				}
			} catch (java.sql.SQLException sqle) {
			}
			String message = "End...";
			System.out.println(message);
		}

	}
}
