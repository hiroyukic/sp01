package fw;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * log4j2を使用してログ出力を行うサンプルクラス
 *
 */
public class logoutput {
	public static void main(String[] args) {
		Logger logger = LogManager.getLogger("EventLogger");

		logger.trace("TraceMessage");
		logger.debug("DebugMessage");
		logger.info("InfoMessage {}!", "Info Test Log4j2");
		logger.warn("WarnMessage {}!", "Warn Test Log4j2");
		logger.error("ErrorMessage {}!", "Error Message");
		logger.fatal("FatalMessage");
		logger.info("Exception", new Exception("Error EX"));
	}
}
