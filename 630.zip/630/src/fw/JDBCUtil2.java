package fw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * JDBC接続管理ビーン<BR>
 * <BR>
 * JDBC接続管理ビーンは、WAS接続管理機能の使用の有無をアプリケーションから隠匿する。<BR>
 * また、Facedeデザイン・パターンを使用し、JDBCのConnectionクラス、Statementクラス
 * (PreparedStatementクラスを内部的に使用)、ResultSetクラスを内部的に管理することによって
 * 少ないステップ数でJDBCアクセスのアプリケーションを作成することができます。<BR>
 * <BR>
 * ［JDBC接続管理を使用したコーディング例]<BR>
 * try {<BR>
 * // JDBC接続管理のインタンス化<BR>
 * jUtil = new JDBCUtil();<BR>
 * try {<BR>
 * // SQLのセット<BR>
 * // 内部的にはDBの接続が行われていない場合この時点で接続<BR>
 * jUtil.setSQL("SELECT A,B FROM TABLE WHERE Z=?");<BR>
 * jUtil.setString(1,"XXX"); // パラメータ・マーカーに検索条件をセット<BR>
 * // 検索の実行<BR>
 * jUtil.executeQuery();<BR>
 * while (jUtil.next()) { // カーサーのセット<BR>
 * System.out.println(jUtil.getString(1)); //結果の取得<BR>
 * System.out.println(jUtil.getString(2));<BR>
 * }<BR>
 * jUtil.close(); // 結果セットとステートメントのclose<BR>
 * } catch (Exception e) {<BR>
 * e.printStackTrace();<BR>
 * } finally {<BR>
 * jUtil.freeConnection(); // 接続の解放<BR>
 * }<BR>
 * } catch (Exception e) {<BR>
 * e.printStackTrace();<BR>
 * }<BR>
 * jUtil = null;<BR>
 * <BR>
 * <BR>
 * [環境設定ファイル]<BR>
 * 環境設定ファイル（省略時:"iccfwenv.properties"）の以下の設定値が影響する。<BR>
 * <BR>
 * <LI>デフォルト JDBCドライバ名</LI><BR>
 * キー：fj.JdbcUtil.JdbcDriverName<BR>
 * 値 ：デフォルトで使用するJDBCドライバを指定する。<BR>
 * <LI>デフォルト JDBC URL</LI><BR>
 * キー：fj.JdbcUtil.JdbcURL<BR>
 * 値 ：デフォルトで使用するJDBC URLを指定する。<BR>
 * <LI>デフォルト JDBC ユーザーID</LI><BR>
 * キー：fj.JdbcUtil.JdbcUserID<BR>
 * 値 ：デフォルトで使用するJDBCのユーザーIDを指定する。<BR>
 * <LI>デフォルト JDBC パスワード</LI><BR>
 * キー：fj.JdbcUtil.JdbcPassword<BR>
 * 値 ：デフォルトで使用するJDBCのパスワードを指定する。<BR>
 * <BR>
 * <LI>WAS接続マネジャーの使用</LI><BR>
 * キー：fj.JdbcUtil.UseConnMgr<BR>
 * 値 ：TRUE － DBアクセスにWAS接続マネジャーを使用する。<BR>
 * FALSE － DBアクセスにWAS接続マネジャーを使用しません。(default)<BR>
 * <LI>WAS接続マネジャーの使用時のプール名</LI><BR>
 * キー：fj.JdbcUtil.ConnMgrPoolName<BR>
 * 値 ：WAS接続マネジャーを使用する場合のプール名を指定する。<BR>
 *
 * @see java.sql
 *
 */
public class JDBCUtil2 {

	private boolean fieldUseConnMgr = false;
	private String fieldJdbcDriverName = new String();
	private String fieldJdbcUrl = new String();
	private String fieldJdbcUserID = new String();
	private String fieldJdbcPassword = new String();

	private Connection conn = null;
	private DataSource ds = null;

	private PreparedStatement sqlStmt = null;
	private ResultSet sqlResult = null;

	/**
	 * JDBCUtil コンストラクター<BR>
	 * 環境設定パラメータを取得し、各種プロパティを初期化する。<BR>
	 * JDBCドライバーをロードする。<BR>
	 *
	 * @exception java.lang.ClassNotFoundException
	 *                例外記述：JDBCドライバが見つからない場合
	 */
	public JDBCUtil2() throws ClassNotFoundException {
		super();

		String work;

		EnvParm parm = new EnvParm("fj");
		//fieldJdbcDriverName = parm.getProperty("fj.JdbcUtil.JdbcDriverName");
		//fieldJdbcDriverName = "COM.ibm.db2.jdbc.app.DB2Driver";
		fieldJdbcDriverName = "COM.ibm.db2.jdbc.net.DB2Driver";



		//fieldJdbcUrl = parm.getProperty("fj.JdbcUtil.JdbcURL");
		//fieldJdbcUrl = "jdbc:db2:TKJDWDB";
		//fieldJdbcUrl = "jdbc:db2://COMTSTA2:50000/TKJDWDB";
		//fieldJdbcUrl = "jdbc:db2://COMTSTA2:50000/";
		//fieldJdbcUrl = "jdbc:db2://COMTSTA2:50000/TKJDWDB"; だんまり
		//fieldJdbcUrl = "jdbc:db2://172.30.1.76:50000/"; SQL1001N  "50000" は、有効なデータベース名ではありません。
		//fieldJdbcUrl = "jdbc:db2://COMTSTA2:5678/TKJDWDB"; [IBM][JDBC Driver] CLI0616E  ソケットのオープン・エラー
		fieldJdbcUrl = "jdbc:db2://COMTSTA2:50000/TKJDWDB"; //だんまり


		fieldJdbcUserID = parm.getProperty("fj.JdbcUtil.JdbcUserID");
		fieldJdbcPassword = parm.getProperty("fj.JdbcUtil.JdbcPassword");
		work = parm.getProperty("fj.JdbcUtil.UseConnMgr");

		if (work != null) {
			if (work.equals("TRUE")) {
				fieldUseConnMgr = true;
			}
		}


		// Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();
		//# JDBC ドライバー名
		//fj.JdbcUtil.JdbcDriverName=COM.ibm.db2.jdbc.app.DB2Drive


		try {
			  //Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();
			  //Class.forName(fieldJdbcDriverName); // load JDBC driver
			  Class.forName(fieldJdbcDriverName).newInstance(); // load JDBC driver
		}catch (ClassNotFoundException e){
		}catch (Exception e){
		}


		//Class.forName(fieldJdbcDriverName); // load JDBC driver

	}

	/**
	 * \ッドの記述を挿入してください。 )
	 *
	 * @return boolean
	 * @param row
	 *            int
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean absolute(int row) throws java.sql.SQLException {

		return (sqlResult.absolute(row));

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void addBatch() throws java.sql.SQLException {

		sqlStmt.addBatch();

	}

	/**
	 * \ッドの記述を挿入してください。 作
	 *
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void afterLast() throws java.sql.SQLException {

		sqlResult.afterLast();

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void beforeFirst() throws java.sql.SQLException {

		sqlResult.beforeFirst();

	}

	/**
	 * PreparedStatementクラスのcancelメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void cancel() throws SQLException {

		sqlStmt.cancel();

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void clearBatch() throws java.sql.SQLException {

		sqlStmt.clearBatch();

	}

	/**
	 * ConnectionクラスのclearWarningsメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void clearDBWarnings() throws SQLException {

		conn.clearWarnings();

	}

	/**
	 * PreparedStatementクラスのclearParametersメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void clearParameters() throws SQLException {

		sqlStmt.clearParameters();

	}

	/**
	 * ResultSetクラスのclearWarningsメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void clearRSWarnings() throws SQLException {

		sqlResult.clearWarnings();

	}

	/**
	 * PreparedStatementクラスのclearWarningsメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void clearWarnings() throws SQLException {

		sqlStmt.clearWarnings();

	}

	/**
	 * ResultSetクラスのcloseメソッド、PreparedStatementクラスのcloseメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void close() throws SQLException {

		if (sqlResult != null) {
			sqlResult.close();
			sqlResult = null;
		}
		if (sqlStmt != null) {
			sqlStmt.close();
			sqlStmt = null;
		}
	}

	/**
	 * ResultSetクラスのcloseメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void closeResultSet() throws SQLException {

		sqlResult.close();

	}

	/**
	 * Connectionクラスのcommitメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void commit() throws SQLException {

		if (conn != null) {
			conn.commit();
		}

	}

	/**
	 * PreparedStatementクラスのexecuteQueryメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception iccfw.SystemErrorException
	 *                例外記述：DB接続マネージャの接続でタイムアウトが発生した場合
	 */
	public void executeQuery() throws SQLException {

		sqlResult = sqlStmt.executeQuery();

	}

	/**
	 * PreparedStatementクラスのexecuteUpdateメソッドを実行する。
	 *
	 * @return int SQL文で変更された行の数
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception iccfw.SystemErrorException
	 *                例外記述：DB接続マネージャの接続でタイムアウトが発生した場合
	 */
	public int executeUpdate() throws SQLException {

		return (sqlStmt.executeUpdate());

	}

	/**
	 * ResultSetクラスのfindColumnメソッドを実行する。
	 *
	 * @return int 列番号
	 * @param colName
	 *            java.lang.String 検索する列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int findColumn(java.lang.String colName) throws SQLException {

		return (sqlResult.findColumn(colName));

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが有効な行にある場合は true、結果セットに行がない場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean first() throws java.sql.SQLException {

		return (sqlResult.first());

	}

	/**
	 * DB接続を解放する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 *                例外記述：接続マネージャでのエラーが発生した場合
	 */
	public void freeConnection() throws SQLException {

		if (sqlStmt != null) {
			close();
		}
		if (conn != null) {
			conn.close();
			conn = null;
		}
	}

	/**
	 * ResultSetクラスのgetAsciiStreamメソッドを実行する。
	 *
	 * @return java.io.InputStream 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.io.InputStream getAsciiStream(int index) throws SQLException {

		return (sqlResult.getAsciiStream(index));

	}

	/**
	 * ResultSetクラスのgetAsciiStreamメソッドを実行する。
	 *
	 * @return java.io.InputStream 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.io.InputStream getAsciiStream(java.lang.String colName) throws SQLException {

		return (sqlResult.getAsciiStream(colName));

	}

	/**
	 * ConnectionクラスのgetAutoCommitメソッドを実行する。
	 *
	 * @return boolean 現在の設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public boolean getAutoCommit() throws SQLException {

		return (conn.getAutoCommit());

	}

	/**
	 * ResultSetクラスのgetBigDecimalメソッドを実行する。
	 *
	 * @return java.math.BigDecimal 全精度の列値。値が SQL NULL の場合、返される値は Java
	 *         プログラミング言語の null
	 * @param index
	 *            int 最初の列は 1、2 番目の列は 2、などとする
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.math.BigDecimal getBigDecimal(int index) throws SQLException {

		return (sqlResult.getBigDecimal(index));

	}

	/**
	 * ResultSetクラスのgetBigDecimalメソッドを実行する。
	 *
	 * @return java.math.BigDecimal 全精度の列値。値が SQL NULL の場合、返される値は Java
	 *         プログラミング言語の null
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.math.BigDecimal getBigDecimal(java.lang.String colName) throws SQLException {

		return (sqlResult.getBigDecimal(colName));

	}

	/**
	 * ResultSetクラスのgetBinaryStreamメソッドを実行する。
	 *
	 * @return java.io.InputStream 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.io.InputStream getBinaryStream(int index) throws SQLException {

		return (sqlResult.getBinaryStream(index));

	}

	/**
	 * ResultSetクラスのgetBinaryStreamメソッドを実行する。
	 *
	 * @return java.io.InputStream 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.io.InputStream getBinaryStream(java.lang.String colName) throws SQLException {

		return (sqlResult.getBinaryStream(colName));

	}

	/**
	 * ResultSetクラスのgetBooleanメソッドを実行する。
	 *
	 * @return boolean 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public boolean getBoolean(int index) throws SQLException {

		return (sqlResult.getBoolean(index));

	}

	/**
	 * ResultSetクラスのgetBooleanメソッドを実行する。
	 *
	 * @return boolean 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public boolean getBoolean(java.lang.String colName) throws SQLException {

		return (sqlResult.getBoolean(colName));

	}

	/**
	 * ResultSetクラスのgetByteメソッドを実行する。
	 *
	 * @return byte 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public byte getByte(int index) throws SQLException {

		return (sqlResult.getByte(index));

	}

	/**
	 * ResultSetクラスのgetByteメソッドを実行する。
	 *
	 * @return byte 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public byte getByte(java.lang.String colName) throws SQLException {

		return (sqlResult.getByte(colName));

	}

	/**
	 * ResultSetクラスのgetBytesメソッドを実行する。
	 *
	 * @return byte[] 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public byte[] getBytes(int index) throws SQLException {

		return (sqlResult.getBytes(index));

	}

	/**
	 * ResultSetクラスのgetBytesメソッドを実行する。
	 *
	 * @return byte[] 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public byte[] getBytes(java.lang.String colName) throws SQLException {

		return (sqlResult.getBytes(colName));

	}

	/**
	 * ConnectionクラスのgetCatalogメソッドを実行する。
	 *
	 * @return java.lang.String 現在のカタログ名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.lang.String getCatalog() throws SQLException {

		return (conn.getCatalog());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return java.io.Reader 列の値
	 * @param columnIndex
	 *            int 最初の列は 1、2 番目の列は 2、などとする
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public java.io.Reader getCharacterStream(int columnIndex) throws java.sql.SQLException {

		return (sqlResult.getCharacterStream(columnIndex));

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return java.io.Reader 列の値
	 * @param columnName
	 *            java.lang.String 列の名前
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public java.io.Reader getCharacterStream(String columnName) throws java.sql.SQLException {

		return (sqlResult.getCharacterStream(columnName));

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int 並行処理の種類。CONCUR_READ_ONLY または CONCUR_UPDATABLE
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getConcurrency() throws java.sql.SQLException {

		return (sqlResult.getConcurrency());

	}

	/**
	 * プロパティに設定された情報でDB接続を取得する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外記述：システムエラーが発生した場合
	 */
	public void getConnection() throws SQLException, SystemErrorException {

		getConnection(fieldJdbcUrl, fieldJdbcUserID, fieldJdbcPassword);

	}

	/**
	 * DB接続を取得する。
	 *
	 * @param url
	 *            java.lang.String JDBC URL
	 * @param userid
	 *            java.lang.String JDBC ユーザーID
	 * @param password
	 *            java.lang.String JDBC パスワード
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外記述：システムエラーが発生した場合
	 */
	public void getConnection(java.lang.String url, java.lang.String userid, java.lang.String password)
			throws SQLException, SystemErrorException {

		if (fieldUseConnMgr) {

			Hashtable parms = new Hashtable();
			parms.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.ejs.ns.jndi.CNInitialContextFactory");

			try {
				Context ctx = new InitialContext(parms);
				ds = (DataSource) ctx.lookup("jdbc/dedb01");
			} catch (NamingException ne) {
				throw new SystemErrorException(ne);
			}
			conn = ds.getConnection(userid, password);

		} else {

			conn = DriverManager.getConnection(url, userid, password);
		}
	}

	/**
	 * ResultSetクラスのgetCursorNameメソッドを実行する。
	 *
	 * @return java.lang.String 現在のカーサー名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.lang.String getCursorName() throws SQLException {

		return (sqlResult.getCursorName());

	}

	/**
	 * ResultSetクラスのgetDateメソッドを実行する。
	 *
	 * @return java.sql.Date 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Date getDate(int index) throws SQLException {

		return (sqlResult.getDate(index));

	}

	/**
	 * ResultSetクラスのgetDateメソッドを実行する。
	 *
	 * @return java.sql.Date 列の値
	 * @param index
	 *            int 列番号
	 * @param index
	 *            java.util.Calendar 日付を作成するのに使う java.util.Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Date getDate(int index, Calendar cal) throws SQLException {

		return (sqlResult.getDate(index, cal));

	}

	/**
	 * ResultSetクラスのgetDateメソッドを実行する。
	 *
	 * @return java.sql.Date 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Date getDate(java.lang.String colName) throws SQLException {

		return (sqlResult.getDate(colName));

	}

	/**
	 * ResultSetクラスのgetDateメソッドを実行する。
	 *
	 * @return java.sql.Date 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @param index
	 *            java.util.Calendar 日付を作成するのに使う java.util.Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Date getDate(java.lang.String colName, Calendar cal) throws SQLException {

		return (sqlResult.getDate(colName, cal));

	}

	/**
	 * ConnectionクラスのgetDBMetaDataメソッドを実行する。
	 *
	 * @return java.sql.DatabaseMetaData 現在の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.DatabaseMetaData getDBMetaData() throws SQLException {

		return (conn.getMetaData());

	}

	/**
	 * ConnectionクラスのgetWarningsメソッドを実行する。
	 *
	 * @return java.sql.SQLWarning 現在の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.SQLWarning getDBWarnings() throws SQLException {

		return conn.getWarnings();

	}

	/**
	 * ResultSetクラスのgetDoubleメソッドを実行する。
	 *
	 * @return double 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public double getDouble(int index) throws SQLException {

		return (sqlResult.getDouble(index));

	}

	/**
	 * ResultSetクラスのgetDoubleメソッドを実行する。
	 *
	 * @return double 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public double getDouble(java.lang.String colName) throws SQLException {

		return (sqlResult.getDouble(colName));

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int この Statement オブジェクトから生成された結果セットのデフォルトのフェッチ方向
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getFetchDirection() throws java.sql.SQLException {

		return (sqlStmt.getFetchDirection());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int この Statement オブジェクトから生成された結果セットのデフォルトのフェッチサイズ
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getFetchSize() throws java.sql.SQLException {

		return (sqlStmt.getFetchSize());

	}

	/**
	 * ResultSetクラスのgetFloatメソッドを実行する。
	 *
	 * @return float 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public float getFloat(int index) throws SQLException {

		return (sqlResult.getFloat(index));

	}

	/**
	 * ResultSetクラスのgetFloatメソッドを実行する。
	 *
	 * @return float 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public float getFloat(java.lang.String colName) throws SQLException {

		return (sqlResult.getFloat(colName));

	}

	/**
	 * ResultSetクラスのgetIntメソッドを実行する。
	 *
	 * @return int 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int getInt(int index) throws SQLException {

		return (sqlResult.getInt(index));

	}

	/**
	 * ResultSetクラスのgetIntメソッドを実行する。
	 *
	 * @return int 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int getInt(java.lang.String colName) throws SQLException {

		return (sqlResult.getInt(colName));

	}

	/**
	 * jdbcDriverName プロパティー (java.lang.String) 値を取得する。
	 *
	 * @return jdbcDriverName プロパティーの値。
	 * @see #setJdbcDriverName
	 */
	public String getJdbcDriverName() {
		return fieldJdbcDriverName;
	}

	/**
	 * jdbcPassword プロパティー (java.lang.String) 値を取得する。
	 *
	 * @return jdbcPassword プロパティーの値。
	 * @see #setJdbcPassword
	 */
	public String getJdbcPassword() {
		return fieldJdbcPassword;
	}

	/**
	 * jdbcUrl プロパティー (java.lang.String) 値を取得する。
	 *
	 * @return jdbcUrl プロパティーの値。
	 * @see #setJdbcUrl
	 */
	public String getJdbcUrl() {
		return fieldJdbcUrl;
	}

	/**
	 * jdbcUserID プロパティー (java.lang.String) 値を取得する。
	 *
	 * @return jdbcUserID プロパティーの値。
	 * @see #setJdbcUserID
	 */
	public String getJdbcUserID() {
		return fieldJdbcUserID;
	}

	/**
	 * ResultSetクラスのgetLongメソッドを実行する。
	 *
	 * @return long 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public long getLong(int index) throws SQLException {

		return (sqlResult.getLong(index));

	}

	/**
	 * ResultSetクラスのgetLongメソッドを実行する。
	 *
	 * @return long 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public long getLong(java.lang.String colName) throws SQLException {

		return (sqlResult.getLong(colName));

	}

	/**
	 * PreparedStatementクラスのgetMaxFieldSizeメソッドを実行する。
	 *
	 * @return int 最大フィールドサイズの制限値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int getMaxFieldSize() throws SQLException {

		return (sqlStmt.getMaxFieldSize());

	}

	/**
	 * PreparedStatementクラスのgetMaxFieldSizeメソッドを実行する。
	 *
	 * @return int 最大行数の制限値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int getMaxRows() throws SQLException {

		return (sqlStmt.getMaxRows());

	}

	/**
	 * ResultSetクラスのgetMetaDataメソッドを実行する。
	 *
	 * @return java.sql.ResultSetMetaData ResultSetMetaDataオブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.ResultSetMetaData getMetaData() throws SQLException {

		return (sqlResult.getMetaData());

	}

	/**
	 * ResultSetクラスのgetObjectメソッドを実行する。
	 *
	 * @return java.lang.Object 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public Object getObject(int index) throws SQLException {

		return (sqlResult.getObject(index));

	}

	/**
	 * ResultSetクラスのgetObjectメソッドを実行する。
	 *
	 * @return java.lang.Object 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public Object getObject(java.lang.String colName) throws SQLException {

		return (sqlResult.getObject(colName));

	}

	/**
	 * PreparedStatementクラスのgetQueryTimeoutメソッドを実行する。
	 *
	 * @return int 照会タイムアウトの制限値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int getQueryTimeout() throws SQLException {

		return (sqlStmt.getQueryTimeout());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int ResultSet.CONCUR_READ_ONLY または ResultSet.CONCUR_UPDATABLE
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getResultSetConcurrency() throws java.sql.SQLException {

		return (sqlStmt.getResultSetConcurrency());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int
	 *         ResultSet.TYPE_FORWARD_ONLY、ResultSet.TYPE_SCROLL_INSENSITIVE、または
	 *         <BR>
	 *         ResultSet.TYPE_SCROLL_SENSITIVE のうちの 1 つ
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getResultSetType() throws java.sql.SQLException {

		return (sqlStmt.getResultSetType());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int 現在の行の番号。現在の行がない場合は 0
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getRow() throws java.sql.SQLException {

		return (sqlResult.getRow());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int この Statement オブジェクトから生成された結果セットのデフォルトのフェッチ方向
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getRSFetchDirection() throws java.sql.SQLException {

		return (sqlResult.getFetchDirection());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int この Statement オブジェクトから生成された結果セットのデフォルトのフェッチサイズ
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getRSFetchSize() throws java.sql.SQLException {

		return (sqlResult.getFetchSize());

	}

	/**
	 * ResultSetクラスのgetWarningsメソッドを実行する。
	 *
	 * @return java.sql.SQLWarning 現在の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.SQLWarning getRSWarnings() throws SQLException {

		return (sqlResult.getWarnings());

	}

	/**
	 * ResultSetクラスのgetShortメソッドを実行する。
	 *
	 * @return short 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public short getShort(int index) throws SQLException {

		return (sqlResult.getShort(index));

	}

	/**
	 * ResultSetクラスのgetShortメソッドを実行する。
	 *
	 * @return short 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public short getShort(java.lang.String colName) throws SQLException {

		return (sqlResult.getShort(colName));

	}

	/**
	 * ResultSetクラスのgetStringメソッドを実行する。
	 *
	 * @return java.lang.String 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.lang.String getString(int index) throws SQLException {

		return (sqlResult.getString(index));

	}

	/**
	 * ResultSetクラスのgetStringメソッドを実行する。
	 *
	 * @return java.lang.String 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.lang.String getString(java.lang.String colName) throws SQLException {

		return (sqlResult.getString(colName));

	}

	/**
	 * ResultSetクラスのgetTimeメソッドを実行する。
	 *
	 * @return java.sql.Time 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Time getTime(int index) throws SQLException {

		return (sqlResult.getTime(index));

	}

	/**
	 * ResultSetクラスのgetTimeメソッドを実行する。
	 *
	 * @return java.sql.Time 列の値
	 * @param index
	 *            int 列番号
	 * @param index
	 *            java.util.Calendar 時刻を作成するのに使う java.util.Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Time getTime(int index, Calendar cal) throws SQLException {

		return (sqlResult.getTime(index, cal));

	}

	/**
	 * ResultSetクラスのgetTimeメソッドを実行する。
	 *
	 * @return java.sql.Time 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Time getTime(java.lang.String colName) throws SQLException {

		return (sqlResult.getTime(colName));

	}

	/**
	 * ResultSetクラスのgetTimeメソッドを実行する。
	 *
	 * @return java.sql.Time 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @param index
	 *            java.util.Calendar 時刻を作成するのに使う java.util.Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Time getTime(java.lang.String colName, Calendar cal) throws SQLException {

		return (sqlResult.getTime(colName, cal));

	}

	/**
	 * ResultSetクラスのgetTimestampメソッドを実行する。
	 *
	 * @return java.sql.Timestamp 列の値
	 * @param index
	 *            int 列番号
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Timestamp getTimestamp(int index) throws SQLException {

		return (sqlResult.getTimestamp(index));

	}

	/**
	 * ResultSetクラスのgetTimestampメソッドを実行する。
	 *
	 * @return java.sql.Timestamp 列の値
	 * @param index
	 *            int 列番号
	 * @param index
	 *            java.util.Calendar タイムスタンプを作成するのに使う java.util.Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Timestamp getTimestamp(int index, Calendar cal) throws SQLException {

		return (sqlResult.getTimestamp(index, cal));

	}

	/**
	 * ResultSetクラスのgetTimestampメソッドを実行する。
	 *
	 * @return java.sql.Timestamp 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Timestamp getTimestamp(java.lang.String colName) throws SQLException {

		return (sqlResult.getTimestamp(colName));

	}

	/**
	 * ResultSetクラスのgetTimestampメソッドを実行する。
	 *
	 * @return java.sql.Timestamp 列の値
	 * @param colName
	 *            java.lang.String 列名
	 * @param index
	 *            java.util.Calendar タイムスタンプを作成するのに使う java.util.Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.Timestamp getTimestamp(java.lang.String colName, Calendar cal) throws SQLException {

		return (sqlResult.getTimestamp(colName, cal));

	}

	/**
	 * ConnectionクラスのgetTransactionIsolationメソッドを実行する。
	 *
	 * @return int 現在の設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public int getTransactionIsolation() throws SQLException {

		return (conn.getTransactionIsolation());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return int TYPE_FORWARD_ONLY、TYPE_SCROLL_INSENSITIVE、または
	 *         TYPE_SCROLL_SENSITIVE
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public int getType() throws java.sql.SQLException {

		return (sqlResult.getType());

	}

	/**
	 * useConnMgr プロパティー (boolean) 値を取得する。
	 *
	 * @return useConnMgr プロパティーの値。
	 * @see #setUseConnMgr
	 */
	public boolean getUseConnMgr() {
		return fieldUseConnMgr;
	}

	/**
	 * PreparedStatementクラスのgetWarningsメソッドを実行する。
	 *
	 * @return java.sql.SQLWarning 現在の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public java.sql.SQLWarning getWarnings() throws SQLException {

		return (sqlStmt.getWarnings());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが最終行より後ろにある場合は true、カーソルが他の位置にあるか、結果セットに行がない場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean isAfterLast() throws java.sql.SQLException {

		return (sqlResult.isAfterLast());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが先頭行より前にある場合は true、カーソルが他の位置にあるか、結果セットに行がない場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean isBeforeFirst() throws java.sql.SQLException {

		return (sqlResult.isBeforeFirst());

	}

	/**
	 * ConnectionクラスのisClosedメソッドを実行する。
	 *
	 * @return boolean 現在の設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public boolean isClosed() throws SQLException {
		return (conn.isClosed());
	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが先頭行にある場合は true、そうでない場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean isFirst() throws java.sql.SQLException {

		return (sqlResult.isFirst());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが最終行にある場合は true、そうでない場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean isLast() throws java.sql.SQLException {

		return (sqlResult.isLast());

	}

	/**
	 * ConnectionクラスのisReadOnlyメソッドを実行する。
	 *
	 * @return boolean 現在の設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public boolean isReadOnly() throws SQLException {

		return (conn.isReadOnly());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが有効な行にある場合は true、結果セットに行がない場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean last() throws java.sql.SQLException {

		return (sqlResult.last());

	}

	/**
	 * ResultSetクラスのnextメソッドを実行する。
	 *
	 * @return boolean 現在の位置づけ結果
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public boolean next() throws SQLException {

		return (sqlResult.next());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが有効な行にある場合は true、結果セットの外にある場合は false
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean previous() throws java.sql.SQLException {

		return (sqlResult.previous());

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void refreshRow() throws java.sql.SQLException {

		sqlResult.refreshRow();

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @return boolean カーソルが行にある場合は true、そうでない場合は false
	 * @param row
	 *            int
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public boolean relative(int row) throws java.sql.SQLException {

		return (sqlResult.relative(row));

	}

	/**
	 * Connectionクラスのrollbackメソッドを実行する。
	 *
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void rollback() throws SQLException {

		if (conn != null) {
			conn.rollback();
		}

	}

	/**
	 * PreparedStatementクラスのsetAsciiStreamメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.io.InputStream 列の値
	 * @param len
	 *            int 長さ
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setAsciiStream(int index, java.io.InputStream val, int len) throws SQLException {

		sqlStmt.setAsciiStream(index, val, len);

	}

	/**
	 * ConnectionクラスのsetAutoCommitメソッドを実行する。
	 *
	 * @param val
	 *            boolean 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setAutoCommit(boolean val) throws SQLException {

		conn.setAutoCommit(val);

	}

	/**
	 * PreparedStatementクラスのsetBigDecimalメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.math.BigDecimal 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setBigDecimal(int index, java.math.BigDecimal val) throws SQLException {

		sqlStmt.setBigDecimal(index, val);

	}

	/**
	 * PreparedStatementクラスのsetBinaryStreamメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.io.InputStream 列の値
	 * @param len
	 *            int 長さ
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setBinaryStream(int index, java.io.InputStream val, int len) throws SQLException {

		sqlStmt.setBinaryStream(index, val, len);

	}

	/**
	 * PreparedStatementクラスのsetBooleanメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            boolean 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setBoolean(int index, boolean val) throws SQLException {

		sqlStmt.setBoolean(index, val);

	}

	/**
	 * PreparedStatementクラスのsetByteメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            byte 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setByte(int index, byte val) throws SQLException {

		sqlStmt.setByte(index, val);

	}

	/**
	 * PreparedStatementクラスのsetBytesメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            byte[] 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setBytes(int index, byte val[]) throws SQLException {

		sqlStmt.setBytes(index, val);

	}

	/**
	 * ConnectionクラスのsetCatalogメソッドを実行する。
	 *
	 * @param val
	 *            java.lang.String 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setCatalog(java.lang.String val) throws SQLException {

		conn.setCatalog(val);

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @param parameterIndex
	 *            int
	 * @param reader
	 *            java.io.Reader
	 * @param length
	 *            int
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void setCharacterStream(int parameterIndex, java.io.Reader reader, int length) throws java.sql.SQLException {

		sqlStmt.setCharacterStream(parameterIndex, reader, length);

	}

	/**
	 * PreparedStatementクラスのsetCursorNameメソッドを実行する。
	 *
	 * @param val
	 *            java.lang.String 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setCursorName(java.lang.String val) throws SQLException {

		sqlStmt.setCursorName(val);

	}

	/**
	 * PreparedStatementクラスのsetDateメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.sql.Date 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setDate(int index, java.sql.Date val) throws SQLException {

		sqlStmt.setDate(index, val);

	}

	/**
	 * PreparedStatementクラスのsetDateメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.sql.Date 列の値
	 * @param cal
	 *            java.util.Calendar ドライバが日付を作成するために使用する Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setDate(int index, java.sql.Date val, Calendar cal) throws SQLException {

		sqlStmt.setDate(index, val, cal);

	}

	/**
	 * PreparedStatementクラスのsetDoubleメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            double 列の値
	 * @param val
	 *            java.sql.Date
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setDouble(int index, double val) throws SQLException {

		sqlStmt.setDouble(index, val);

	}

	/**
	 * PreparedStatementクラスのsetEscapeProcessingメソッドを実行する。
	 *
	 * @param val
	 *            boolean 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setEscapeProcessing(boolean val) throws SQLException {

		sqlStmt.setEscapeProcessing(val);

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @param direction
	 *            int 行を処理する初期方向
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void setFetchDirection(int direction) throws java.sql.SQLException {

		sqlStmt.setFetchDirection(direction);

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @param rows
	 *            int フェッチする行数
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void setFetchSize(int rows) throws java.sql.SQLException {

		sqlStmt.setFetchSize(rows);

	}

	/**
	 * PreparedStatementクラスのsetFloatメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            float 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setFloat(int index, float val) throws SQLException {

		sqlStmt.setFloat(index, val);

	}

	/**
	 * PreparedStatementクラスのsetIntメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            int 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setInt(int index, int val) throws SQLException {

		sqlStmt.setInt(index, val);

	}

	/**
	 * jdbcDriverName プロパティー (java.lang.String) 値を設定する。
	 *
	 * @param jdbcDriverName
	 *            プロパティーの新しい値です。
	 * @see #getJdbcDriverName
	 */
	public void setJdbcDriverName(String jdbcDriverName) {
		fieldJdbcDriverName = jdbcDriverName;
	}

	/**
	 * jdbcPassword プロパティー (java.lang.String) 値を設定する。
	 *
	 * @param jdbcPassword
	 *            プロパティーの新しい値です。
	 * @see #getJdbcPassword
	 */
	public void setJdbcPassword(String jdbcPassword) {
		fieldJdbcPassword = jdbcPassword;
	}

	/**
	 * jdbcUrl プロパティー (java.lang.String) 値を設定する。
	 *
	 * @param jdbcUrl
	 *            プロパティーの新しい値です。
	 * @see #getJdbcUrl
	 */
	public void setJdbcUrl(String jdbcUrl) {
		fieldJdbcUrl = jdbcUrl;
	}

	/**
	 * jdbcUserID プロパティー (java.lang.String) 値を設定する。
	 *
	 * @param jdbcUserID
	 *            プロパティーの新しい値です。
	 * @see #getJdbcUserID
	 */
	public void setJdbcUserID(String jdbcUserID) {
		fieldJdbcUserID = jdbcUserID;
	}

	/**
	 * PreparedStatementクラスのsetLongメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            long 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setLong(int index, long val) throws SQLException {

		sqlStmt.setLong(index, val);

	}

	/**
	 * PreparedStatementクラスのsetMaxFieldSizeメソッドを実行する。
	 *
	 * @param maxVal
	 *            int 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setMaxFieldSize(int maxVal) throws SQLException {

		sqlStmt.setMaxFieldSize(maxVal);

	}

	/**
	 * PreparedStatementクラスのsetMaxRowsメソッドを実行する。
	 *
	 * @param maxVal
	 *            int 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setMaxRows(int maxVal) throws SQLException {

		sqlStmt.setMaxRows(maxVal);

	}

	/**
	 * PreparedStatementクラスのsetNullメソッドを実行する。
	 *
	 * @param sqlType
	 *            int 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setNull(int index, int sqlType) throws SQLException {

		sqlStmt.setNull(index, sqlType);

	}

	/**
	 * PreparedStatementクラスのsetObjectメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param inType
	 *            java.lang.Object 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setObject(int index, Object inType) throws SQLException {

		sqlStmt.setObject(index, inType);

	}

	/**
	 * PreparedStatementクラスのsetObjectメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param inType
	 *            java.lang.Object 列の値
	 * @param destType
	 *            int 列タイプ
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setObject(int index, Object inType, int destType) throws SQLException {

		sqlStmt.setObject(index, inType, destType);

	}

	/**
	 * PreparedStatementクラスのsetObjectメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param inType
	 *            java.lang.Object 列の値
	 * @param destType
	 *            int 列タイプ
	 * @param scale
	 *            int 精度
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setObject(int index, Object inType, int destType, int scale) throws SQLException {

		sqlStmt.setObject(index, inType, destType, scale);

	}

	/**
	 * PreparedStatementクラスのsetQueryTimeoutメソッドを実行する。
	 *
	 * @param val
	 *            int 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setQueryTimeout(int val) throws SQLException {

		sqlStmt.setQueryTimeout(val);

	}

	/**
	 * ConnectionクラスのsetReadOnlyメソッドを実行する。
	 *
	 * @param val
	 *            boolean 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setReadOnly(boolean val) throws SQLException {

		conn.setReadOnly(val);

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @param direction
	 *            int 行を処理する初期方向
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void setRSFetchDirection(int direction) throws java.sql.SQLException {

		sqlResult.setFetchDirection(direction);

	}

	/**
	 * \ッドの記述を挿入してください。
	 *
	 * @param rows
	 *            int フェッチする行数
	 * @exception java.sql.SQLException
	 *                例外記述
	 */
	public void setRSFetchSize(int rows) throws java.sql.SQLException {

		sqlResult.setFetchSize(rows);

	}

	/**
	 * PreparedStatementクラスのsetShortメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            short 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setShort(int index, short val) throws SQLException {

		sqlStmt.setShort(index, val);

	}

	/**
	 * プロパティの設定を使用してSQL文を実行可能状態にする。
	 *
	 * @param sql
	 *            java.lang.String SQL
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外記述：システムエラーが発生した場合
	 */
	public void setSQL(java.lang.String sql) throws SQLException, SystemErrorException {

		setSQL(sql, fieldJdbcUrl, fieldJdbcUserID, fieldJdbcPassword);

	}

	/**
	 * プロパティの設定を使用してSQL文を実行可能状態にする。
	 *
	 * @param sql
	 *            java.lang.String SQL
	 * @param int
	 *            resultSetType 結果セットのタイプ。ResultSet.TYPE_XXX を参照
	 * @param int
	 *            resultSetConcurrency 並行処理の種類。ResultSet.CONCUR_XXX を参照
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外記述：システムエラーが発生した場合
	 */
	public void setSQL(java.lang.String sql, int resultSetType, int resultSetConcurrency)
			throws SQLException, SystemErrorException {

		setSQL(sql, fieldJdbcUrl, fieldJdbcUserID, fieldJdbcPassword, resultSetType, resultSetConcurrency);

	}

	/**
	 * SQL文を実行可能状態にする。
	 *
	 * @param sql
	 *            java.lang.String SQL
	 * @param url
	 *            java.lang.String JDBC URL
	 * @param userid
	 *            java.lang.String JDBC ユーザーID
	 * @param password
	 *            java.lang.String JDBC パスワード
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外記述：システムエラーが発生した場合
	 */
	public void setSQL(String sql, String url, String userid, String password)
			throws SQLException, SystemErrorException {

		try {
			if (conn == null) {
				getConnection(url, userid, password);
			}
			if (sqlStmt != null) {
				close();
			}
			sqlStmt = conn.prepareStatement(sql);
			// Logger.L5.writeLog("set sql:" + sql);

		} catch (SQLException e) {

			sqlStmt = null;
			throw e;
		}

	}

	/**
	 * SQL文を実行可能状態にする。
	 *
	 * @param sql
	 *            java.lang.String SQL
	 * @param url
	 *            java.lang.String JDBC URL
	 * @param userid
	 *            java.lang.String JDBC ユーザーID
	 * @param password
	 *            java.lang.String JDBC パスワード
	 * @param int
	 *            resultSetType 結果セットのタイプ。ResultSet.TYPE_XXX を参照
	 * @param int
	 *            resultSetConcurrency 並行処理の種類。ResultSet.CONCUR_XXX を参照
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外記述：システムエラーが発生した場合
	 */
	public void setSQL(String sql, String url, String userid, String password, int resultSetType,
			int resultSetConcurrency) throws SQLException, SystemErrorException {

		try {
			if (conn == null) {
				getConnection(url, userid, password);
			}
			if (sqlStmt != null) {
				close();
			}
			sqlStmt = conn.prepareStatement(sql, resultSetType, resultSetConcurrency);
			// Logger.L5.writeLog("set sql:" + sql);

		} catch (SQLException e) {

			sqlStmt = null;
			throw e;
		}

	}

	/**
	 * PreparedStatementクラスのsetStringメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.lang.String 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setString(int index, java.lang.String val) throws SQLException {

		sqlStmt.setString(index, val);

	}

	/**
	 * PreparedStatementクラスのsetTimeメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.sql.Time 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setTime(int index, java.sql.Time val) throws SQLException {

		sqlStmt.setTime(index, val);

	}

	/**
	 * PreparedStatementクラスのsetTimeメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.sql.Time 列の値
	 * @param cal
	 *            java.util.Calendar ドライバが時間を作成するために使用する Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setTime(int index, java.sql.Time val, Calendar cal) throws SQLException {

		sqlStmt.setTime(index, val, cal);

	}

	/**
	 * PreparedStatementクラスのsetTimestampメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.sql.Timestamp 列の値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setTimestamp(int index, java.sql.Timestamp val) throws SQLException {

		sqlStmt.setTimestamp(index, val);

	}

	/**
	 * PreparedStatementクラスのsetTimestampメソッドを実行する。
	 *
	 * @param index
	 *            int 列番号
	 * @param val
	 *            java.sql.Timestamp 列の値
	 * @param cal
	 *            java.util.Calendar ドライバがタイムスタンプを作成するために使用する Calendar オブジェクト
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setTimestamp(int index, java.sql.Timestamp val, Calendar cal) throws SQLException {

		sqlStmt.setTimestamp(index, val, cal);

	}

	/**
	 * ConnectionクラスのsetTransactionIsolationメソッドを実行する。
	 *
	 * @param val
	 *            int 設定値
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public void setTransactionIsolation(int val) throws SQLException {

		conn.setTransactionIsolation(val);

	}

	/**
	 * useConnMgr プロパティー (boolean) 値を設定する。
	 *
	 * @param useConnMgr
	 *            プロパティーの新しい値です。
	 * @see #getUseConnMgr
	 */
	public void setUseConnMgr(boolean useConnMgr) {
		fieldUseConnMgr = useConnMgr;
	}

	/**
	 * ResultSetクラスのwasNullメソッドを実行する。
	 *
	 * @return boolean 結果
	 * @exception java.sql.SQLException
	 *                例外記述：SQLエラーが発生した場合
	 */
	public boolean wasNull() throws SQLException {

		return (sqlResult.wasNull());

	}


	public ResultSet getResultset() throws SQLException {

		return (sqlResult);

	}



	/**
	 * テストドライバ
	 *
	 * @see "\src\fj.properties"
	 */
	public static void main(String[] args) {

		JDBCUtil2 jdbc = null;
		String jdbcurl = null;
		try {
			jdbc = new JDBCUtil2();

			jdbcurl = jdbc.getJdbcUrl();
			System.out.println("jdbcurl = " + jdbcurl);

			// コネクション確立
			jdbc.getConnection();

			// SQL
			String sql = " SELECT AADCYOCD, AADCYONM, AADSEDAI FROM TAAD000 ";
			StringBuffer sb = new StringBuffer(sql);

			int index = 1;
			jdbc.setSQL(sb.toString());
			// 実行
			jdbc.executeQuery();

			// 結果
			int i = 0;
			while (jdbc.next()) {
				i++;
				System.out.println(" i = " + i);
				System.out.println("[1] = " + jdbc.getString("AADCYOCD").trim());
				System.out.println("[2] = " + jdbc.getString("AADCYONM").trim());
				System.out.println("[3] = " + jdbc.getString("AADSEDAI").trim());

				// TEDB000 edb = new TEDB000();
				//
				// if (JUtil.getString("1") != null) // 委託者ｺｰﾄﾞ
				// edb.setITKCD(JUtil.getString("1").trim());
				//
				// if (JUtil.getDate("2") != null) // 指定日
				// edb.setFRIDT(df.format(JUtil.getDate("2")));
				//
				// edb.setTSUBN(String.valueOf(JUtil.getInt("3"))); // 通番
				//
				// records.addElement(edb);
			}
			// } catch (SQLException e) {
			// throw new SystemErrorException(e);
			// }

			jdbc.close();

		} catch (java.sql.SQLException sqle) {

			String className = Thread.currentThread().getStackTrace()[1].getClassName() ;
			String msg = new String(className + " : " + "SQLの実行エラー "  + sqle.getMessage() );
			FjLog.error(msg);
			System.err.println(msg);
			sqle.printStackTrace();



		} catch (Exception e) {
			String message = "Exception..";
			System.out.println(message);
		} finally {
			System.out.println("jdbcurl = " + jdbcurl);
			try {
				if (jdbc != null) {
					jdbc.close();
					jdbc = null;
				}
			} catch (java.sql.SQLException sqle) {
			}
			String message = "End...";
			System.out.println(message);
		}

	}
}
