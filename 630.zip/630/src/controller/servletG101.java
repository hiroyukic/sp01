package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.beanTAAAwithTAAD;
import fw.FjLog;
import model.TblTAAA000;
import net.arnx.jsonic.JSON;
import sv.DownloadFileInfo;
import sv.SetDownloadFileInfo;

/**
 * Servlet implementation class servletG100
 */
@WebServlet("/servletG101")
public class servletG101 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String REQUEST_STRING = "requestJs";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletG101() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		// TODO Auto-generated method stub
		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());

		String parameter = request.getParameter(REQUEST_STRING);
		System.out.println(parameter);

		// MessageBean bean = JSON.decode(parameter, MessageBean.class);

		// String me =
		// "{'age':28,'interests':['running','programming'],'name':'sho322'}";
		// Person myPerson = JSON.decode(me, Person.class);

		//////////////////////////////////////////////////////////////////////////////
		TblTAAA000 TAAA;
		ArrayList<beanTAAAwithTAAD> beans = null;
		try {
			TAAA = new TblTAAA000();
			// 検索：「受信一覧情報」
			beans = TAAA.findWithTAAD("3003", "001");
		} catch (Exception e) {
			e.printStackTrace();
			String msg = new String("servletG100 : " + "Excpetion[70]=" + e.toString());
			FjLog.error(msg);
			throw new ServletException(e);
		} finally {
		}

		// サーブレットに送信されたメッセージが表示される。
		// ダミー情報の生成
		SetDownloadFileInfo info = new SetDownloadFileInfo();
		ArrayList<DownloadFileInfo> alist = info.set();

		HttpSession session = request.getSession();
		session.setAttribute("beanG100", beans);

		//resultG100


	     //String jsontxt = JSON.encode(beans);



	     ///////////////////////////////////////////////
			// Beans→JSON コンバート
	     StringBuffer sbuf = new StringBuffer();
			beanTAAAwithTAAD bean = null;
			for (int i = 0; i < beans.size(); i++) {
				bean = (beanTAAAwithTAAD) beans.get(i);
				// POJOをJSONに変換。戻り値 (例） {"number":10,"string":"aaa","array":[1,2,3]}
				String text = JSON.encode(bean);
				sbuf.append(text);
			}
		//System.out.println("sbuf.tostring =" + sbuf.toString());

	     String jsontxt = sbuf.toString();







		//String responseJson = "{\"responseMessage\" : \"サーブレットからの返信ですxxxxxxxx\"}";
		//String responseJson = jsontxt;

	     String responseJson =  "[ { \"name\": \"Tiger Nixon\", \"position\": \"System Architect\", \"salary\": \"$320,800\", \"start_date\": \"2011/04/25\", \"office\": \"Edinburgh\", \"extn\": \"5421\" }, { \"name\": \"Garrett Winters\", \"position\": \"Accountant\", \"salary\": \"$170,750\", \"start_date\": \"2011/07/25\", \"office\": \"Tokyo\", \"extn\": \"8422\" }, { \"name\": \"Michael Bruce\", \"position\": \"Javascript Developer\", \"salary\": \"$183,000\", \"start_date\": \"2011/06/27\", \"office\": \"Singapore\", \"extn\": \"5384\" }, { \"name\": \"Donna Snider\", \"position\": \"Customer Support\", \"salary\": \"$112,000\", \"start_date\": \"2011/01/25\", \"office\": \"New York\", \"extn\": \"4226\" } ]";






		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setContentType("application/json;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.print(responseJson);

//		RequestDispatcher dispatcher =
//		request.getRequestDispatcher("/ajax/g100.jsp");
//		dispatcher.forward(request, response);




	}




}
