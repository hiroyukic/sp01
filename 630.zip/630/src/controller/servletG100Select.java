package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.beanTAAAwithTAAD;
import fw.FjLog;
import model.Person;
import model.TblTAAA000;
import net.arnx.jsonic.JSON;
import sv.DownloadFileInfo;
import sv.SetDownloadFileInfo;
/**
 * Servlet implementation class JsonTestServlet
 */
@WebServlet("/servletG100Select")
public class servletG100Select extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String REQUEST_STRING = "requestJs";


    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletG100Select() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		String parameter = request.getParameter(REQUEST_STRING);
		System.out.println(parameter);
//		 Person me = new Person();
//	        me.setName("sho322");
//	        me.setAge(28);
//	        String[] interests = {"running","programming"};
//	        me.setInterests(interests);


		//MessageBean bean = JSON.decode(parameter, MessageBean.class);

		 String me = "{'age':28,'interests':['running','programming'],'name':'sho322'}";
	     Person myPerson = JSON.decode(me, Person.class);



	    TblTAAA000 TAAA;
		ArrayList<beanTAAAwithTAAD> beans = null;
		try {
			TAAA = new TblTAAA000(new fw.JDBCUtil());
			beans = TAAA.findWithTAAD("3003", "001");
		} catch (Exception e) {
			e.printStackTrace();
			String msg = new String("Main : " + "Excpetion[70]=" + e.toString());
			FjLog.error(msg);
			throw new ServletException(e);
		} finally {
		}



		//サーブレットに送信されたメッセージが表示される。
		//System.out.println(bean.getMessage());
	        String[] interests = myPerson.getInterests();
	        System.out.println(interests[0] + "," + interests[1]);



	        //ダミー情報の生成
	        SetDownloadFileInfo info = new SetDownloadFileInfo();
	        ArrayList<DownloadFileInfo> alist = info.set();

	        HttpSession session = request.getSession();
	        session.setAttribute("beanG100",beans);
	        session.setAttribute("beanPerson",myPerson);


		String responseJson = "{\"responseMessage\" : \"サーブレットからの返信です\"}";

		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setContentType("application/json;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.print(responseJson);

		//RequestDispatcher dispatcher = request.getRequestDispatcher("/sv/Table.jsp");
		//RequestDispatcher dispatcher = request.getRequestDispatcher("/ajax/g100.jsp");
		//dispatcher.forward(request, response);

	}




}

