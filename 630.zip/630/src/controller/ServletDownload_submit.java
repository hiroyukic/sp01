package controller;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.http.fileupload.IOUtils;

import fw.FjLog;
import fw.SystemErrorException;

import net.arnx.jsonic.JSON;


@SuppressWarnings("serial")
@WebServlet(name = "download", urlPatterns = { "/download" })
public class ServletDownload_submit extends HttpServlet {
	private final String REQUEST_STRING = "requestJs";
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String parameter = request.getParameter(REQUEST_STRING);
		//MessageBean bean = JSON.decode(parameter, MessageBean.class);
		//サーブレットに送信されたメッセージが表示される。
		//System.out.println(bean.getMessage());
		
		System.out.println(parameter);
		
		
		
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		// PrintWriter out = response.getWriter();
		String var;

		// String name = "";
		// tmp = request.getParameter("name");
		// if (tmp == null || tmp.length() == 0) {
		// name = "未設定です";
		// } else {
		// name = tmp;
		// }
		//
		// String text;
		// tmp = request.getParameter("text");
		// if (tmp == null || tmp.length() == 0) {
		// text = "未設定です";
		// } else {
		// text = tmp;
		// }

		//////////////////////////////////////////////////////
		// パラメータ取得
		//////////////////////////////////////////////////////
		String jaCode;
		var = request.getParameter("jacode");
		if (var == null || var.length() == 0) {
			jaCode = "未設定です";
		} else {
			jaCode = var;
		}

		String tempoCode;
		var = request.getParameter("tenpoCode");
		if (var == null || var.length() == 0) {
			tempoCode = "未設定です";
		} else {
			tempoCode = var;
		}

		String cyohyoCode;
		var = request.getParameter("cyohyocode");
		if (var == null || var.length() == 0) {
			cyohyoCode = "未設定です";
		} else {
			cyohyoCode = var;
		}

		String kijyunDate;
		var = request.getParameter("kijyunDate");
		if (var == null || var.length() == 0) {
			kijyunDate = "未設定です";
		} else {
			kijyunDate = var;
		}

		//////////////////////////////////////////////////////
		// ダウンロード
		//////////////////////////////////////////////////////
		try{
			boolean rt = download(response, jaCode, tempoCode, cyohyoCode, kijyunDate);
		} catch (Exception e) {
			//throw new ServletException(e);
			
			//Errorページを使用する場合
			//request.setAttribute("msg", msg);
			//RequestDispatcher dispatcher = request.getRequestDispatcher("/error_servlet.jsp");
		    //dispatcher.forward(request, response);
		}

		//HttpSession session = request.getSession();
		//request.setAttribute("beanG102", beans);

		//String responseJson = "{\"responseMessage\" : \"サーブレットからの返信ですxxxxxxxx\"}";
		//response.setHeader("Access-Control-Allow-Origin", "*");
		//response.setContentType("application/json;charset=UTF-8");
		//PrintWriter out = response.getWriter();
		//out.print(responseJson);

		//RequestDispatcher dispatcher = request.getRequestDispatcher("/ajax/g102.jsp");
		//dispatcher.forward(request, response);
		
	}

	private boolean download(HttpServletResponse response, String jaCode, String tempoCode, String cyohyoCode,
			String kijyunDate) throws IOException,SystemErrorException, ServletException {

		ServletOutputStream op = null;
		DataInputStream in = null;
		// ex. "D:/FILEROOT/HTTP/3003001/KGSDA228/KGSDA228.20150223.cab";
		String fileName = cyohyoCode + kijyunDate + ".cab";
		String filePath = "/mnt/KENGYOMU/FILEROOT/HTTP/" + jaCode + tempoCode + "/" + cyohyoCode + "/" + cyohyoCode
				+ "." + kijyunDate + ".cab";

			java.io.File file = new File(filePath);
			if (file.exists()) {
				// レスポンスヘッダーの作成
				response.setContentType("application/octet-stream");
				response.setContentLength((int) file.length());
				// ファイル名の設定ISO_8859_1にエンコード
				response.setHeader("Content-Disposition",
						"inline; filename=\"" + new String(fileName.getBytes("UTF-8"), "ISO_8859_1") + "\"");
				// ファイルの読み込み
				int bytes = 0;
				op = response.getOutputStream();
				byte[] bbuf = new byte[1024];
				in = new DataInputStream(new FileInputStream(file));
				while ((in != null) && ((bytes = in.read(bbuf)) != -1)) {
					op.write(bbuf, 0, bytes);
				}
				op.flush();
				//
				IOUtils.closeQuietly(op);
				IOUtils.closeQuietly(in);
			} else {
				System.out.println("[PostReceieve] File not found. file=" + filePath);
				String msg = "SystemError [ServletDownload.145] : DL対象ファイルにアクセスできませんでした。管理者に連絡し、「ファイル状況」、ならびに、「mount状況」の確認依頼をして下さい。";
				msg = msg + " FilePath="+ filePath;
				FjLog.error(msg);
				//20170629
				//throw new SystemErrorException(msg);
			}
		return true;
	}

}
