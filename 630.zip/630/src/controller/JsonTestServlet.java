package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Person;
import net.arnx.jsonic.JSON;
import sv.DownloadFileInfo;
import sv.SetDownloadFileInfo;
/**
 * Servlet implementation class JsonTestServlet
 */
@WebServlet("/JsonTestServlet")
public class JsonTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String REQUEST_STRING = "requestJs";


    /**
     * @see HttpServlet#HttpServlet()
     */
    public JsonTestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		String parameter = request.getParameter(REQUEST_STRING);
		System.out.println(parameter);
//		 Person me = new Person();
//	        me.setName("sho322");
//	        me.setAge(28);
//	        String[] interests = {"running","programming"};
//	        me.setInterests(interests);


		//MessageBean bean = JSON.decode(parameter, MessageBean.class);

		 String me = "{'age':28,'interests':['running','programming'],'name':'sho322'}";
	     Person myPerson = JSON.decode(me, Person.class);


		//サーブレットに送信されたメッセージが表示される。
		//System.out.println(bean.getMessage());
	        String[] interests = myPerson.getInterests();
	        System.out.println(interests[0] + "," + interests[1]);

	        //ダミー情報の生成
	        SetDownloadFileInfo info = new SetDownloadFileInfo();
	        ArrayList<DownloadFileInfo> alist = info.set();

	        HttpSession session = request.getSession();
	        session.setAttribute("bean",alist);

		//String responseJson = "{\"responseMessage\" : \"サーブレットからの返信です\"}";

		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setContentType("application/json;charset=UTF-8");

		//PrintWriter out = response.getWriter();
		//out.print(responseJson);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/sv/Table.jsp");
		dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
