package model;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import bean.beanTAAAwithTAAD;
import fw.DataSourceUtil;
import fw.FjLog;
import fw.JDBCUtil;
import fw.SystemErrorException;
import fw.UserErrorException;

//import org.json.JSONArray;
//import org.json.JSONObject;
/**
 * 「TAADB000」
 *
 * @since : (2017/04/26)
 * @author: chiba
 */
public class TblTAAA000 {
	private String CLASS_NAME = Thread.currentThread().getStackTrace()[1].getClassName();
	private JDBCUtil jUtil = null;
	private DateFormat df = new SimpleDateFormat("yyyyMMdd");
	// private DateFormat tsf = new SimpleDateFormat("yyyyMMddHHmmss");

	/**
	 * TblTAAA000
	 *
	 * @param jUtil
	 *            pjt.fw.JDBCUtil
	 * @since : (2017/06/01)
	 */
	public TblTAAA000() throws SystemErrorException {
		super();
		// try {
		// jUtil = new JDBCUtil();
		// } catch (ClassNotFoundException e) {
		// throw new SystemErrorException(e);
		// }
	}

	/**
	 * TblTAAA000
	 *
	 * @param jUtil
	 *            pjt.fw.JDBCUtil
	 * @since : (2017/06/01)
	 */
	// public TblTAAA000(JDBCUtil j) {
	// super();
	// jUtil = j;
	// }

	// DataSourceUtil ds = null;
	// Connection connection = null;
	// try {
	// // コネクション取得
	// ds = new DataSourceUtil();
	// connection = ds.getConnection();
	//
	// // SQL
	// String sql = " SELECT AADCYOCD, AADCYONM, AADSEDAI FROM TAAD000 ";
	// StringBuffer sb = new StringBuffer(sql);
	//
	//
	// PreparedStatement statement = connection.prepareStatement(sql);
	//
	// // 実行
	// ResultSet rs = statement.executeQuery();
	//
	// // 結果
	// int i = 0;
	// while (rs.next()) {
	// i++;
	// System.out.println(" i = " + i);
	// System.out.println("[1] = " + rs.getString("AADCYOCD").trim());
	// System.out.println("[2] = " + rs.getString("AADCYONM").trim());
	// System.out.println("[3] = " + rs.getString("AADSEDAI").trim());
	// }
	//
	// // コネクション・クローズ
	// connection.close();
	//
	// } catch (Exception e) {
	// String className =
	// Thread.currentThread().getStackTrace()[1].getClassName() ;
	// String msg = new String(className + " : " + "SQLの実行エラー " + e.getMessage()
	// );
	// FjLog.error(msg);
	// System.err.println(msg);
	// e.printStackTrace();
	// } finally {
	// System.out.println("jdbcurl = " );
	// try {
	// if (connection != null) {
	// connection.close();
	// connection = null;
	// }
	// } catch (java.sql.SQLException sqle) {
	// }
	// String message = "End...";
	// System.out.println(message);
	// }

	/**
	 * findWithTAAD
	 *
	 * @param String
	 *            jaCode JAコード java.lang.String SQL
	 * @param String
	 *            tenpoCode 店舗コード
	 *
	 * @exception java.sql.SQLException
	 *                例外：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外：システムエラーが発生した場合
	 *
	 * @since : (2017/06/01)
	 *
	 *        DB：TAAA000, TAAD000 条件：JAコード、店舗コード、帳表コード 項目：[TAAA000]
	 *        JAコード、店舗コード、帳表コード、新基準日、新世代番号 項目：[TAAD000]
	 *        帳表名称、サイクル、世代、受信区分、圧縮区分、送付フラグ
	 */
	public java.util.ArrayList<beanTAAAwithTAAD> findWithTAAD(String jaCode, String tenpoCode)
			throws UserErrorException, SystemErrorException {

		DataSourceUtil ds = null;
		Connection connection = null;
		ResultSet rs = null;

		try {
			// コネクション取得
			ds = new DataSourceUtil();
			connection = ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
			String msg = new String(CLASS_NAME + " : " + "Excpetion[92]=" + e.toString());
			FjLog.error(msg);
			try {
				if (!connection.isClosed()) {
					connection.close();
				}
			} catch (SQLException e1) {
			}
			throw new SystemErrorException(e);
			// ERROR画面へ
		}

		// 配信管理(TAAA000)とファイル管理(TAAD000)から基本情報を検索する
		java.util.ArrayList<beanTAAAwithTAAD> beans = null;
		beans = this.selectBase(connection, jaCode, tenpoCode);

		// 配信管理(TAAA000) の最新世代番号から該当世代データのレコード件数を取得する。
		beans = this.selectRecordNumber(connection, beans);

		// String sql = " SELECT A.AAAJACD, A.AAATENCD, A.AAACYOCD, A.AAANEWKJ,
		// A.AAANEWSE, "
		// + " D.AADCYONM , D.AADCYCLE, D.AADSEDAI, D.AADRCVKB, D.AADTATEN,
		// D.AADSOUFU "
		// + " FROM TAAA000 A, TAAD000 D "
		// + " WHERE (A.AAACYOCD = D.AADCYOCD) "
		// + " AND ( A.AAAJACD = ? ) "
		// + " AND ( AAATENCD = ? ) ";
		// //StringBuffer sb = new StringBuffer(sql);
		//
		// try {
		// // コネクション取得
		// ds = new DataSourceUtil();
		// connection = ds.getConnection();
		//
		// // SQL
		// //String sql = " SELECT AADCYOCD, AADCYONM, AADSEDAI FROM TAAD000 ";
		// PreparedStatement statement = connection.prepareStatement(sql);
		//
		// // パラメータ設定
		// //jaCode = "8888";
		// statement.setString(1, jaCode);
		// statement.setString(2, tenpoCode);
		//
		// // 実行
		// rs = statement.executeQuery();
		//
		// // 結果
		//// int i = 0;
		//// while (rs.next()) {
		//// i++;
		//// System.out.println(" i = " + i);
		//// System.out.println("[1] = " + rs.getString("AAACYOCD").trim());
		//// System.out.println("[2] = " + rs.getString("AADCYONM").trim());
		//// System.out.println("[3] = " + rs.getString("AAAJACD").trim());
		//// }
		//
		// // コネクション・クローズ
		// //connection.close();
		//
		// } catch (Exception e) {
		// e.printStackTrace();
		// String msg = new String(CLASS_NAME + " : " + "Excpetion[92]=" +
		// e.toString());
		// FjLog.error(msg);
		// try {
		// if(!connection.isClosed()){
		// connection.close();
		// }
		// } catch (SQLException e1) {
		// }
		// throw new SystemErrorException(e);
		// //ERROR画面へ
		// }
		//
		// // rs = 0 の場合の設定 TODO
		//
		//
		// // 実行結果取得→bean
		// ArrayList<beanTAAAwithTAAD> beanList = new
		// ArrayList<beanTAAAwithTAAD>();
		// try {
		// while (rs.next()) {
		// // エレメント
		// beanTAAAwithTAAD bean = new beanTAAAwithTAAD();
		// // 属性取得
		// bean.setAAAJACD(rs.getString("AAAJACD").trim());
		// bean.setAAATENCD(rs.getString("AAATENCD").trim());
		// bean.setAAACYOCD(rs.getString("AAACYOCD").trim());
		// bean.setAAANEWKJ(rs.getString("AAANEWKJ").trim());
		// bean.setAAANEWSE(rs.getString("AAANEWSE").trim());
		// bean.setAADCYONM(rs.getString("AADCYONM").trim());
		// bean.setAADCYCLE(rs.getString("AADCYCLE").trim());
		// bean.setAADSEDAI(rs.getString("AADSEDAI").trim());
		// bean.setAADRCVKB(rs.getString("AADRCVKB").trim());
		// // 「他店」→「圧縮区分」
		// bean.setAADZIPKB(rs.getString("AADTATEN").trim());
		// bean.setAADSOUFU(rs.getString("AADSOUFU").trim());
		// // エレメント追加
		// beanList.add(bean);
		// }
		// } catch (Exception e) {
		// e.printStackTrace();
		// String msg = new String(CLASS_NAME + " : " + "Excpetion[222]=" +
		// e.toString());
		// FjLog.error(msg);
		// throw new SystemErrorException(e);
		// } finally {
		// }
		//
		//
		// // レコード件数(TAAA000)取得
		//
		//
		//
		//
		//
		//
		//
		//
		//
		// // コネクション・クローズ
		// try {
		// connection.close();
		// } catch (SQLException e) {
		// // TODO 自動生成された catch ブロック
		// e.printStackTrace();
		// }

		if (0 == beans.size()) {
			return null;
		} else {
			return beans;
		}

	}

	/**
	 * selectBase
	 *
	 * @param Connection
	 *            connection
	 * @param String
	 *            jaCode JAコード
	 * @param String
	 *            tenpoCode 店舗コード
	 *
	 * @exception java.sql.SQLException
	 *                例外：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外：システムエラーが発生した場合
	 *
	 * @since : (2017/06/07)
	 *
	 *        DB：TAAA000, TAAD000 条件：JAコード、店舗コード、帳表コード 項目：[TAAA000]
	 *        JAコード、店舗コード、帳表コード、新基準日、新世代番号 項目：[TAAD000]
	 *        帳表名称、サイクル、世代、受信区分、圧縮区分、送付フラグ
	 */
	private java.util.ArrayList<beanTAAAwithTAAD> selectBase(Connection connection, String jaCode, String tenpoCode)
			throws UserErrorException, SystemErrorException {

		// DataSourceUtil ds = null;
		ResultSet rs = null;

		String sql = " SELECT A.AAAJACD, A.AAATENCD, A.AAACYOCD, A.AAANEWKJ, A.AAANEWSE, "
				+ " D.AADCYONM , D.AADCYCLE, D.AADSEDAI, D.AADRCVKB, D.AADTATEN, D.AADSOUFU "
				+ " FROM TAAA000 A, TAAD000 D " + " WHERE (A.AAACYOCD = D.AADCYOCD) " + " AND ( A.AAAJACD = ? ) "
				+ " AND ( AAATENCD = ? ) ";
		// StringBuffer sb = new StringBuffer(sql);

		try {
			// コネクション取得
			// ds = new DataSourceUtil();
			// connection = ds.getConnection();

			// SQL
			// String sql = " SELECT AADCYOCD, AADCYONM, AADSEDAI FROM TAAD000
			// ";
			PreparedStatement statement = connection.prepareStatement(sql);

			// パラメータ設定
			// jaCode = "8888";
			statement.setString(1, jaCode);
			statement.setString(2, tenpoCode);

			// 実行
			rs = statement.executeQuery();

			// コネクション・クローズ
			// connection.close();

		} catch (Exception e) {
			e.printStackTrace();
			String msg = new String(CLASS_NAME + " : " + "Excpetion[92]=" + e.toString());
			FjLog.error(msg);
			try {
				if (!connection.isClosed()) {
					connection.close();
				}
			} catch (SQLException e1) {
			}
			throw new SystemErrorException(e);
			// ERROR画面へ
		}

		// rs = 0 の場合の設定 TODO

		// 実行結果取得→bean
		ArrayList<beanTAAAwithTAAD> beanList = new ArrayList<beanTAAAwithTAAD>();
		try {
			while (rs.next()) {
				// エレメント
				beanTAAAwithTAAD bean = new beanTAAAwithTAAD();
				// 属性取得
				bean.setAAAJACD(rs.getString("AAAJACD").trim());
				bean.setAAATENCD(rs.getString("AAATENCD").trim());
				bean.setAAACYOCD(rs.getString("AAACYOCD").trim());
				bean.setAAANEWKJ(rs.getString("AAANEWKJ").trim());
				bean.setAAANEWSE(rs.getString("AAANEWSE").trim());
				bean.setAADCYONM(rs.getString("AADCYONM").trim());
				bean.setAADCYCLE(rs.getString("AADCYCLE").trim());
				bean.setAADSEDAI(rs.getString("AADSEDAI").trim());
				bean.setAADRCVKB(rs.getString("AADRCVKB").trim());
				// 「他店」→「圧縮区分」
				bean.setAADZIPKB(rs.getString("AADTATEN").trim());
				bean.setAADSOUFU(rs.getString("AADSOUFU").trim());
				// エレメント追加
				beanList.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
			String msg = new String(CLASS_NAME + " : " + "Excpetion[222]=" + e.toString());
			FjLog.error(msg);
			throw new SystemErrorException(e);
		} finally {
		}

		// コネクション・クローズ
		// try {
		// //connection.close();
		// } catch (SQLException e) {
		// // TODO 自動生成された catch ブロック
		// e.printStackTrace();
		// }

		if (0 == beanList.size()) {
			return null;
		} else {
			return beanList;
		}
	}

	/**
	 * selectBase
	 *
	 * @param Connection
	 *            connection
	 * @param String
	 *            jaCode JAコード
	 * @param ArrayList<beanTAAAwithTAAD>
	 *            beans 店舗コード
	 *
	 * @exception java.sql.SQLException
	 *                例外：SQLエラーが発生した場合
	 * @exception pjt.fw.SystemErrorException
	 *                例外：システムエラーが発生した場合
	 *
	 * @since : (2017/06/07) selectRecordNumber DB：TAAA000, TAAD000
	 *        条件：JAコード、店舗コード、帳表コード 項目：[TAAA000] JAコード、店舗コード、帳表コード、新基準日、新世代番号
	 *        項目：[TAAD000] 帳表名称、サイクル、世代、受信区分、圧縮区分、送付フラグ
	 */
	private java.util.ArrayList<beanTAAAwithTAAD> selectRecordNumber(Connection connection,
			ArrayList<beanTAAAwithTAAD> beans) throws UserErrorException, SystemErrorException {

		// DataSourceUtil ds = null;
		ResultSet rs = null;

		String sql = " SELECT * FROM TAAA000  " + " WHERE ( AAAJACD = ? ) " + " AND ( AAATENCD = ? ) "
				+ " AND ( AAACYOCD = ? ) " + " AND ( AAANEWKJ = ? ) ";
		// StringBuffer sb = new StringBuffer(sql);

		String recordCount = null;
		String sedaiNum = null;
		try {
			// SQL
			PreparedStatement statement = connection.prepareStatement(sql);

			for (int i = 0; i < beans.size(); i++) {
				beanTAAAwithTAAD bean = beans.get(i);
				statement.setString(1, bean.getAAAJACD());
				statement.setString(2, bean.getAAATENCD());
				statement.setString(3, bean.getAAACYOCD());
				statement.setBigDecimal(4, new BigDecimal( bean.getAAANEWKJ())); // Integer.parseInt(bean.getAAANEWKJ()));

				// 実行
				rs = statement.executeQuery();

				while (rs.next()) {
					try {
						// 属性取得
						sedaiNum = rs.getString("AAANEWSE").trim();
						sedaiNum = String.format("%3s", sedaiNum).replace(' ', '0');
						recordCount = rs.getString("AAARC" + sedaiNum).trim();
						// レコード件数 設定
						bean.setAAARECNUM(recordCount);
					} catch (Exception e) {
						String msg = new String(CLASS_NAME + " : " + "Excpetion[453]=" + e.toString());
						FjLog.error(msg);
						bean.setAAARECNUM("");
					}

				}

			}

			// コネクション・クローズ
			// connection.close();

		} catch (Exception e) {
			e.printStackTrace();
			String msg = new String(CLASS_NAME + " : " + "Excpetion[92]=" + e.toString());
			FjLog.error(msg);
			try {
				if (!connection.isClosed()) {
					connection.close();
				}
			} catch (SQLException e1) {
			}
			throw new SystemErrorException(e);
			// ERROR画面へ
		}

		// rs = 0 の場合の設定 TODO

		// // 実行結果取得→bean
		// ArrayList<beanTAAAwithTAAD> beanList = new
		// ArrayList<beanTAAAwithTAAD>();
		// try {
		// while (rs.next()) {
		// // エレメント
		// beanTAAAwithTAAD bean = new beanTAAAwithTAAD();
		// // 属性取得
		// bean.setAAAJACD(rs.getString("AAAJACD").trim());
		// bean.setAAATENCD(rs.getString("AAATENCD").trim());
		// bean.setAAACYOCD(rs.getString("AAACYOCD").trim());
		// bean.setAAANEWKJ(rs.getString("AAANEWKJ").trim());
		// bean.setAAANEWSE(rs.getString("AAANEWSE").trim());
		// bean.setAADCYONM(rs.getString("AADCYONM").trim());
		// bean.setAADCYCLE(rs.getString("AADCYCLE").trim());
		// bean.setAADSEDAI(rs.getString("AADSEDAI").trim());
		// bean.setAADRCVKB(rs.getString("AADRCVKB").trim());
		// // 「他店」→「圧縮区分」
		// bean.setAADZIPKB(rs.getString("AADTATEN").trim());
		// bean.setAADSOUFU(rs.getString("AADSOUFU").trim());
		// // エレメント追加
		// beanList.add(bean);
		// }
		// } catch (Exception e) {
		// e.printStackTrace();
		// String msg = new String(CLASS_NAME + " : " + "Excpetion[222]=" +
		// e.toString());
		// FjLog.error(msg);
		// throw new SystemErrorException(e);
		// } finally {
		// }

		// コネクション・クローズ
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		if (0 == beans.size()) {
			return null;
		} else {
			return beans;
		}
	}

	// try{
	//
	// jUtil.setSQL(sb.toString());
	//
	// if (rcvtm != null) { //��M�����I������(EDBRCVTMorEDHRCVTM)
	// jUtil.setDate(index,new java.sql.Date(df.parse(rcvtm).getTime()));
	// index++;
	// }
	// if (itkcd != null) { //�ϑ��҃R�[�h(EDBITKCDorEDAITKCD)
	// jUtil.setString(index,itkcd);
	// index++;
	// }
	// if (fridt != null && fridt.length > 0) { //�U�֓�(EDAFRIDT)
	// for (int i=0;i<fridt.length;i++) {
	// jUtil.setDate(index,new java.sql.Date(df.parse(fridt[i]).getTime()));
	// index++;
	// }
	// }
	// if (stats != null && stats.length > 0) {
	// //�����X�e�[�^�X(EDBSTATSorEDHSTATS)
	// for (int i=0;i<stats.length;i++) {
	// jUtil.setInt(index,Integer.parseInt(stats[i]));
	// index++;
	// }
	// }
	// if (sikibetukubun != null) { //�˗��f�[�^���ʋ敪 (EDADTSKB)
	// jUtil.setInt(index,Integer.parseInt(sikibetukubun));
	// index++;
	// }
	// if (furikomiHikiotoshiKubun != null) { //�U�������敪�R�[�h(EMAC0001)
	// jUtil.setString(index,furikomiHikiotoshiKubun);
	// index++;
	// }
	// if (kennaiFurikomiToriatukai != null) { //�����U���戵�敪�R�[�h(EMACD002)
	// jUtil.setString(index,kennaiFurikomiToriatukai);
	// index++;
	// }
	// if (syoribi != null) { //������(EDBTIMSTorEDHTIMST)
	// jUtil.setDate(index,new java.sql.Date(df.parse(syoribi).getTime()));
	// index++;
	// }
	// if (tritm != null) { //�捞�����I������(EDBTRITMorEDHTRITM)
	// jUtil.setDate(index,new java.sql.Date(df.parse(tritm).getTime()));
	// index++;
	// }
	// if (sndtm != null) { //���M�����I������(EDBSNDTMorEDHSNDTM)
	// jUtil.setDate(index,new java.sql.Date(df.parse(sndtm).getTime()));
	// index++;
	// }
	// if (rtftm != null) { //�ԋp�f�[�^�쐬�����I������(EDBRTFTMorEDHRTFTM)
	// jUtil.setDate(index,new java.sql.Date(df.parse(rtftm).getTime()));
	// index++;
	// }
	// if (astats != null) { //�����X�e�[�^�X(EDASTATS)
	// jUtil.setInt(index,Integer.parseInt(astats));
	// index++;
	// }
	//
	// jUtil.executeQuery();
	//
	// int i = 0;
	// while (jUtil.next()) {
	//
	// Logger.L5.writeLog("record[" + i + "]");
	// i++;
	//
	// TEDB000 edb = new TEDB000();
	// if(jUtil.getTimestamp("F1") != null)
	// edb.setRCVTM(tsf.format(jUtil.getTimestamp("F1")));
	// if(jUtil.getString("F2") != null)
	// edb.setRCVFN(jUtil.getString("F2").trim());
	// edb.setITKCD(jUtil.getString("F20").trim());
	// edb.setFRIDT(df.format(jUtil.getDate("F21")));
	// edb.setTSUBN(String.valueOf(jUtil.getInt("F22")));
	// edb.setSTATS(String.valueOf(jUtil.getInt("F3")));
	// if(jUtil.getTimestamp("F4") != null)
	// edb.setTRITM(tsf.format(jUtil.getTimestamp("F4")));
	// if(jUtil.getTimestamp("F6") != null)
	// edb.setTIMST(tsf.format(jUtil.getTimestamp("F6")));
	// if(jUtil.getString("F5") != null)
	// edb.setSNDFN(jUtil.getString("F5").trim());
	// if(jUtil.getString("EMAB0005") != null)
	// edb.setITKNM(jUtil.getString("EMAB0005").trim());
	// if(jUtil.getString("EMAB0020") != null)
	// edb.setFRMCD(jUtil.getString("EMAB0020").trim());
	// edb.setDTSKB(String.valueOf(jUtil.getInt("EDADTSKB")));
	// if(jUtil.getString("EMAC0001") != null)
	// edb.setFRIKB(jUtil.getString("EMAC0001").trim());
	// if(jUtil.getString("EMACC006") != null)
	// edb.setKAKKB(jUtil.getString("EMACC006").trim());
	// edb.setKENSU(String.valueOf(jUtil.getInt("F7")));
	// edb.setKINGK(String.valueOf(jUtil.getLong("F8")));
	// if(jUtil.getString("F9") != null)
	// edb.setINPFN(jUtil.getString("F9").trim());
	// if(jUtil.getString("F10") != null)
	// edb.setSYUCD(jUtil.getString("F10").trim());
	// if(jUtil.getTimestamp("F11") != null)
	// edb.setSNDTM(tsf.format(jUtil.getTimestamp("F11")));
	// if(jUtil.getTimestamp("F12") != null)
	// edb.setRTFTM(tsf.format(jUtil.getTimestamp("F12")));
	// if(jUtil.getString("EMACD002") != null)
	// edb.setKBNCD(jUtil.getString("EMACD002").trim());
	// edb.setYOHFL(String.valueOf(jUtil.getInt("EMAK0001")));
	// edb.setASTAT(String.valueOf(jUtil.getInt("EDASTATS")));
	// if(jUtil.getString("F17") != null)
	// edb.setSYUCD(jUtil.getString("F17").trim());
	//
	// if(jUtil.getString("F18") != null)
	// edb.setGUNKB(jUtil.getString("F18").trim());
	//
	// records.addElement(edb);
	// }
	//
	// } catch (SQLException e) {
	// ExceptionChecker ec = new ExceptionChecker(e);
	// if (ec.isUserError()){
	// throw new UserErrorException(ec.getMsgId());
	// }else{
	// throw new SystemErrorException(e);
	// }
	// } catch (ParseException e) {
	// }
	// return records;
	//
	// }

	/**
	 * main: (2017/06/05 17:28:56)
	 */
	// public static void main(String[] args) {
	// try {
	// TblTAAA000 TAAA = new TblTAAA000(new JDBCUtil());
	//
	// /************************************************
	// * �O��ʂ̓��͏����Z�b�V�����I�u�W�F�N�g����擾
	// *************************************************/
	// String itakucd = "0002100";
	// String siteibi = "20120705";
	// String[] status = new String[1];
	// status[0] = "19";
	// String torikomibi = "20130402";
	//
	// /************************************************
	// *************************************************/
	// //ArrayList<beanTAAAwithTAAD> records = TAAA.findWithTAAD("3003", "001",
	// "KGSDA004");
	//
	//
	// ArrayList<beanTAAAwithTAAD> beans = null;
	// try {
	// beans = TAAA.findWithTAAD("3003", "001");
	// } catch (SystemErrorException e) {
	// e.printStackTrace();
	// String msg = new String("Main : " + "Excpetion[1165]=" + e.toString());
	// FjLog.error(msg);
	// throw new SystemErrorException(e);
	// } finally {
	// }
	//
	// // Bean→JSON コンバート
	// beanTAAAwithTAAD bean;
	// for (int i = 0; i < beans.size(); i++) {
	// bean = (beanTAAAwithTAAD) beans.get(i);
	// // POJOをJSONに変換。戻り値 (例） {"number":10,"string":"aaa","array":[1,2,3]}
	// String text = JSON.encode(bean);
	// System.out.println("index=" + i +" " + text);
	// }
	//
	// System.out.println("---END---");
	//
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

}
