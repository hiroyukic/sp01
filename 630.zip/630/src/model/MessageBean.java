package model;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import bean.beanTAAAwithTAAD;
import fw.DataSourceUtil;
import fw.FjLog;
import fw.JDBCUtil;
import fw.SystemErrorException;
import fw.UserErrorException;

//import org.json.JSONArray;
//import org.json.JSONObject;
/**
 * Download 用パラメータ
 * @since : (2017/06/29)
 * @author: chiba
 */
public class MessageBean {
	//jacode":"3003","tenpoCode":"001","cyohyocode":"KGSDA004","kijyunDate":"20170331"}"
	private String jacode ;
	private String tenpoCode ;
	private String cyohyocode ;
	private String kijyunDate ;

	public String getJacode() {
		return jacode;
	}
	public void setJacode(String jacode) {
		this.jacode = jacode;
	}
	public String getTenpoCode() {
		return tenpoCode;
	}
	public void setTenpoCode(String tenpoCode) {
		this.tenpoCode = tenpoCode;
	}
	public String getCyohyocode() {
		return cyohyocode;
	}
	public void setCyohyocode(String cyohyocode) {
		this.cyohyocode = cyohyocode;
	}
	public String getKijyunDate() {
		return kijyunDate;
	}
	public void setKijyunDate(String kijyunDate) {
		this.kijyunDate = kijyunDate;
	}


}
