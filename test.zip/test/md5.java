package test;

public class md5 {

	static {
	    System.loadLibrary("KJCrypt");
	}

//	Declare Function PasswordToMD5 Lib "KJCrypt" ( _
//			Byval sPassword As String, _
//			iResult() As Integer _
//		) As Long


	 //static {
	 //       Native.register("Kernel32"); // ネイティブライブラリのロード
	 //   }


	//Windows APIのQueryPerformanceFrequencyを呼び出すnativeメソッド定義
	public static native int PasswordToMD5(String s0, int[] s1);

	public static void main(String[] args) {

		 String hsInputStr = "PASSWORD";
		 int MD5Data[] = {0,1,2,3,4,5,6,7};

	    int ret ;
	    try {
	    	ret = PasswordToMD5(hsInputStr, MD5Data);
	    } catch (Exception e) {
			String message = "Exception..";
			System.out.println(message);
		}

	    //ret = PasswordToMD5(hsInputStr, MD5Data);

	    //System.out.println(ret);



	}

}
