package test;




//	Declare Function PasswordToMD5 Lib "KJCrypt" ( _
//		Byval sPassword As String, _
//		iResult() As Integer _
//	) As Long


public class gMakePass {



static {
    System.loadLibrary("KJCript");
 }

//Windows APIのQueryPerformanceFrequencyを呼び出すnativeメソッド定義
public static native int PasswordToMD5(String s0, String s1);

 public static void main(String args[]) {
	 gMakePass obj = new gMakePass();



	 String hsInputStr = "PASSWORD";
	 String MD5Data = "";

    int ret = 0;
    ret = PasswordToMD5(hsInputStr, MD5Data);

    System.out.println(ret);





 }






}
