Public Class ZFRM0001
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �� dispose ���I�[�o�[���C�h���ăR���|�[�l���g�ꗗ���������܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    ' Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^�͎g�p���Ȃ��ł��������B
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents ButtonEnd As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.ButtonEnd = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(34, 27)
        Me.Button1.Name = "Button1"
        Me.Button1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button1.Size = New System.Drawing.Size(187, 33)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "(&1)�݌ɊǗ����j���["
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(34, 78)
        Me.Button2.Name = "Button2"
        Me.Button2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button2.Size = New System.Drawing.Size(187, 33)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "(&2)�}�X�^�Ǘ����j���["
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(34, 123)
        Me.Button3.Name = "Button3"
        Me.Button3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button3.Size = New System.Drawing.Size(187, 33)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "(&3)"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Visible = False
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(34, 171)
        Me.Button4.Name = "Button4"
        Me.Button4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button4.Size = New System.Drawing.Size(187, 33)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "(&4)"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.Visible = False
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(34, 219)
        Me.Button5.Name = "Button5"
        Me.Button5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button5.Size = New System.Drawing.Size(187, 33)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "(&5)"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Visible = False
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(34, 267)
        Me.Button6.Name = "Button6"
        Me.Button6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button6.Size = New System.Drawing.Size(187, 33)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "(&6)"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.Visible = False
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(34, 315)
        Me.Button7.Name = "Button7"
        Me.Button7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button7.Size = New System.Drawing.Size(187, 33)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "(&7)"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button7.Visible = False
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(254, 27)
        Me.Button8.Name = "Button8"
        Me.Button8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button8.Size = New System.Drawing.Size(187, 33)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "(&8)"
        Me.Button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.Visible = False
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(254, 75)
        Me.Button9.Name = "Button9"
        Me.Button9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button9.Size = New System.Drawing.Size(187, 33)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "(&9)"
        Me.Button9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button9.Visible = False
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(254, 123)
        Me.Button10.Name = "Button10"
        Me.Button10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button10.Size = New System.Drawing.Size(187, 33)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "(&A)"
        Me.Button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10.Visible = False
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(254, 171)
        Me.Button11.Name = "Button11"
        Me.Button11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button11.Size = New System.Drawing.Size(187, 33)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "(&B)"
        Me.Button11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button11.Visible = False
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(254, 219)
        Me.Button12.Name = "Button12"
        Me.Button12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button12.Size = New System.Drawing.Size(187, 33)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "(&C)"
        Me.Button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button12.Visible = False
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(254, 267)
        Me.Button13.Name = "Button13"
        Me.Button13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button13.Size = New System.Drawing.Size(187, 33)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "(&D)"
        Me.Button13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button13.Visible = False
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(254, 315)
        Me.Button14.Name = "Button14"
        Me.Button14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button14.Size = New System.Drawing.Size(187, 33)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "(&E)"
        Me.Button14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button14.Visible = False
        '
        'ButtonEnd
        '
        Me.ButtonEnd.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ButtonEnd.Location = New System.Drawing.Point(254, 363)
        Me.ButtonEnd.Name = "ButtonEnd"
        Me.ButtonEnd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ButtonEnd.Size = New System.Drawing.Size(187, 33)
        Me.ButtonEnd.TabIndex = 14
        Me.ButtonEnd.Text = "�I��(&X)"
        '
        'ZFRM0001
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 12)
        Me.ClientSize = New System.Drawing.Size(464, 412)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ButtonEnd, Me.Button14, Me.Button13, Me.Button12, Me.Button11, Me.Button10, Me.Button9, Me.Button8, Me.Button7, Me.Button6, Me.Button5, Me.Button4, Me.Button3, Me.Button2, Me.Button1})
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ZFRM0001"
        Me.Text = "���C�����j���["
        Me.ResumeLayout(False)

    End Sub

#End Region
    '�t�H�[���錾
    Dim AFRM0001 As New AFRM0001
    Dim XFRM0001 As New XFRM0001

    Private Sub ZFRM0001_Load _
            (ByVal sender As System.Object, _
            ByVal e As System.EventArgs) _
            Handles MyBase.Load
        Me.Text = Me.Name & ":" & Me.Text
    End Sub

    Private Sub ZFRM0001_Closing _
            (ByVal sender As Object, _
            ByVal e As System.ComponentModel.CancelEventArgs) _
            Handles MyBase.Closing
        If aLoadedForms.Count > 0 Then
            MsgBox("���̃t�H�[���� " & _
                    CStr(aLoadedForms.Count) & _
                    " �J���Ă��܂��B")
            aLoadedForms.Item(0).Focus()
            e.Cancel = True
        End If
    End Sub

    Private Sub Button1_Click _
            (ByVal sender As System.Object, _
            ByVal e As System.EventArgs) _
            Handles Button1.Click
        Try
            AFRM0001.Show()
        Catch
            AFRM0001 = New AFRM0001
            AFRM0001.Show()
        End Try
        AFRM0001.Focus()
    End Sub
    Private Sub Button2_Click _
            (ByVal sender As System.Object, _
            ByVal e As System.EventArgs) _
            Handles Button2.Click
        Try
            XFRM0001.Show()
        Catch
            XFRM0001 = New XFRM0001
            XFRM0001.Show()
        End Try
        XFRM0001.Focus()
    End Sub

    Private Sub ButtonEnd_Click _
            (ByVal sender As System.Object, _
            ByVal e As System.EventArgs) _
            Handles ButtonEnd.Click
        Me.Close()
    End Sub
End Class
