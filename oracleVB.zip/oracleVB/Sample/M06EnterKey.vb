Module M06EnterKey
    Public Sub NextControl(ByVal mfrm01 As Form)
        Dim intNowTabIndex As Integer
        Dim intTabIndex As Integer
        Dim cnt01 As Control
        Dim objTXT As Object
        Dim intContCount As Integer
        Dim intX As Integer
        Dim i As Integer
        Dim intMin As Integer
        '�����ݒ�
        intX = -1
        intMin = 999999999
        '�R���g���[�����̗v�f�����z����m��
        intContCount = mfrm01.Controls.Count - 1
        Dim cntAR(intContCount) As Control
        Dim intAR(intContCount) As Integer
        'intNowTabIndex ��
        '���݂̃R���g���[����TabIndex
        intNowTabIndex = _
            mfrm01.ActiveControl.TabIndex
        '���ׂẴR���g���[������
        For Each cnt01 In mfrm01.Controls
            Do
                If cnt01.CanFocus Then
                Else
                    Exit Do
                End If
                If cnt01.Enabled Then
                Else
                    Exit Do
                End If
                If cnt01.Visible Then
                Else
                    Exit Do
                End If
                If cnt01.TabStop Then
                Else
                    Exit Do
                End If
                intTabIndex = cnt01.TabIndex
                If intTabIndex > intNowTabIndex Then
                Else
                    Exit Do
                End If
                '�z��Ɋi�[
                intX = intX + 1
                cntAR(intX) = cnt01
                intAR(intX) = intTabIndex
                '�ŏ��l���v�Z
                If intTabIndex < intMin Then
                    intMin = intTabIndex
                End If
                Exit Do
            Loop
        Next cnt01
        '�ŏ���TabIndex�����R���g���[����T����
        'Focus
        For i = 0 To intX
            If intAR(i) = intMin Then
                cntAR(i).Focus()
                'SelectAll���\�b�h���\�Ȃ���s
                Try
                    objTXT = cntAR(i)
                    objTXT.SelectAll()
                Catch ex As Exception
                End Try
                Exit For
            End If
        Next i
    End Sub

End Module
