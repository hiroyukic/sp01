﻿package filesplit2;

import java.text.*;
import java.sql.*;

import filesplit2.util.Log;
import filesplit2.util.DBConnectBase;
import filesplit2.util.DoneException;

public class Taaa000 extends Object {

	/** データベース管理用クラス*/
	private DBConnectBase db;

	/** JAコード */
	private String jaCode;

	/** 店舗コード */
	private String tenCode;

	/** 帳票コード */
	private String cyoHyoCode;

	/** 最新基準日 */
	private String newKijunBi;

	/** 最新世代 */
	private int    newSedai;

	/** ファイル詳細クラスの個数 */
	private int    fileDetailCNT;

	/** ファイル詳細クラス */
	protected Taaa000FileDetail fileDetail[];

	/** PreparedStatement 定義 保存世代数 取得*/
	protected PreparedStatement preStmtSaveFileCNT = null;

	/** SQL 定義 保存世代数 取得 */
	protected String SQL_SELECT_SAVE_FILE_CNT = "SELECT AADSEDAI FROM TAAD000 WHERE AADCYOCD = ? ";

	/** PreparedStatement 定義 配信管理テーブル 取得*/
	protected PreparedStatement preStmtTAAA000 = null;

	/** SQL 定義 配信管理テーブル 取得 */
	protected String SQL_SELECT_TAAA000 = "SELECT * FROM TAAA000 WHERE AAAJACD = ? AND AAATENCD = ? AND AAACYOCD = ?";

	/** ログ出力オブジェクト取得 */
	private Log log = Log.getInstance();


	/** コンストラクタ.
	 */
	public Taaa000() {

	log.trace("Taaa000.Taaa000() Start");

		jaCode	   = "";
		tenCode    = "";
		cyoHyoCode = "";
		newKijunBi = "";
		newSedai   = 0;
		db = DBConnectBase.getInstance();

	log.trace("Taaa000.Taaa000() End");
	
	}


	/** 読み込み処理(データベース).
	 */
	protected void doRead() throws DoneException{
	
		log.trace("Taaa000.doRead() Start");

		try{
			Connection conn = db.getConnection();						//DBコネクション取得
			ResultSet result   = null;									//SQL実行結果取得用
			preStmtSaveFileCNT = null;									//管理世代数取得用ステートメント
			preStmtTAAA000     = null;									//配信管理テーブル取得用ステートメント
			try{
				preStmtSaveFileCNT = conn.prepareStatement(SQL_SELECT_SAVE_FILE_CNT);	//ステートメント割り当て（世代数取得開始）
				preStmtSaveFileCNT.setString(1,cyoHyoCode);				//引数設定、WHERE文の帳票コード
				//ＳＱＬのResultSet取得 保存世代数取得
				result = preStmtSaveFileCNT.executeQuery();				//SQL実行
				if( result.next() ) {									//結果あり？
					setFileDetailCNT(
						Integer.valueOf(
							result.getString("AADSEDAI").trim()
						).intValue() +1 
					);													//世代数分のファイル詳細クラス割り当て
				}else{
					setFileDetailCNT(0);								//結果なしの場合クラスの割り当てなし
				}
				result.close();											//世代数取得終了

				preStmtTAAA000 = conn.prepareStatement(SQL_SELECT_TAAA000);//ステートメント割り当て（配信管理取得開始）
				preStmtTAAA000.setString(1,jaCode);						//引数設定、WHERE文のJAコード
				preStmtTAAA000.setString(2,tenCode);					//引数設定、WHERE文の店舗コード
				preStmtTAAA000.setString(3,cyoHyoCode);					//引数設定、WHERE文の帳票コード

				result = preStmtTAAA000.executeQuery();					//SQL実行
				if(result.next()){										//結果あり？

					newKijunBi = result.getString("AAANEWKJ");			//最新基準日取得
					newSedai   = Integer.parseInt(result.getString("AAANEWSE"));//最新世代取得
					NumberFormat nf = new DecimalFormat("000");			//以下 ファイル詳細（最大６１個）の分取得のため

					for(int i=0; i< fileDetailCNT; i++){				//世代数分ループ
						String num = nf.format(i+1);					//SQL結果取得のための文字列
						setSedaiNo(i, result.getString( "AAASE"+num ));		//世代番号
						setKijunBi(i, result.getString( "AAAKJ"+num ));		//基準日
						setReciveCnt(i, result.getString( "AAARC"+num ));	//受信レコード数
						setReciveFlag(i, result.getString( "AAARV"+num ));	//受信フラグ
						setReciveDate(i, result.getString( "AAARD"+num ));	//受信日
					}
				}

			} catch(Exception e){
				throw new DoneException(e,"ＤＢＳＱＬ（読込み）実行できませんでした。");	//SQL実行時のエラー

			} finally {
				try{
					result.close();										//配信管理取得終了
					if( preStmtSaveFileCNT != null )
						preStmtSaveFileCNT.close();
					if( preStmtTAAA000     != null )
						preStmtTAAA000.close();
				}catch(Exception e){
					throw new DoneException(e,"ＤＢＳＱＬステートメントをクローズできませんでした。");
				}
			}

		}catch(Exception e){
			throw new DoneException(e,"ＤＢコネクション（読込み）を取得できませんでした。");
		}

		log.trace("Taaa000.doRead() End");
	
	}


	/** 書き込み処理(データベース).
	 */
	protected void doWrite() throws DoneException{
	
		log.trace("Taaa000.doWrite() Start");

		ResultSet result = null;											//SQL実行結果取得用
		preStmtTAAA000   = null;											//配信管理テーブル取得用ステートメント
		Statement stmt   = null;											//配信管理テーブル書き込み用ステートメント
		try {
			Connection conn = db.getConnection();							//DBコネクション取得
			try {
				preStmtTAAA000 = conn.prepareStatement(SQL_SELECT_TAAA000);	//配信管理テーブル取得開始
				preStmtTAAA000.setString(1,jaCode);							//引数設定、WHERE文のJAコード
				preStmtTAAA000.setString(2,tenCode);						//引数設定、WHERE文の店舗コード
				preStmtTAAA000.setString(3,cyoHyoCode);						//引数設定、WHERE文の帳票コード
				result = preStmtTAAA000.executeQuery();						//SQL実行

				String SQL = "";
				if(!result.next()){										//配信管理レコードなし(INSERT開始)
                    NumberFormat nf = new DecimalFormat("00");
					/* INSERT */
					SQL = "INSERT INTO TAAA000 VALUES(" 
							+ "'"  + jaCode     + "'"
							+ ",'" + tenCode    + "'"
							+ ",'" + cyoHyoCode + "'"
							+ ","  + newKijunBi
							+ ","  + nf.format(newSedai);
					int i;
					for(i=0; i< fileDetailCNT; i++){					//ファイル詳細設定部分のループ
						SQL += "," + this.fileDetail[i].toCVS();
					}
					for(;i<61;i++){										//ファイル詳細未設定部分のループ
						SQL += ",NULL,NULL,NULL,NULL,NULL";
					}
	                SQL += ")";
	            }else{													//配信管理レコードあり(UPDATE開始)
					/* UPDATE */
                    NumberFormat nf = new DecimalFormat("00");
					SQL = "UPDATE TAAA000 SET"
							+ " AAANEWKJ = "  + newKijunBi
							+ ", AAANEWSE = "  + nf.format(newSedai);

					nf = new DecimalFormat("000");

					int i;
					for(i=0; i< fileDetailCNT; i++){					//ファイル詳細設定部分のループ
						String num = nf.format(i+1);
						SQL += ", AAASE"+ num + " = " + getSedaiNo(i);
						SQL += ", AAAKJ"+ num + " = " + getKijunBi(i);
						SQL += ", AAARC"
							  + num + " = " 
							  + getReciveCnt(i);
						SQL +=  ", AAARV"
							  + num + " = '" 
							  + getReciveFlag(i)
							  + "'";
						SQL +=  ", AAARD"
							  + num + " = " 
							  + getReciveDate(i);

                    }

					for(;i<61;i++){										//ファイル詳細未設定部分のループ
						String num = nf.format(i+1);
						SQL += ", AAASE"+ num + " = NULL";
						SQL += ", AAAKJ"+ num + " = NULL";
						SQL += ", AAARC"+ num + " = NULL";
						SQL += ", AAARV"+ num + " = NULL";
						SQL += ", AAARD"+ num + " = NULL";
					}
                    SQL += " WHERE AAAJACD = '" + jaCode + "' AND ";
                    SQL += " AAATENCD = '" + tenCode + "' AND ";
                    SQL += " AAACYOCD = '" + cyoHyoCode + "'";
				}
				stmt = conn.createStatement();							//ステートメント取得
				stmt.execute(SQL);										//書き込みSQL実行
			} catch(Exception e) {
				throw new DoneException(e,"ＤＢＳＱＬ（書込み）実行できませんでした。");
			} finally {
				if( result != null ) result.close();
				if( preStmtTAAA000 != null ) preStmtTAAA000.close();
				if( stmt != null ) stmt.close();
			}

		}catch(Exception e){
			throw new DoneException(e,"ＤＢコネクション（書込み）を取得できませんでした。");
		}

		log.trace("Taaa000.doWrite() End");
	
	}


	/**ファイル詳細の個数設定.
	 * @param size 個数[0から61個まで]
	*/
	public void setFileDetailCNT(int size) {

		log.trace("Taaa000.setFileDetailCNT Start");

		fileDetailCNT = size;											//メンバ変数にサイズ代入
		fileDetail = new Taaa000FileDetail[fileDetailCNT];				//ファイル詳細用配列アロケート
		for(int i=0; i<fileDetailCNT; i++){								//世代数分だけループ
			Taaa000FileDetail fd = new Taaa000FileDetail();				//ファイル詳細クラス生成
			fileDetail[i] = fd;											//配列に代入
		}

		log.trace("Taaa000.setFileDetailCNT End");
	}


	/**ファイル詳細個数の取得.
	 * @return 設定可能個数
	 */
	public int getFileDetailCNT(){
		return fileDetailCNT;
	}


	/** JAコード取得.
	 * @return JAコード
	 */
	public String getJaCode(){
		return jaCode;
	}


	/** 店舗コード取得.
	 * @return 店舗コード
	 */
	public String getTenCode(){
		return tenCode;
	}


	/** 帳票コード取得
	 * @return 帳票コード
	 */
	public String getCyoHyoCode(){
		return cyoHyoCode;
	}


	/** 最新基準日取得
	 * @return 最新基準日
	 */
	public String getNewKijunBi(){
		return newKijunBi;
	}


	/** 最新世代取得
	 * @return 最新世代
	 */
	public String getNewSedai(){ 
        NumberFormat nf = new DecimalFormat("00");
        return nf.format(newSedai); 
    }


	/** JAコード設定
	 * @param JAコード
	 */
	public void setJaCode(String jaCode){
		this.jaCode = jaCode;
	}


	/** 店舗コード設定
	 * @param 店舗コード
	 */
	public void setTenCode(String tencd){
		this.tenCode = tencd;
	}


	/** 帳票コード設定
	 * @param 帳票コード
	 */
	public void setCyoHyoCode(String Cyocd){
		this.cyoHyoCode = Cyocd;
	}


	/** 最新基準日設定
	 * @param 最新基準日
	 */
	public void setNewKijunBi(String kj){
		this.newKijunBi = kj;
	}


	/** 最新世代設定
	 * @param 最新世代
	 */
	public void setNewSedai(String newse){ 
        this.newSedai = Integer.parseInt(newse);
    }


	/** ファイル詳細の世代番号取得
	 * @param i ファイル詳細配列のindex
	 * @return 世代番号
	 */
	public String getSedaiNo(int i){
		return fileDetail[i].getSedaiNo();
	}


	/** ファイル詳細の基準日取得
	 * @param i ファイル詳細配列のindex
	 * @return 基準日
	 */
	public String getKijunBi(int i){
		return fileDetail[i].getKijunBi();
	}


	/** ファイル詳細の受信レコード数取得
	 * @param i ファイル詳細配列のindex
	 * @return 受信レコード数
	 */
	public String getReciveCnt(int i){
		return fileDetail[i].getReciveCnt();
	}


	/** ファイル詳細の受信フラグ取得
	 * @param i ファイル詳細配列のindex
	 * @return 受信フラグ
	 */
	public String getReciveFlag(int i){
        if(fileDetail[i].getReciveFlag() == null){
            return " ";
        }else{
            return fileDetail[i].getReciveFlag();
        }
    }


	/** ファイル詳細の受信日取得
	 * @param i ファイル詳細配列のindex
	 * @return 受信日
	 */
	public String getReciveDate(int i){
		return fileDetail[i].getReciveDate();
	}


	/** ファイル詳細世代番号設定.
	 * @param i ファイル詳細配列のindex
	 * @param 世代番号
	 */
	public void setSedaiNo(int i,String sedaiNo){
		fileDetail[i].setSedaiNo(sedaiNo);
	}


	/** ファイル詳細基準日設定.
	 * @param i ファイル詳細配列のindex
	 * @param 基準日
	 */
	public void setKijunBi(int i,String kijunBi){
		fileDetail[i].setKijunBi(kijunBi);
	}


	/** ファイル詳細受信レコード数設定.
	 * @param i ファイル詳細配列のindex
	 * @param レコード数
	 */
	public void setReciveCnt(int i,String recCnt){
		fileDetail[i].setReciveCnt(recCnt);
	}


	/** ファイル詳細受信フラグ設定.
	 * @param i ファイル詳細配列のindex
	 * @param 受信フラグ
	 */
	public void setReciveFlag(int i,String reciveFlag){
		fileDetail[i].setReciveFlag(reciveFlag);
	}


	/** ファイル詳細受信日設定.
	 * @param i ファイル詳細配列のindex
	 * @param 受信日
	 */
	public void setReciveDate(int i,String reciveDate){
		fileDetail[i].setReciveDate(reciveDate);
	}


	/** このクラスの詳細情報を文字列で返す。.
	 */
	public String toString(){

		String ret = 
		  "JA CODE     : " + jaCode     + "\n"
		+ "TEN CODE    : " + tenCode    + "\n"
		+ "CYOHYO CODE : " + cyoHyoCode + "\n"
		+ "NEW SEDAI   : " + newSedai   + "\n"
		+ "NEW KIJUNBI : " + newKijunBi + "\n"
		+ "SEDAI COUNT : " + getFileDetailCNT() + "\n";

		return ret;
	}


}
