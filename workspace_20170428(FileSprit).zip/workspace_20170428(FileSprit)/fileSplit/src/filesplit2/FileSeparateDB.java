﻿/*
 * FileID(HALUFTID)をキーにしてファイル管理テーブル内のレコードを取得
 *
 *	version		V01.00	2009/05/25	T.itoh	Open
 *
 */

package filesplit2;

import java.util.*;
import java.sql.*;

import filesplit2.util.Log;
import filesplit2.util.DBConnectBase;
import filesplit2.util.DoneException;

/** FileID(HALUFTID)をキーにしてファイル管理テーブル内のレコードを取得する。
 *
 * @author ICCWS59
 * @version $Id: FileSeparateDB.java,v 1.3 2003/10/29 02:05:35 hori Exp $
 */
public class FileSeparateDB extends Object{

	/** DB */
	private DBConnectBase db;

	/** ファイル管理情報用マップ */
	protected Map fileSeparateMap = null;

	/** JA単位分割マップ(ファイル分割区分 １のとき使用) */
	protected Map jaHonTenMap     = null;

	/** 店舗単位分割マップ (ファイル分割区分 2のとき使用) */
	protected Map jaTenMap        = null;

	/** その他(データ出力先等)ディレクトリ
	 * <PRE>
	 * index :
	 *	0:	  reserved
	 *	1:	  送信先信連
	 *	2:	  送信先センター
	 *	3:	  帳票コード無効
	 *	4:	  JAコード無効
	 *	5:	  店舗コード無効
	 *	6:	  ファイル区分無効
	 *	7:	  基準日
	 *	8:	  DUST BOX
	 *	9:	  HTTP
	 *	10:	  FTP
	 *</PRE>
	 */
	protected String[] miscDirectory = {
		  null,        "SINREN",     "CENTER",    "CYOHYOERR"
		, "JACODEERR", "TENCODEERR", "FILEKBERR", "KIJUNBIERR"
		, "DUSTBOX",   "HTTP",       "FTP"
	};

	/** SQL 定義 帳票コード,分割区分 取得 */
	protected String SQL_SELECT_CHOHYOCD 
		= "SELECT AADCYOCD,AADBUNKB,AADSOUFU,AADRCVKB,AADTATEN FROM TAAD000 WHERE AADHULFT = ? ";

	/** SQL 定義 JA本店 取得  */
	protected String SQL_SELECT_JA_HONCD
		= "SELECT DQHHONCD FROM DQHJAJM WHERE DQHJACOD= ?";

	/** SQL 定義 店舗存在確認 */
	protected String SQL_SELECT_JA_TEN_CNT
	  = "SELECT COUNT(DQJTENCD) FROM DQJTENM WHERE DQJJACOD= ? AND DQJTENCD= ?";

	/** SQL 定義 基準日取得   */
	protected String SQL_SELECT_TAAA000_KJ
	= "SELECT "
	+ "AAAKJ001,AAAKJ002,AAAKJ003,AAAKJ004,AAAKJ005,AAAKJ006,AAAKJ007,AAAKJ008,AAAKJ009,AAAKJ010,"
	+ "AAAKJ011,AAAKJ012,AAAKJ013,AAAKJ014,AAAKJ015,AAAKJ016,AAAKJ017,AAAKJ018,AAAKJ019,AAAKJ020,"
	+ "AAAKJ021,AAAKJ022,AAAKJ023,AAAKJ024,AAAKJ025,AAAKJ026,AAAKJ027,AAAKJ028,AAAKJ029,AAAKJ030,"
	+ "AAAKJ031,AAAKJ032,AAAKJ033,AAAKJ034,AAAKJ035,AAAKJ036,AAAKJ037,AAAKJ038,AAAKJ039,AAAKJ040,"
	+ "AAAKJ041,AAAKJ042,AAAKJ043,AAAKJ044,AAAKJ045,AAAKJ046,AAAKJ047,AAAKJ048,AAAKJ049,AAAKJ050,"
	+ "AAAKJ051,AAAKJ052,AAAKJ053,AAAKJ054,AAAKJ055,AAAKJ056,AAAKJ057,AAAKJ058,AAAKJ059,AAAKJ060,"
	+ "AAAKJ061 "
	+ "FROM TAAA000 "
	+ "WHERE AAACYOCD = ? AND AAAJACD = ? AND AAATENCD = ?";

	/** PreparedStatement 定義 JA本店 取得    */
	protected PreparedStatement preStmtChoHyoCD = null;

	/** PreparedStatement 定義 JA本店 取得    */
	protected PreparedStatement preStmtJaHonCD = null;

	/** PreparedStatement 定義 店舗存在確認   */
	protected PreparedStatement preStmtJaTenCnt = null;

	/** PreparedStatement 定義 基準日取得確認 */
	protected PreparedStatement preStmtTAAA000_KJ = null;

	/** FileID **/
	protected String FileID;
	
	
	// 定数定義
	/** ファイル分割区分が0以外(1,2) */
	public final static int VALUE_RET_OK           = 0;

	/** ファイル分割区分が00のとき   */
	public final static int VALUE_RET_OK_FILEKBDEF = 1;

	/** ファイル分割区分が01のとき   */
	public final static int VALUE_RET_OK_FILEKB01  = 2;

	/** ファイル分割区分が02のとき*/
	public final static int VALUE_RET_OK_FILEKB02  = 3;

	/** 帳票コードが不正*/
	public final static int VALUE_RET_ERR_CYOHYO   = 4;

	/** JAコードが不正*/
	public final static int VALUE_RET_ERR_JACODE   = 5;

	/** 店舗コードが不正*/
	public final static int VALUE_RET_ERR_TENCOD   = 6;

	/** ファイル分割区分が不正*/
	public final static int VALUE_RET_ERR_FILEKB   = 7;

	/** 基準日が不正 */
	public final static int VALUE_RET_ERR_KIJUNBI  = 8;

	/** ログ取得 */
	private Log log = Log.getInstance();

	/** ファイル内の基準日が全て同一かチェックするための日付保存エリア */
	protected String checkKijunbi = "";

	/** 特殊圧縮ファイル名（プロパティーファイルより取得）<BR>
		帳票ｺｰﾄﾞ.copyName		：圧縮前のファイル名<BR>
		帳票ｺｰﾄﾞ.compressName	：圧縮後のファイル名	*/
	protected Map compressMap;

	/** FileSeparateDBコンストラクタ.
	 *@param s:受信ファイルのFileID
	 */
	public FileSeparateDB(){

		super();

		jaHonTenMap 	= new HashMap();								//JA単位分割用マップ
		jaTenMap		= new HashMap();								//店舗単位分割用マップ
		compressMap		= new HashMap();								//圧縮用マップファイル
		db = DBConnectBase.getInstance();								//DBConnectBase 取得

	}



	//debug////////////////////////////////////
	/** アプリケーションとして動かすときのメイン.
	 * @param s:fileid
	 */
	public static void main(String[] s) {
		if(s.length == 1){
			FileSeparateDB FSDB = new FileSeparateDB();
			FSDB.FileID = s[0];
		}else{
			System.out.println("don't set parameter String[]");
			System.exit(-1);
		}
	}
	//debug////////////////////////////////////


	/** DBに接続.
	 */
	protected void connectDB() throws DoneException{
		
		log.trace("FileSeparateDB.connectDB Start");

		try {
			Connection conn = db.getConnection();						//Connection取得
			// PreparedStatement 作成
			preStmtChoHyoCD   = conn.prepareStatement(SQL_SELECT_CHOHYOCD);		//帳票preStmt作成
			preStmtJaHonCD	  = conn.prepareStatement(SQL_SELECT_JA_HONCD);		//JA本店
			preStmtJaTenCnt   = conn.prepareStatement(SQL_SELECT_JA_TEN_CNT);	//店舗確認
			preStmtTAAA000_KJ = conn.prepareStatement(SQL_SELECT_TAAA000_KJ);	//基準日取得
			
		} catch (Exception e) {
			throw new DoneException(e,"ＤＢコネクション作成に失敗しました。");
		}

		log.trace("FileSeparateDB.connectDB End");
	}


	/** DBと切断
	 */
	public void disconnectDB() throws DoneException{

		log.trace("FileSeparateDB.disconnectDB Start");

		try {
			db.disconnectDB();
		} catch (Exception e) {
			throw new DoneException(e,"ＤＢコネクション切断に失敗しました。");
		}

		log.trace("FileSeparateDB.disconnectDB End");
	}


	/** ファイル管理情報用マップを取得します。
	*/
	public Map getFileSeparateMap(){
		return fileSeparateMap;
	}


	/** ファイル管理情報用マップ<BR>
	/* ファイル管理テーブルからファイル区分等を読み込みマップにセットします。
	 * @param FileID:ファイルID（HALUFTID）
	 *
	 * 受信種類：1(HTTP),2(FTP)
	 * 分割区分：0(分割不要),1(ＪＡ単位),2(店舗単位)
	 * 圧縮区分：0(圧縮不要),1(圧縮必要)
	 * 送付先区分:0(信連、センター以外),1(信連),2(センター)
	 * 
	 */
	public void setFileSeparateMap(String FileID) throws DoneException{

		log.trace("FileSeparateDB.setFileSeparateMap Start");

		Statement stmt = null;
		fileSeparateMap = new HashMap();								//ファイル区分用マップ生成

		try{
			//データ取得時のＳＱＬ(ファイルID（HALUFTID）キィー)
			preStmtChoHyoCD.setString(1,FileID);
			//ＳＱＬのResultSet取得
			ResultSet result = preStmtChoHyoCD.executeQuery();

			while (result.next()) {
				//ファイル管理テーブル(TAAD000)からデータ取得
				String strKey = result.getString("AADCYOCD");		/* 帳票コード */
				//Mapにキー、ヴァリューを格納
				fileSeparateMap.put(strKey+".BUNKB",result.getString("AADBUNKB")); 	/* ファイル分割区分 */
				fileSeparateMap.put(strKey+".SOUFU",result.getString("AADSOUFU")); 	/* ファイル送付先区分 */
				fileSeparateMap.put(strKey+".RCVKB",result.getString("AADRCVKB")); 	/* ファイル受信種類 */
				fileSeparateMap.put(strKey+".TATEN",result.getString("AADTATEN")); 	/* ファイル圧縮区分 */

				// ファイル管理情報用マップのインフォメイション
				String infoMsg = "受信種類=" + result.getString("AADRCVKB");
				infoMsg = infoMsg + ",分割区分=" + result.getString("AADBUNKB");
				infoMsg = infoMsg + ",圧縮区分=" + result.getString("AADTATEN");
				infoMsg = infoMsg + ",送付先区分=" + result.getString("AADSOUFU");
				log.debug(infoMsg);

			}

			// ファイル内の基準日が全て同一かチェックするための日付保存エリアクリア checkKijunBi()で使用する。
			checkKijunbi="";

		} catch (Exception e) {
			throw new DoneException(e,"ファイル管理情報用マップ作成失敗しました。");

		} finally {
			try {
				//クローズする。
				if (stmt != null) stmt.close();

			} catch (SQLException e) {
				throw new DoneException(e,"ファイル管理情報用マップ作成「statementのclose」に失敗しました。");
			}
		}

		if( fileSeparateMap.size() == 0) throw new DoneException("ファイル管理情報用マップ作成「HULFTID("+FileID+")」が不正です。");

		log.trace("FileSeparateDB.setFileSeparateMap End");

	}




	/** 日付の妥当性チェックを行います。
	 * 
	 * @param strDate:日付
	 * @return true or false
	 */

	public boolean checkDate(String strDate){

		String strYear;
		String strMonth;
		String strDay;
		int intYear;
		int intMonth;
		int intDay;
		int dataLength;

		try{
			//データのレングスチェック
			dataLength = strDate.length();
			if(dataLength != 8){
				return false;
			}
			
			//引数を分解する。
			strYear  = strDate.substring(0,4);
			strMonth = strDate.substring(4,6);
			strDay   = strDate.substring(6,8);

			//Int化する。
			intYear  = Integer.parseInt(strYear);
			intMonth = Integer.parseInt(strMonth);
			intDay   = Integer.parseInt(strDay);

			//月チェック
			if(12<intMonth){
				return false;
			}
			//日チェック
			if(intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11){
				if(30<intDay){
					return false;
				}
			}else
			if(intMonth != 2){
				if(31<intDay){
					return false;
				}
			}else
			{
				//閏年チェック(２月の日チェック)
				if(!((intYear % 4) == 0 && (intYear % 100) != 0 || (intYear % 400) == 0)){
					if(28<intDay){
						return false;
					}
				}
				if(29<intDay){
					return false;
				}
			}
		}catch(NumberFormatException e){
			return false;
		}catch(IndexOutOfBoundsException e){
			return false;
		}
		return true;
	}





	/**
	 * 入力データの帳票コード、ＪＡコード、店舗コード、基準日の妥当性をチェックし、処理コードを返します。
	 * 正常データ				VALUE_RET_OK
	 * 帳票コードが不正 		VALUE_RET_ERR_CYOHYO
	 * JAコードが不正 			VALUE_RET_ERR_JACODE
	 * 店舗コードが不正 		VALUE_RET_ERR_TENCOD
	 * ファイル分割区分が不正 	VALUE_RET_ERR_FILEKB
	 * 基準日が不正  			VALUE_RET_ERR_KIJUNBI
	 *
	 * @param dirString	:リターン情報
	 * 							[0]    :JACode
	 * 							[1]    :TENCode
	 * 							[2]    :HTTP/FTP/DUSTBOXﾌｫﾙﾀﾞｰ名
	 * @param chohyo		:帳票コード
	 * @param jacod		:JAコード
	 * @param tencod		:店舗コード
	 * 
	 * @return 処理コード
	 */
	public int getValue(String[] dirString, String chohyo, String jacod, String tencod, String kijunbi) throws DoneException{

		log.trace("FileSeparateDB.getValue Start");

		String strBunkb = (String)fileSeparateMap.get(chohyo+".BUNKB");	//帳票コードよりファイル分割区分取得
		String strRvcKB = (String)fileSeparateMap.get(chohyo+".RCVKB");	//帳票コードよりファイル受信種類取得
		String strHonTenCD = getJaHonTenCD(jacod);		//本店店舗コード取得とJAコード存在するか
		int retCode = 0;				//リターンコード
		dirString[0] = jacod;			//JAｺｰﾄﾞ
		dirString[1] = tencod;			//店舗ｺｰﾄﾞ
		dirString[2] = "";				//出力ﾌｫﾙﾀﾞｰ(DUSTBOX)
	
		if (strBunkb != null) {								//帳票コードは登録されている？

			if (strHonTenCD != null) {							//JAコードは存在するか
				if (getJaTenCnt(jacod,tencod)) {				//店舗存在確認
					if ((strBunkb.equals("0") || strBunkb.equals("1") || strBunkb.equals("2")) && 
						(strRvcKB.equals("1") || strRvcKB.equals("2"))) {	//ファイル分割区分、ファイル受信種類が妥当か
						String retArray[] = new String[3];				//リターン情報
						retCode = getVlaueOK(retArray, chohyo, jacod, tencod, strHonTenCD);
						dirString[0] = retArray[0];				/* JAｺｰﾄﾞ */
						dirString[1] = retArray[1];				/* 店舗ｺｰﾄﾞ */
						dirString[2] = retArray[2];				/* 出力ﾌｫﾙﾀﾞｰ */

						//基準日は正しいか
						if (checkKijunBi(chohyo, retArray[0], retArray[1], kijunbi) == false) {
							retCode = VALUE_RET_ERR_KIJUNBI;
							dirString[2] = miscDirectory[8]+"/"+miscDirectory[7];	/* DUSTBOX(KijyunnbiErr) */
						}

					// ファイル分割区分が無効時の処理
					} else {
						log.info("受信区分又はファイル分割区分が不正です。["+chohyo+"]["+strRvcKB+"]["+strBunkb+"]");
						retCode = VALUE_RET_ERR_FILEKB;
						dirString[2] = miscDirectory[8]+"/"+miscDirectory[6];	/* DUSTBOX(FileKBErr) */
					}

				//店舗コードが存在しない時の処理
				}else{
					log.info("店舗コードが存在しません。["+chohyo+"]["+jacod+"]["+tencod+"]["+kijunbi+"]");
					retCode = VALUE_RET_ERR_TENCOD;
					dirString[2] = miscDirectory[8]+"/"+miscDirectory[5];	/* DUSTBOX(TenCodeErr) */
				}

			//JAコードが存在しない時の処理
			} else {
				log.info("ＪＡコードが存在しません。["+chohyo+"]["+jacod+"]["+tencod+"]["+kijunbi+"]");
				retCode = VALUE_RET_ERR_JACODE;
				dirString[2] = miscDirectory[8]+"/"+miscDirectory[4];	/* DUSTBOX(JACodeErr) */
			}

		//帳票コードが存在しない時の処理
		} else {
			log.info("ＨＵＬＦＴＩＤと帳票コードが一致しません。["+chohyo+"]["+jacod+"]["+tencod+"]["+kijunbi+"]");
			retCode = VALUE_RET_ERR_CYOHYO;
			dirString[2] = miscDirectory[8]+"/"+miscDirectory[3];	/* DUSTBOX(CyohyoErr) */
		}

		log.trace("FileSeparateDB.getValue End");

		return retCode;
	}


	/** 入力データのチェック正常時の処理コードを返します。
	 * ファイル分割区分が0以外(ＪＡ単位､店舗単位)のとき					VALUE_RET_OK
	 * ファイル分割区分が0(分割不要)で送信先区分が0(信連､ｾﾝﾀｰ以外)のとき	VALUE_RET_OK_FILEKBDEF
	 * ファイル分割区分が0(分割不要)で送信先区分が1(信連)のときのとき 		VALUE_RET_OK_FILEKB01
	 * ファイル分割区分が0(分割不要)で送信先区分が2(ｾﾝﾀｰ)のとき			VALUE_RET_OK_FILEKB02
	 *
	 * @param dirString	:リターン情報
	 * 							[0]    :JACode
	 * 							[1]    :TENCode
	 * 							[2]    :出力ﾌｫﾙﾀﾞｰ(HTTP/FTP)
	 * @param chohyo		:帳票コード
	 * @param jacod		:JAコード
	 * @param tencod		:店舗コード
	 * @param strHonTenCD	:本店コード
	 * 
	 * @return 処理コード
	 */

	protected int getVlaueOK(String dirString[], String chohyo, String jacode, String tencod, String strHonTenCD) throws DoneException {

		int retCode = -1;
		String bunkatuKB = (String)fileSeparateMap.get(chohyo+".BUNKB");	//帳票コードよりファイル分割区分取得
		String sendKB = (String)fileSeparateMap.get(chohyo+".SOUFU");		//帳票コードよりファイル送付先区分取得
		String rvcKB = (String)fileSeparateMap.get(chohyo+".RCVKB");		//帳票コードよりファイル受信種類取得

		dirString[0] = jacode;
		dirString[1] = tencod;
		if(rvcKB.equals("1")) dirString[2] = miscDirectory[9];		//HTTP
		if(rvcKB.equals("2")) dirString[2] = miscDirectory[10];	//FTP

		if (sendKB.equals("1")) {					//	ファイル送信先区分:信連
			retCode = VALUE_RET_OK_FILEKB01;			//	リターンコードOK(区分０)
			String strSinren = getJaHonTenCD("3003");		//信連本店店舗コード取得
			if (strSinren != null) {							//JAコードは存在するか
				dirString[0] = "3003";		            		//　戻り値 岩手コード
				dirString[1] = strSinren;              			//　戻り値 店舗コード
			} else {
				strSinren = getJaHonTenCD("3004");			//信連本店店舗コード取得
				if (strSinren != null) {						//JAコードは存在するか
					dirString[0] = "3004";		            	//　戻り値 宮城コード
					dirString[1] = strSinren;              		//　戻り値 店舗コード
				} else {
					strSinren = getJaHonTenCD("3005");		//信連本店店舗コード取得
					if (strSinren != null) {					//JAコードは存在するか
						dirString[0] = "3005";		           	//　戻り値 秋田コード
						dirString[1] = strSinren;           	//　戻り値 店舗コード
					} else {
						dirString[0] = "9999";		           	//　戻り値 JAコード
						dirString[1] = "999";               	//　戻り値 店舗コード
					}
				}
			}
			
		} else if (sendKB.equals("2")) {			//	ファイル送信先区分:センター
			retCode = VALUE_RET_OK_FILEKB02;			//	リターンコードOK(区分０)
			dirString[0] = "9999";		            	//　戻り値 JAコード
			dirString[1] = "999";                 		//　戻り値 店舗コード
		} else {									//	ファイル送信先区分:その他？
			if (bunkatuKB.equals("1")) {				//ファイル分割区分 JA単位  (１)
				retCode = VALUE_RET_OK;						//	リーターンコードOK
				dirString[0] = jacode;							//	戻り値 JAコード
				dirString[1] = strHonTenCD;						//	戻り値 本店コード
			} else if (bunkatuKB.equals("2")) {		//ファイル分割区分 店舗単位(２)
				retCode = VALUE_RET_OK;						//	リーターンコードOK
				dirString[0] = jacode;							//	戻り値 JAコード
				dirString[1] = tencod;							//	戻り値 店舗コード
			} else if (bunkatuKB.equals("0")) {		//ファイル分割区分 分割不要(０)
				retCode = VALUE_RET_OK_FILEKBDEF;			//	リターンコードOK(送信先Defalut)
				dirString[0] = jacode;						//	戻り値 JAコード
				dirString[1] = tencod;						//	戻り値 店舗コード
			}						
		}
		return retCode;
	}


	/** ＪＡ本店コードを取得します。
	 * 次回より、Map(jaHonTenMap)よりアクセスします。
	 * 
	 * @param jacod:JAコード
	 * @return 本店コード
	 */
	protected String getJaHonTenCD(String jacod) throws DoneException{

		try{
			String strHonTenCD = (String)jaHonTenMap.get(jacod);			//マップより検索
			if (strHonTenCD == null) {										//ない場合
				preStmtJaHonCD.setString(1,jacod);							//SQL発行
				ResultSet rs = preStmtJaHonCD.executeQuery();
				if (rs.next() == true) {										//結果あり
					strHonTenCD = rs.getString(1);							//値取得
					if (strHonTenCD != null) {								//取得成功
						jaHonTenMap.put(jacod,strHonTenCD);					//JAコードをキーに本店コードをマップにセット
					} else {
						log.info("ＪＡコードが存在しません。["+jacod+"]");
						return null;
					} 
				} else {
					log.info("ＪＡコードが存在しません。["+jacod+"]");
					return null;
				} 
			}
			return strHonTenCD;											//戻り値 本店コード

		}catch(Exception e){
			throw new DoneException(e,"["+jacod+"]の本店コード取得に失敗しました。");
		}
	}


	/** ＪＡ店舗コードを取得します。
	 * 次回より、Map(jaTenMap)よりアクセスします。
	 * 
	 * @param jacod:JAコード
	 * @param tencd:店舗コード
	 * @return 店舗コードがあった場合 true
	 */
	protected boolean getJaTenCnt(String jacod,String tencd) throws DoneException{

		try{

			Vector vecTenCD = (Vector)jaTenMap.get(jacod);				//店舗コードのVectorを取得
			if(vecTenCD != null){										//取得失敗
				if(vecTenCD.indexOf(tencd) != -1) return true;		//Vector内に店舗コードがある 戻り値 true/成功
				/* 2003.06.13 修正店舗コード=999はマスタになくてもＯＫとします。 */
				if(tencd.equals("999")) return true;
			}

			preStmtJaTenCnt.setString(1,jacod);							//SQL実行
			preStmtJaTenCnt.setString(2,tencd);
			ResultSet rs = preStmtJaTenCnt.executeQuery();
			if(rs.next() == true){										//データあり
				if(rs.getInt(1) == 1){									//店舗コードあり
					if(vecTenCD == null){
						vecTenCD = new Vector();
						vecTenCD.add(tencd);
						jaTenMap.put(jacod,vecTenCD);
					}else{
						vecTenCD.add(tencd);
					}
					return true;
				}else if(rs.getInt(1) == 0 && tencd.equals("999")){	//店舗コードが「999」
					/* 追加：20030630 修正店舗コード=999はマスタになくてもＯＫとします */
					if(vecTenCD == null){
						vecTenCD = new Vector();
						vecTenCD.add(tencd);
						jaTenMap.put(jacod,vecTenCD);
					}else{
						vecTenCD.add(tencd);
					}
					return true;
				}
			}

			log.info("店舗コードが存在しません。["+jacod+"]["+tencd+"]");
			return false;

		}catch(Exception e){
			throw new DoneException(e,"店舗コード取得に失敗しました。["+jacod+"]["+tencd+"]");
		}

	}


	/** 基準日のチェックを行います。
	 * 配信管理テーブル個別明細レコードの基準日の最大値(最新基準日)と比較します。
	 * 
	 * @param chohyo:帳票コード
	 * @param jacod:JAコード
	 * @param tencd:店舗コード
	 * @param kijunbi:基準日
	 * @return 店舗コードがあった場合 true
	 */
	public boolean checkKijunBi(String chohyo, String jacod, String tencod, String kijunbi) throws DoneException{

		int max = 0;													//最新の基準日を保持

		if (checkKijunbi.length() == 0) {								//ファイル内の最初の基準日保存
			checkKijunbi = kijunbi;
		}

		if (!checkKijunbi.equals(kijunbi)) {							//ファイル内全レコードの基準日が同一でなければ基準日エラー
			log.info("基準日の異なるデータが存在します。["+chohyo+"]["+jacod+"]["+tencod+"]["+kijunbi+"]");
			return false;				
		}
		
		try{

			if( checkDate(kijunbi) == false) {							//日付の文字列は正しいかチェック
				log.info("基準日が日付ではありません。["+chohyo+"]["+jacod+"]["+tencod+"]["+kijunbi+"]");
				return false;				
			}
			int intkj = Integer.parseInt(kijunbi);						//整数へ変換

			preStmtTAAA000_KJ.setString(1,chohyo);						//SQL 実行開始
			preStmtTAAA000_KJ.setString(2,jacod);
			preStmtTAAA000_KJ.setString(3,tencod);

			ResultSet rs = preStmtTAAA000_KJ.executeQuery();
			if(rs.next() == true){										//データ取得設定した場合基準日のチェック開始

				for(int i=1; i<=61 ; i++){								//61データ分ループ開始
					int kj = rs.getInt(i);								//整数でデータ取得
					if(kj > max) max = kj;								//最大値更新処理
					if(kj == intkj) return true;						//同一基準日ならば上書き 戻り値 true/成功
				}
				if(max < intkj) return true;							//最大値よりも大きい 新規データ 戻り値 true/成功
				log.info("基準日が最新基準日より以前です。["+chohyo+"]["+jacod+"]["+tencod+"]["+kijunbi+"]["+max+"]");
				return false;											//基準日 失敗
			}

			return true;												//新規レコードのため基準日チェックなし戻り値 true/成功

		}catch(Exception e){
			throw new DoneException(e,"基準日が不正です。["+chohyo+"]["+jacod+"]["+tencod+"]["+kijunbi+"]");
		}

	}


	/** ディストラクタ.
	 * ＤＢのコネクションを閉じます。
	 */
	protected void finalize() throws java.lang.Throwable {

		try {
			//クローズする。
			db.disconnectDB();
		} catch (Exception e) {
			throw new DoneException(e,"ＤＢファイナライズに失敗しました。");
		}finally{
			super.finalize();
		}

	}


	/** その他(データ出力先等)ディレクトリを設定します。
	 * <PRE>
	 * index :
	 *	0:	  reserved
	 *	1:	  送信先信連
	 *	2:	  送信先センター
	 *	3:	  帳票コード無効
	 *	4:	  JAコード無効
	 *	5:	  店舗コード無効
	 *	6:	  ファイル区分無効
	 *	7:	  基準日
	 *	8:	  DUST BOX
	 *	9:	  HTTP
	 *	10:	  FTP
	 *</PRE>
	 */
	public void setMiscDirectory(int i, String dir) {

		this.miscDirectory[i] = dir;

	}


	/** その他(データ出力先等)ディレクトリを取得します。
	 * <PRE>
	 * index :
	 *	0:	  reserved
	 *	1:	  送信先信連
	 *	2:	  送信先センター
	 *	3:	  帳票コード無効
	 *	4:	  JAコード無効
	 *	5:	  店舗コード無効
	 *	6:	  ファイル区分無効
	 *	7:	  基準日
	 *	8:	  DUST BOX
	 *	9:	  HTTP
	 *	10:	  FTP
	 *</PRE>
	 */
	public String getMiscDirectory(int i) {

		return this.miscDirectory[i];

	}	


	/** 特殊圧縮ファイル名（プロパティーファイルより取得）<BR>
	* <B>Format</B><BR>
		帳票ｺｰﾄﾞ.copyName		：圧縮前のファイル名<BR>
		帳票ｺｰﾄﾞ.compressName	：圧縮後のファイル名
	*/
	public Map getCompressMap(){
		return compressMap;
	}


	/**プロパティーファイルから圧縮ファイルパスを取得してマッピングします。
	 * 圧縮前と圧縮後のファイル名をディフォルト値以外にしたい場合に設定します。
	 *  @param map  圧縮ファイルのマップ
	 *  @param prop プロパティファイル
	 */
	protected void setCompressMap(Properties prop) throws DoneException{
		
		for (Enumeration e = prop.propertyNames(); e.hasMoreElements() ;) {

			String tmp = ((String)e.nextElement());
			if(tmp.startsWith("SateiPath.")){
				String value1 = null;
				String value2 = null;
				String value3 = null;
				tmp = prop.getProperty(tmp);

				if(tmp != null){
					StringTokenizer st = new StringTokenizer(tmp,":");
					if(st.countTokens() == 1){
						value1 = st.nextToken();
						value2 = value1;
						value3 = value1+".cab";
					}else if(st.countTokens() == 2){
						value1 = st.nextToken();
						value2 = st.nextToken();
						value3 = value2+".cab";
					}else if(st.countTokens() == 3){
						value1 = st.nextToken();
						value2 = st.nextToken();
						value3 = st.nextToken();
					}else{
						throw new DoneException("圧縮ファイルの指定が間違っています。["+tmp+"]");
					}
					compressMap.put(value1+".copyName",value2);		/* 圧縮前のファイル名 */
					compressMap.put(value1+".compressName",value3); /* 圧縮後のファイル名 */
				}
			}
		}
	}


}