﻿package filesplit2;

import java.text.*;

/** DB(TA000)用ファイル詳細部分クラス*/
public class Taaa000FileDetail extends Object{

	/** 世代番号 */
	private int    sedaiNo;

	/** 基準日*/
	private String kijunBi;

	/** レコード数 */
	private int    recCnt;

	/** 受信フラグ */
	private String reciveFlag;

	/** 受信日 */
	private String reciveDate;

	/** コンストラクタ (初期値設定).
	 * <table border="1">
	 * <tr><td>世代番号  </td><td>99  </td></tr>
	 * <tr><td>基準日    </td><td>NULL</td></tr>
	 * <tr><td>レコード数</td><td>0   </td></tr>
	 * <tr><td>受信フラグ</td><td>0   </td></tr>
	 * <tr><td>受信日    </td><td>NULL</td></tr>
	 * </table>
	 */
	public Taaa000FileDetail(){
		sedaiNo    = 99;
		kijunBi    = "NULL";
		recCnt	   = -1;
		reciveFlag = "";
		reciveDate = "NULL";
	}


	/** ファイル詳細設定(一括設定).
	 *
	 * @param sedaiNo 世代番号
	 * @param kijunBi 基準日
	 * @param recCnt  受信レコード数
	 * @param reciveFlag 受信フラグ
	 * @param reciveDate 受信日
	 */
	public void set(String sedaiNo, String kijunBi, String recCnt, String reciveFlag, String reciveDate ){
		setSedaiNo(sedaiNo);
		setKijunBi(kijunBi);
		setReciveCnt(recCnt);
		setReciveFlag(reciveFlag);
		setReciveDate(reciveDate);
	}


	/** 世代番号取得.
	 * @return 世代番号
	 */
	public String getSedaiNo(){
		if(0 < sedaiNo && sedaiNo <= 61){
	        NumberFormat nf = new DecimalFormat("00");
	        return nf.format(this.sedaiNo);
		}else{
			return "NULL";
		}
    }


	/** 基準日取得.
	 * @return 基準日
	 */
	public String getKijunBi(){
		return kijunBi;
	}


	/** 受信レコード数取得. 2004.12.16 MOD
	 * @return 受信レコード数
	 */
	public String getReciveCnt(){
		if(0 < recCnt){
			return String.valueOf(recCnt);
		}else{
			return "0";
		}
	}


	/** 受信フラグ取得.
	 * @return 受信フラグ
	 */
	public String getReciveFlag(){
		return reciveFlag;
	}


	/** 受信日取得.
	 * @return 受信日
	 */
	public String getReciveDate(){
		return reciveDate;
	}


	/** 世代番号設定.
	 * @param sedaiNo 世代番号
	 */
	public void setSedaiNo(String sedaiNo){
		try{
			this.sedaiNo = Integer.parseInt(sedaiNo);
		}catch(Exception e){
			this.sedaiNo = 99;
		}
	}


	/** 基準日設定.
	 * @param kijunBi 基準日
	 */
	public void setKijunBi(String kijunBi){
		this.kijunBi = kijunBi;
	}


	/** 受信レコード数設定.
	 * @param recCnt 受信レコード数
	 */
	public void setReciveCnt(String recCnt){
		if(recCnt!=null){
			this.recCnt = Integer.parseInt(recCnt);
		}else{
			this.recCnt = 0;
		}
	}


	/** 受信レコード数設定.
	 * @param recCnt 受信レコード数
	 */
	public void setReciveCnt(int recCnt){
		this.recCnt = recCnt;
	}


	/** 受信フラグ設定.
	 * @param reciveFlag 受信フラグ
	 */
	public void setReciveFlag(String reciveFlag){
		this.reciveFlag = reciveFlag;
	}


	/** 受信日設定.
	 * @param reciveDate 受信日
	 */
	public void setReciveDate(String reciveDate){
		this.reciveDate = reciveDate;
	}


	/** CVS出力（カンマ区切り SQL作成用）.
	 * @return カンマ区切り文字列
	 */
	public String toCVS(){
		StringBuffer sb = new StringBuffer();
		sb.append(getSedaiNo());
		sb.append(",");
		sb.append(getKijunBi());
		sb.append(",");
		sb.append(getReciveCnt());
        sb.append(",'");
        sb.append(getReciveFlag());
        sb.append("',");
		sb.append(getReciveDate());
		return sb.toString();
	}


	/** ログ用出力作成
	 * @return ログ用文字列
	 */
	public String toString(){
		String ret =
		  "SEDAI        : " + getSedaiNo()    + "\n"
		+ "KIJUNBI      : " + getKijunBi()    + "\n"
		+ "RECIVE COUNT : " + getReciveCnt()  + "\n"
		+ "RECIVE FLAG  : " + getReciveFlag() + "\n"
		+ "RECIVE DATE  : " + getReciveDate() + "\n";

		return ret;
	}


}

