﻿package filesplit2;

import filesplit2.util.DoneException;

/** ファイル区分、帳票コード、JA・店舗コードエラー用ファイル管理クラス*/
public class FileDataError extends FileData{
	String header = "";

	/** コンストラクタ
	 * @param cyohyoCode	帳票コード
	 * @param jacode		JAコード
	 * @param tencode 		店舗コード
	 * @param kijunbi 		基準日
	 * @param FilePath 	ファイルパス
	 * @param filename1  	通常ファイル名
	 * @param filename2  	圧縮ファイル名
	 * @param strCabarc 	圧縮.EXEパス
	 * @param strEncoding 	文字エンコーディング
	 */
	public FileDataError(String cyohyoCode,
							String jacode, 
							String tencode, 
							String kijunbi, 
							String FilePath,
							String filename1,
							String filename2,
							String strCabarc,
							String strEncoding
						  ) throws DoneException{

		super(cyohyoCode, jacode, tencode, kijunbi, FilePath,
			   filename1, filename2, strCabarc, strEncoding);

		log.trace("FileDataError.FileDataError() Start");

		dbwrite = false;

		header = cyohyoCode + jacode + tencode + kijunbi;

		log.trace("FileDataError.FileDataError() End");
	}


	/** ファイルパス取得 
	 * @return ファイルパス [ファイルルート]/[super.getFilePath()]
	 */
	public String getFilePath()
	{

		String ret =  super.getFilePath();

		return ret;
	}


	/** ファイルパス取得 
	 * @param 追記するデータ
	 */
	public void addData(String data) throws Exception{

		int cnt=0;

		try{

			outputBuffered.write(data);
			outputBuffered.newLine();         

			try{
				cnt = Integer.parseInt(tmpFileDetail.getReciveCnt())+1;
			}catch(Exception e){
				cnt = 1;
			}

			//今回世代の配信管理テーブルのデータ数
			tmpFileDetail.setReciveCnt(cnt);

		}catch(Exception e){

			throw new DoneException(e,"ファイル書き込み（エラーファイル）に失敗しました");

		}

	}

	/** DBより読み込み 
	 * DBより読み込みは、行わないためオーバーライドした関数
	 * 管理するファイル詳細用クラスは、1つのみ作成（世代は1世代のみ）
	 */
	public void doRead(){

		taaa000.setFileDetailCNT(1);

	}
}