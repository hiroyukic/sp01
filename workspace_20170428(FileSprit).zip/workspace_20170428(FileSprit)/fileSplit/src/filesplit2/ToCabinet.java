﻿package filesplit2;

import filesplit2.util.Log;
import filesplit2.util.DoneException;

/** ファイル圧縮
 */
public class ToCabinet extends Object{
	protected Process process;
	protected Runtime runtime;
	protected String strCommand;
	protected Log log = Log.getInstance();

	/** コンストラクタ
	 *cabarc.exeのパスはcommandであること。(例えば、C:\CABUTIL\BIN\CABARC)
	 *inFile,outFileのパスはフルパスであること。
	 */
	public ToCabinet(String cabarc, String inFile,String outFile) throws DoneException{

		super();

		log.trace("ToCabinet.ToCabinet start");
		log.trace("CABARC.EXE PATH SET:"+cabarc+" inFilePath:"+inFile+" outFilePath:"+outFile);

		//引数のどれかがnullの場合は即終了＞実際は起こらないﾊｽﾞ...
		if(cabarc.equals("") || inFile.equals("") || outFile.equals("")){
			throw new DoneException("指定されたパラメータの数が不一致です");
		}

		// '/'場合'\'に置換する。
		if(cabarc.indexOf("/") != -1){
			cabarc = cabarc.replace('/','\\');
		}
		if(inFile.indexOf("/") != -1){
			inFile = inFile.replace('/','\\');
		}
		if(outFile.indexOf("/") != -1){
			outFile = outFile.replace('/','\\');
		}

		//コマンドラインの指定＞cabarc [command] [outFilePath] [inFilePath]
		strCommand = new String();
		strCommand = cabarc + ".exe N " + outFile + " " + inFile;   //Eclipseでテストする場合のコマンドライン
//		strCommand = cabarc + " N " + outFile + " " + inFile;
		log.trace("Command Line : " + strCommand);

		try{
			//runtimeのオブジェクト取得
			runtime = Runtime.getRuntime();

			log.trace("Runtime Execute...");

			//プロセス作成＞runtimeによってコマンドラインの実行
			process = runtime.exec(strCommand);

			//プロセス終了までwait後、戻り値によってプロセス終了結果を確認
			int i = process.waitFor();

			//プロセス終了結果：０は正常終了／それ以外は異常終了＞exceptionを投げる。
			if(i != 0){

				log.trace("Runtime Execute...error");
				throw new DoneException("圧縮時にエラー発生しました");
			}

			log.trace("Runtime Execute...complete");

		}catch(Exception e){
			log.trace("Runtime... error");
			throw new DoneException(e,"ランタイム実行時にエラーが発生しました");
		}
	}
}
