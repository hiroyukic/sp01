﻿package filesplit2;

import java.io.*;
import java.text.*;

import filesplit2.util.DoneException;
import filesplit2.util.Log;


/** ファイル書き込み用クラス.
 *  条件を満たしたデータをisAddData関数により判断し.
 *  addData関数により追加する。
 */
public class FileData extends  Object{

	/** 書き込み用バッファストリーム */
	protected BufferedWriter outputBuffered = null;   

	/** 配信管理テーブル クラス */
	protected Taaa000 taaa000 = null;

	/** 配信管理テーブル更新用　世代詳細クラス*/
	protected Taaa000FileDetail tmpFileDetail = null;

	/** DB書き込みフラグ [書き込み:true/書き込まない:FLSE]*/
	protected boolean dbwrite = true;

	/** 書込みファイルのルートパス*/
	private String FileRootPath = "";

	/** 帳票コード */
	private String CyohyoCode = "";

	/** JAコード */
	private String JaCode = "";

	/** 店舗コード */
	private String TenCode = "";

	/** 最新基準日 */
	private String KijunBi = "";

	/**通常ファイル名*/
	private String FileName1 = "";      

	/**圧縮ファイル名（圧縮ありの場合は｢ファイル名｣.cab */
	private String FileName2 = "";

	/** プロパティファイルからCABARC.EXEのコマンド(※<CABARC.EXEの格納ディレクトリ> + "CABARC")*/
	private String passCabarc;

	/** 文字エンコーディング */
	private String Charset;

	/**圧縮処理用のパスのFILE型<COMP:圧縮ファイル/BAK:圧縮ファイルバックアップ>*/
	private File COMP,BAK;

	/**ログ */
	protected Log log = Log.getInstance();



	/* ===============================================================================
		コンストラクタ
	=============================================================================== */
	/** コンストラクタ
	 */
	public FileData(){
	}


	/** コンストラクタ
	 * @param chohyoCode 	帳票コード
	 * @param jaCode 		JAコード
	 * @param tenCode 		店舗コード
	 * @param kijunbi 		最新基準日
	 * @param fileRoot 	出力ファイルルートパス
	 * @param filename1  	通常ファイル名
	 * @param filename2  	圧縮ファイル名（圧縮なしの場合はスペース）
	 * @param strCabarc 	圧縮.EXEパス
	 * @param strEncoding 	文字エンコーディング
	 */
	public FileData(String cyohyoCode, 
					 String jaCode, 
					 String tenCode,
					 String kijunbi,
					 String fileRoot,
				 	 String filename1,
					 String filename2,
					 String strCabarc,
					 String strEncoding
					 ) throws DoneException{

		log.trace("FileData.FileData() Start");

																
		CyohyoCode = cyohyoCode;	/* 帳票コード */
		JaCode = jaCode;			/* JAコード */
		TenCode = tenCode;			/* 店舗コード */
		KijunBi = kijunbi;			/* 最新基準日 */
		FileRootPath = fileRoot;	/* 出力ファイルルートパス */
		FileName1 = filename1 ;		/* 通常ファイル名 */
		FileName2 = filename2 ;		/* 圧縮ファイル名 */
		passCabarc = strCabarc ;	/* CABARC.EXEのコマンド */
		Charset = strEncoding;		/* 文字エンコーディング */

		boolean flag_kijunbi = true;

		//配信管理テーブル クラス
		taaa000 = new Taaa000();					//配信管理テーブルクラス変数作成

		//キーになる値
		taaa000.setCyoHyoCode(cyohyoCode);			//帳票コード
		taaa000.setJaCode(jaCode);					//JAコード
		taaa000.setTenCode(tenCode);				//店舗コード

		//DB読み込み 上記設定値をキーにしてデータを読み込む
		taaa000.doRead();

		//最新世代番号の更新処理
		int sedai = Integer.parseInt(taaa000.getNewSedai()) + 1;		//更新最新世代
		int maxsedai = taaa000.getFileDetailCNT();						//最大管理世代数
		if (maxsedai < sedai) sedai = 1;				//管理世代数を超えた場合更新最新世代を「１」に

		//同一基準日での再処理か
		for(int i=0; i<maxsedai; i++){						
			if(taaa000.getKijunBi(i) != null && taaa000.getKijunBi(i).equals(kijunbi)){
				//再処理
				sedai=Integer.parseInt(this.taaa000.getSedaiNo(i));
				flag_kijunbi = false;
			}
		}

		//配信管理テーブル更新用　世代詳細クラスに値設定
		tmpFileDetail = new Taaa000FileDetail();			//編集用一時変数作成

		//今回世代設定
		NumberFormat nf = new DecimalFormat("00");
		tmpFileDetail.setSedaiNo(nf.format(sedai));

		//配信管理テーブル更新（最新世代、最新基準日）ただし再処理時は更新しない。
		if(flag_kijunbi){
			taaa000.setNewSedai(nf.format(sedai));
			taaa000.setNewKijunBi(kijunbi);										//最新基準日更新
		}

		//今回情報設定
		tmpFileDetail.setKijunBi(kijunbi);		/* 基準日 */
		tmpFileDetail.setReciveDate("NULL");	/* 受信日 */	
		tmpFileDetail.setReciveFlag("0");		/* 受信済みフラグ */

		log.trace("FileData.FileData() End");

	}


	/** ファイルパスを取得
	 *  @return ファイルパス [ルート]/[ＪＡコード店舗コード]/[帳票コード]
	 */
	public String getFilePath(){

		String ret = FileRootPath + "/" + JaCode + TenCode + "/" + CyohyoCode;

		return ret;
	}


	/**
	 *  ファイルをオープン
	 *  FileLocation->[FileRootPath]/[JaCode][TenCd]/[CYOHYOCODE]/[FILEID]
	 */
	public void openFile() throws Exception{

		log.trace("FileData.openFile=" + getFilePath()+ "/" + FileName1+ " Start");
		
		if(outputBuffered == null){
			File file = new File( getFilePath() );
			file.mkdirs();

			File sameFile = new File(getFilePath() + "/" + FileName1);
			if(sameFile.exists()) sameFile.delete();

			if( Charset == null || Charset.length() == 0 ){	/* デフォルトの文字エンコーディング */
				outputBuffered = new  BufferedWriter( new OutputStreamWriter(new FileOutputStream(getFilePath() + "/" + FileName1)) );
			} else {
				outputBuffered = new  BufferedWriter( new OutputStreamWriter(new FileOutputStream(getFilePath() + "/" + FileName1), Charset) );
			}

		}
		
		log.trace("FileData.openFile End");

	}


	/**
	 *  指定されたデータを追記
	 *  @param 追記するデータ
	 */
	public void addData(String data) throws Exception{

		int cnt=0;

		try{

			outputBuffered.write(data);
			outputBuffered.newLine();         

			try{
				cnt = Integer.parseInt(tmpFileDetail.getReciveCnt())+1;
			}catch(Exception e){
				cnt = 1;
			}

			//今回世代の配信管理テーブルのデータ数
			tmpFileDetail.setReciveCnt(cnt);

		}catch(Exception e){

			throw new DoneException(e,"ファイル書き込みに失敗しました");

		}

	}


	/**
	 *  設定されている情報と引数を比較
	 *  @param  帳票コード
	 *  @param  ＪＡコード
	 *  @param  店舗コード
	 *  @param  基準日
	 *  @return true  :等しい場合
	 *  @return false :等しくない場合
	 */
	public boolean isAddData(String cyohyoCode, String jaCode, String tenCode, String kijunBi){

		log.trace("FileData.isAddData() Start");

		if (cyohyoCode.equals(CyohyoCode) && 
		    jaCode.equals(JaCode) && 
		    tenCode.equals(TenCode) && 
		    kijunBi.equals(KijunBi)){

			log.trace("FileData.isAddData() End->true");
			return true;
		}

		log.trace("FileData.isAddData() End->false");
		return false;
	}


	/**
	 *  ファイルをクローズ
	 */
	public void  closeFile() throws DoneException{

		log.trace("FileData.closeFile Start");

		try{

			//配信管理テーブルの今回世代更新データ設定
			int sedai = Integer.parseInt(tmpFileDetail.getSedaiNo());
			taaa000.fileDetail[sedai-1] = tmpFileDetail;

			// バッファリングされた出力ストリームをフラッシュします。
			//この処理により、バッファの内容はすべて基礎の出力ストリームに書き込まれます。
			outputBuffered.flush(); 

			if(dbwrite == true){
				taaa000.doWrite();			/* taaa000の世代更新 */

				String dirPath = getFilePath() + "/";
				File dir = new File(dirPath);
				String list[];

				if( dir.isDirectory() ){	/* このファイルがディレクトリであるかどうかを判定 */
					list = dir.list();		/* このディレクトリにあるファイルおよびディレクトリを示す文字列の配列 */
					// 世代管理対象外データの検索
					for(int i=0; i<list.length;i++){
						for(int j=0; j<taaa000.fileDetail.length; j++){

							//通常ファイル
							if( list[i].equals(CyohyoCode+"."+taaa000.fileDetail[j].getKijunBi()) ){
								list[i] = null;
								break;
							}
							//圧縮ファイル
							if( list[i].equals(CyohyoCode+"."+taaa000.fileDetail[j].getKijunBi()+".cab") ){
								list[i] = null;
								break;
							}
							//圧縮バックアップファイル
							if( list[i].equals(CyohyoCode+"."+taaa000.fileDetail[j].getKijunBi()+".bak") ){
								list[i] = null;
								break;
							}
							//今回作成ファイル
							if( list[i].equals(FileName1) ){
								list[i] = null;
								break;
							}
							if (FileName2 != null && FileName2.trim().length() != 0){
								if( list[i].equals(FileName2) ){
									list[i] = null;
									break;
								}
							}
						}
					}
					/* 世代管理対象外データの削除 */
					for(int i=0; i<list.length;i++){
						if(list[i] != null){
							File deleteFile = new File( dirPath+"/"+list[i] );
							deleteFile.delete();
						}
					}
				}

				// 出力ストリームをクローズします。
				outputBuffered.close();
			
				//ファイルを圧縮します。
				if (FileName2 != null && FileName2.trim().length() != 0){
					Compress(FileName1,FileName2);		//ファイル圧縮
				}
			
			} else {

				// エラー発生　出力ストリームをクローズします。
				outputBuffered.close();
			
			}

		}catch(Exception e){

			throw new DoneException(e,"ファイル書き込み（クローズ）に失敗しました");

		}

		log.trace("FileData.closeFile End");

	}


	/**
	 *  ファイルを削除
	 *  @return	true  :削除成功
	 *				false :削除失敗
	 */
	public boolean deleteFile(int err){

		try{
			if(err != 0) dbwrite = false;
			outputBuffered.close();
			File file = new File(getFilePath() + "/" + FileName1);
			file.delete();

		}catch(Exception e){
			return false;
		}

		return true;
	}


	/** 各種情報を取得
	 *  @return 各種情報
	 */
	public String toString(){

		String ret =
		  "File [" + getFilePath() + "/" + FileName1 + "]\n"
		+ "DB WRITE [" + dbwrite + "]\n"
		+ "BFR COMP FILENAME [" + FileName1 +"]\n"
		+ "AFR COMP FILENAME [" + FileName2 +"]\n"
		+ "CLASS NAME [" + super.toString() +"]\n"
		+ tmpFileDetail.toString();

		return ret;
	}



	/** ファイルの圧縮 ADD 05.10.13 
	** 　ファイル管理テーブル(TAAD000)のファイル圧縮要否
	** 区分(AADTATEN)が"1"の場合、圧縮クラス<ToCabinet>
	** を呼び出す。
	*/
	public void  Compress(String fileName1, String fileName2) throws DoneException{

		log.trace("FileData.Compress() Start");

		//圧縮処理用のパス(cabのパス／bakのパス)
		String filePath_comp;
		String backupPath = new String();
		String inFile = new String();
		String dirPath = new String();
		int indexa;
		boolean ret = false;

		try{

			//圧縮後に格納するフルパスを作成します。
			filePath_comp = getFilePath() + "/" + fileName2;
			COMP = new File(filePath_comp);

			//cabファイルが存在する場合はリネームで.bak化
			if(COMP.exists()){

				//バックアップファイルのパスの作成とファイル名の取得をします。
				indexa = filePath_comp.lastIndexOf(".");
				if(indexa==-1){
					//拡張子が無い場合ファイル名の最後に.bakの拡張子をつけます。
					backupPath = filePath_comp + ".bak";
				}else{
					//拡張子がある場合は拡張子を.bakに変更します。
					backupPath = filePath_comp.substring(0,indexa) + ".bak";
				}
				BAK = new File(backupPath);

				//バックアップファイルが存在する場合は削除します。
				if(BAK.exists()) BAK.delete();

				//既存のcabファイルをbakファイルにリネームします。
				ret = COMP.renameTo(BAK);
				if(!ret){
					throw new DoneException("圧縮ファイルの作成失敗 > ファイル：" + filePath_comp + "にアクセスできません。");
				}
			}

			//圧縮する元のファイルパスを取得します。
			inFile = getFilePath() + "/" + fileName1;

			//inFileをfileNameにcabファイル化します。
			ToCabinet toCab = new ToCabinet(passCabarc,inFile,filePath_comp);

		}catch(Exception e){
			throw new DoneException(e,"圧縮ファイルの作成に失敗しました");
		}

		log.trace("FileData.Compress() End");

	}

}
