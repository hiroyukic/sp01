﻿package filesplit2.util;

import java.util.*;
import java.text.*;
import java.io.*;

public class Log{

	/*　*******************************************
	グローバル変数
	*※トレースレベル：1:trace,2:debug,3:info／低1←2←3高<詳細度>
	*
	*********************************************/
	protected String fn            = new String();	//出力ファイルパス
	protected int traceLevel       = 0;				//トレースレベル ※別欄参照※
	protected PrintStream outMsgPS = null;			//
	protected OutputStream os      = null;			//printstream用
	protected int bufferSize = 1024;					//バッファーサイズ

	/** 唯一のLogInstanceインスタンス */
	private static Log LogInstance = null;

	/** 唯一のLogInstanceインスタンス取得 */
	public static synchronized Log getInstance()
	{
		if(LogInstance == null)
			LogInstance = new Log();
		return LogInstance;
	}


	/* ===============================================================================
		コンストラクタ
	=============================================================================== */

	/**
	 * コンストラクタ
	 */
	private Log()
	{
		super();
		//デフォルト(traceLevel:1)(ファイル名:out.log)
		chgLevel(1);
		outMsgPS = System.out;
	}
	

	/* ===============================================================================
		メソッド
	=============================================================================== */

	/**
	* initialize(変数のグローバル化、インスタンス作成)
	* @param	i:Integer     :traceLevel
	*        	s:String      :出力ファイル名
	*        	bufferSize    :バッファーサイズ
	*/
	public void init(int i, String s, int bufferSize) throws Exception
	{
		this.bufferSize = bufferSize;
		init(i, s);
	}
	

	/**
	* initialize(変数のグローバル化、インスタンス作成)
	* @param	i:Integer     :traceLevel
	*        	s:String      :出力ファイル名
	*/
	public void init(int i,String s) throws Exception
	{

		try{
			//ファイル名,トレースレベル受け取り。
			fn = s;
			traceLevel = i;
			if(os ==null){		//プリントストリーム作成
				os = new BufferedOutputStream(new FileOutputStream(fn,true), bufferSize);
				outMsgPS = new PrintStream(os);

			}

		}catch(Exception e){
			outMsgPS = System.out;
			throw new Exception(e);
		}
	}

	/**
	* traceLevel変更メソッド
	* @param i:Integer:traceLevel
	*/
	public void chgLevel(int i)
	{
		traceLevel = i;
	}

	/********************************************
	指定されたメッセージ出力メソッド
	*param@ s:String:メッセージ
	*********************************************/
	public void outLog(String s, int level)
	{
		try{
			if(level >= traceLevel){
				String dateTime = "";
				Date d = null;;
				SimpleDateFormat sdf = null;

				//日付時間取得
				sdf = new SimpleDateFormat("yy/MM/dd HH:mm:ss SSS");
				d = new Date();
				dateTime = sdf.format(d);

				//メッセージ出力
				outMsgPS.println(">" + dateTime + ">" + s);

				//書き終えるごとにPSをフラッシュする。
				outMsgPS.flush();
			}
		}catch(Exception e){
			System.out.println(">" + s);
		}
	}

	/**
	 * 指定されたメッセージ出力メソッド traceLevel=1,2,3
	 * @param s:String:メッセージ
	 */
	public void trace(String s)
	{
		outLog("trace:"+s,1);
	}

	/**
     * 指定されたメッセージ出力メソッド traceLevel=2,3
	 * @param s:String:メッセージ
	 */
	public void debug(String s)
	{
		outLog("debug:"+s,2);
	}
	
	/**
	 * 指定されたメッセージ出力メソッド traceLevel=3
	 * @param s:String:メッセージ
	 */
	public void info(String s)
	{
		outLog("info:"+s,3);
	}


	/**
	 * 指定されたメッセージ出力メソッド traceLevel=3
	 * @param s:String:メッセージ
	 */
	public void error(String s)
	{
		outLog("error:"+s,3);
	}


	/**
	 * 指定されたメッセージ出力メソッド traceLevel=3
	 * @param s:String:メッセージ
	 */
	public void error(Exception ex, String s)
	{
		try{
			outLog("error:"+s,3);
			ex.printStackTrace(outMsgPS);
			outMsgPS.flush();
		}catch(Exception e){
			ex.printStackTrace(System.out);
		}
	}


	/**
	 * finalize(プリントストリームをフラッシュ＆クローズ)
	 */
	protected void finalize() throws Throwable
	{
		try{ //フラッシュ＆クローズ
			if(os != null){
				outMsgPS.println("finalize");
				outMsgPS.flush();
				outMsgPS.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}


	/* ===============================================================================
		デッバク用メソッド
	=============================================================================== */

	protected Vector vecTime = new Vector();
	protected Map mapFuncName = new HashMap();
	/**
	 *  ファンクション開始時間を出力します。
	 * @param className : String : ファンクション名
	 */
	public void beginFunction(String funcName)
	{
		if(traceLevel == 2){
			Long time = new Long(System.currentTimeMillis());
			String  s="";
			vecTime.add(0,time);
			mapFuncName.put(time,funcName);
			for(int i=1; i<vecTime.size();i++){
				s += " ";
			}
			outLog("function->:"+s+funcName,2);
		}
	}

	/**
	 *  ファンクション終了時間を出力します。
	 * @param className : String : ファンクション名
	 */
	public void endFunction()
	{
		if(traceLevel == 2){
			Long    time     = (Long)vecTime.get(0);
			String  funcName = (String)mapFuncName.get(time);
			String  s;
			vecTime.remove(0);
			mapFuncName.remove(time);
			s =  "function<-:";
			for(int i=0; i<vecTime.size();i++){
				s += " ";
			}
			s =  s+funcName;
			s += " Time="+ (System.currentTimeMillis() - time.longValue());
			outLog(s,2);
		}
		
	}


	/**
	 *  アプリケーション開始時間を出力します。
	 * @param className : String : クラス名
	 */
	public void beginApp(String className)
	{
		if(traceLevel == 3){
			if(className==null) className = "";
			info("Application -> " + className);
		}
	}

	/**
	 *  アプリケーション終了時間を出力します。
	 * @param className : String : クラス名
	 */
	public void endApp(String className)
	{
		if(traceLevel == 3){
			if(className==null) className = "";
			info("Application <- " + className);
		}
	}


}
