﻿/*
 * DBコネクション管理クラス.
 *  DBコネクションを管理するクラス。アプリケーション毎に唯一のコネクションを
 *  生成接続して、必要なクラスへ提供する。
 *
 *	version		V01.00	2009/05/25	T.itoh	Open
 *	
 */

package filesplit2.util;

import java.sql.*;

/** DBコネクション管理クラス.
 *  DBコネクションを管理するクラス。アプリケーション毎に唯一のコネクションを
 *  生成接続して、必要なクラスへ提供する。
 *  使用する前にgetInstance()関数で初期化の必要がある
 * <pre>
 *   使用例
 *     DBConnectBase DBCB = DBConnectBase.getInstance();
 *     DBCB.init( .... ) //アプリケーションで1度のみ呼び出し可能
 *     Connection conn = DBCB.getConnection()
 *             :
 *             :
 *     DBCB.disconnectDB
 * </pre>
 */
public class DBConnectBase
{

	/** DBドライバ */
	protected String DB_DRIVER_NAME = "";
	/** DB 名 */
	protected String DB_DB_NAME 	= "";
	/** DB ユーザー名 */
	protected String DB_USER		= "";
	/** DB パスワード */
	protected  String DB_PASSWORD	= "";

	/** DB コネクション  */
	private Connection conn = null;

	/** 唯一のDBConnectBaseインスタンス */
	private static DBConnectBase DBInstance = null;



	/** コンストラクタ */
	protected  DBConnectBase()
	{
		super();
	}



	/** 初期化.
	 * @param DBDriver DBドライバ名
	 * @param DBName DB名
	 * @param DBUser ユーザ名
	 * @param DBPassword パスワード
	 */
	public void init(String DBDriver, String DBName, String DBUser, String DBPassword) throws Exception
	{

		if(conn == null){				//すでにinitが呼ばれているか
			DB_DRIVER_NAME = DBDriver;		//DBドライバ名
			DB_DB_NAME	   = DBName;		//DB名
			DB_USER 	   = DBUser;		//ユーザ名
			DB_PASSWORD    = DBPassword;	//パスワード
		}else{
			throw new Exception("データベース接続の設定は変更できません。");
		}

	}

	/** インスタンス取得 */
	public static synchronized DBConnectBase getInstance()
	{
		if(DBInstance == null)
		  DBInstance = new DBConnectBase();
		return DBInstance;
	}



	/** DBに接続.
	 */
	public Connection getConnection() throws Exception
	{
		try {
            if(conn == null){
    			//JDBCDriverのロード//DB2 JDBCDriver名 - COM.ibm.db2.jdbc.app.DB2Driver
        		Class.forName(DB_DRIVER_NAME);
            	//データベース接続の取得//DB2におけるデータベースURLの指定 - jdbc:db2:DatabeseName
                conn = DriverManager.getConnection(DB_DB_NAME,DB_USER,DB_PASSWORD);
            }
			return conn;

		} catch (Exception e) {
			throw new Exception(e); 
		}
	}



	/** DB切断
	 */
	public void disconnectDB() throws Exception
	{
		try {
			//クローズする。
			if(conn != null){
				conn.close();
				conn = null;
			}
		} catch (SQLException e) {
			throw new Exception(e);
		}
	}



    /** ディストラクタ.
     * DBコネクションを閉じる
     */
    protected void finalize() throws Exception
    {

        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
 			throw new Exception(e);
        }finally{
			try {
				super.finalize();
			} catch (Throwable e) {
				throw new Exception(e);
	        }
		}

    }


}
