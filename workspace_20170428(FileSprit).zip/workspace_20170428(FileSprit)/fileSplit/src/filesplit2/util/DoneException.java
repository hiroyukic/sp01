﻿package filesplit2.util;

public class DoneException extends Exception{

	/** ログ出力クラス */
	private Log log = Log.getInstance();

	//コンストラクタ
	public DoneException(){
		super();
	}

	public DoneException(String msg){
		super(msg);
		log.error(msg);
	}

	public DoneException(Exception e, String msg){
		super(msg + "\n" + e.toString());
		log.error(e,msg);
//		e.printStackTrace(System.out);
		
	}

//	public static void main(String[] args){
//		DoneException de = new DoneException();
//	}
}

