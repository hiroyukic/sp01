﻿/*
 * ファイルの入力クラス
 *
 *	version		V01.00	2009/05/25	T.itoh	Open
 *
 */

package filesplit2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import filesplit2.util.DoneException;

/**
 * ファイルの入力クラスです。<br>
 * 入力還元ファイルの読み込みを制御します。
 *
 */
public class FileReader {

	/* ===============================================================================
		private メンバ
	=============================================================================== */
	/** 入力ファイル名 */
	private String inputFileName = null;   
	/** 文字エンコーディング */
	private String inputCharset = null;   
	/** 入力ファイル */
	private FileInputStream inputFileStream = null;   
	/** 入力バッファー */
	private BufferedReader inputBuffered = null;   

	/* ===============================================================================
		コンストラクタ
	=============================================================================== */
	/**
	 * 入力ファイルを設定します。
	 *
	 *  @param		FileName	入力ファイル名
	 *  			charset		文字エンコーディング
	 *								ディフォルト	MS932
	 *								ＸＭＬファイル	UTF-8
	 *
	 */
	public FileReader( String FileName, String Charset ) {
		
		/* 入力ファイル名を設定します。*/
		inputFileName = FileName;         
		/* 文字エンコーディングを設定します。*/
		inputCharset = Charset;         

	}


	/* ===============================================================================
		メソッド
	=============================================================================== */
	/**
	 * 入力ファイルをオープンします。
	 *
	 */
	public void openFileReader() throws DoneException {
		
		try {
			inputFileStream = new FileInputStream(inputFileName);         
			/* 文字エンコーディングを設定します。*/
			if( inputCharset == null || inputCharset.length() == 0 ){	/* デフォルトの文字エンコーディング */
				inputBuffered = new  BufferedReader( new InputStreamReader(inputFileStream) );
			} else {
				inputBuffered = new  BufferedReader( new InputStreamReader(inputFileStream, inputCharset) );
			}

		} catch (IOException e) {
			throw new DoneException(e,"入力ファイル（" + inputFileName + "）のオープンに失敗しました");
		}

	}


	/**
	 * 入力ファイルをクローズします。
	 *
	 */
	public void closeFileReader() throws DoneException {         

		try {
			inputBuffered.close();         

		} catch (IOException e) {
			throw new DoneException(e,"入力ファイル（" + inputFileName + "）をクローズできません。");
		}

	}         
	/**
	 * 入力ファイルを読み込み、データレコードを１件ずつ返します。
	 * データがない場合は null を返します。
	 *
	 */
	public String getDataRecord() throws DoneException {
		
		try {
			String strRecord = null;
			do{
				strRecord = inputBuffered.readLine();
				if( strRecord == null ) return null;
			}while( strRecord.length() == 0 );
			return strRecord;

		} catch (IOException e) {
			throw new DoneException(e,"入力ファイル（" + inputFileName + "）が読み込みできません。");
		}

	}   

      
}
