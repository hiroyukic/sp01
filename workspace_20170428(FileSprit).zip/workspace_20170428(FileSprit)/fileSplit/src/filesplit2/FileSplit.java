﻿/*
 * ファイル分割処理
 *
 *	version		V01.00	2009/05/25	T.itoh	Open
 *
 */

package filesplit2;

import java.io.*;
import java.util.*;

import filesplit2.util.Log;
import filesplit2.util.DBConnectBase;
import filesplit2.util.DoneException;

/**
 *  入力還元ファイルを条件にしたがって振り分けます。
 *
 */
public class FileSplit{

	/* ===============================================================================
		private メンバ
	=============================================================================== */
	/** 入力ファイルリーダー */
	private FileReader filereader;
	/** 出力先ディレクトリ */
	private String outDir;
	/** 分割要用出力ファイルデータクラスを集めたマップ */
	private List fileDataList;
	/** 分割不要用出力ファイルデータクラス */
	private FileData fileDataKB0;
	/** ファイル管理用DBクラス */
	private FileSeparateDB fileSeparateDB;
	/** DBコネクション管理クラス */
	private DBConnectBase dbcb;
	/** ログ出力クラス */
	private Log log = Log.getInstance();
	/** 圧縮(CAB形式)時に必要な.EXEのパス */
	private String strCabarc;
	/** 文字エンコーディング */
	private String strEncoding;
	/** ファイル拡張子 */
	private String fileExtension;
	
	/* ===============================================================================
		private メンバ　ヘッダーレコードレイアウト
	=============================================================================== */
	/** 帳票コード長 */
	private final int HEAD_LEN_CYOHYOCODE = 8;
	/** JAコード長 */
	private final int HEAD_LEN_JACODE 	= 4;
	/** 店舗コード長 */
	private final int HEAD_LEN_TENCODE	= 3;
	/** 基準日長 */
	private final int HEAD_LEN_KIJUNBI	= 8;
	/** データ長 */
	private final int HEAD_LEN_DATALEN	= 4;
	/** レコード件数 */
	private final int HEAD_LEN_DATASU	= 7;
	/** 次ファイル有無 */
	private final int HEAD_LEN_EXISTNEXT	= 1;
	/** ヘッタ長 定数 */
	private final int HEAD_LEN			= HEAD_LEN_CYOHYOCODE
											+ HEAD_LEN_JACODE
											+ HEAD_LEN_TENCODE
											+ HEAD_LEN_KIJUNBI
											+ HEAD_LEN_DATALEN
											+ HEAD_LEN_DATASU
											+ HEAD_LEN_EXISTNEXT;
	
	/* ===============================================================================
		コンストラクタ
	=============================================================================== */
	/** FileSplitコンストラクタ. */
	public FileSplit() {
		super();
	}


	/* ===============================================================================
		メソッド
	=============================================================================== */
	/** 出力先ディレクトリ設定
	 * @param strOutDir 出力先ディレクトリ
	 */
	public void setOutDir(String strOutDir){
		outDir = strOutDir;
	}


	/** 出力先ディレクトリ取得
	 * @return 出力先ディレクトリ
	 */
	public String getOutDir(){
		return outDir;
	}


	/** データベース・ログ・ファイル分割区分の初期化を行う
	 * @param propFile 設定プロパティーファイル
	 */
	public void init(String propFile) throws DoneException
	{

		log.trace("FileSplit.init() Start");

		try{
			/* Property File 読み込み */
			/** 設定プロパティ */
			Properties prop = new Properties();
			prop.load(new FileInputStream(new File(propFile)));

			/* LOG 設定 */
			String log_file  = prop.getProperty("Log_File","");
			int log_level = Integer.parseInt(prop.getProperty("Log_Level"));
			if(log_file.length() != 0){
				log.init(log_level, log_file);
			}

			/* データベースの設定 */
			outDir = prop.getProperty("OutPutDirectory","");
			String DBDriver = prop.getProperty("DBDriver");
			String DBName = prop.getProperty("DBName");
			String DBUser = prop.getProperty("DBUser");
			String DBPassword = prop.getProperty("DBPassword");

			dbcb = DBConnectBase.getInstance();
			dbcb.init(DBDriver, DBName, DBUser, DBPassword);

			///////////////// ファイル分割用クラス設定 /////////////////
			fileSeparateDB	= new FileSeparateDB();
			fileSeparateDB.setMiscDirectory(1 ,prop.getProperty("SinrenDirectory","Sinren"));
			fileSeparateDB.setMiscDirectory(2 ,prop.getProperty("CenterDirectory","Center"));
			fileSeparateDB.setMiscDirectory(3 ,prop.getProperty("CyohyoErrDirectory","CyohyoErr"));
			fileSeparateDB.setMiscDirectory(4 ,prop.getProperty("JACodeErrDirectory","JACodeErr"));
			fileSeparateDB.setMiscDirectory(5 ,prop.getProperty("TenCodeErrDirectory","TenCodeErr"));
			fileSeparateDB.setMiscDirectory(6 ,prop.getProperty("FileKBErrDirectory","FileKBErr"));
			fileSeparateDB.setMiscDirectory(7 ,prop.getProperty("KijunBiErrDirectory","KijunBiErr"));
			fileSeparateDB.setMiscDirectory(8 ,prop.getProperty("DustBoxDirectory","DustBox"));
			fileSeparateDB.setMiscDirectory(9 ,prop.getProperty("HttpDirectory","Http"));
			fileSeparateDB.setMiscDirectory(10,prop.getProperty("FtpDirectory","Ftp"));

			/////////////// 圧縮(CAB形式)時に必要な.EXEのパス ////////
			strCabarc = prop.getProperty("CabarcPath");

			///////////////////圧縮ファイルの指定////////////////////////////////////////
			fileSeparateDB.setCompressMap(prop);

			/////////////// 文字エンコーディング ////////
			strEncoding = prop.getProperty("CharacterEncoding");

			/////////////// ファイル拡張子 ////////
			fileExtension = prop.getProperty("FileExtension");

			log.trace("FileSplit.init() End");

		}catch(Exception e){
			throw new DoneException(e,"初期設定に失敗しました。"); 
		}

	}


	/**
	 *  データ振り分け処理実行
	 * 
	 */
	public void doExecute(String inFileName) throws DoneException
	{

		log.trace("FileSplit.doExecute() Start");

		String DataRecords = null;			//ヘッタ・データ分割用変数

		try{

			filereader = new FileReader(inFileName,strEncoding);	//読込みファイル設定
			filereader.openFileReader();					//読込みファイルオープン

			/* ファイルID取得（HALFT）*/
			String fieldKey = new File(inFileName).getName();
			log.info("データ振り分け処理を行います。["+fieldKey+"]");

			/* DBコネクション設定 */
			fileSeparateDB.connectDB();						//ファイル管理テーブル(TAAD000)より読み込み

			fileSeparateDB.setFileSeparateMap(fieldKey);	//ファイル管理テーブル(TAAD000)よりファイル分割区分等を取得しMapにセット 
			fileDataList = new Vector();					//ファイル分割処理クラステーブル
			fileDataKB0 = null;							//ファイル分割処理クラステーブル（分割不要）

			//////////////データ読み出し・振り分け//////////////
			int nextExist = 1;
			String[] strHeaders = null;			//ヘッタ分解後の配列
			while(nextExist != 0){
				DataRecords = getHeadRecord();
				if(DataRecords != null){
					strHeaders = doSplitHeader(DataRecords);		//ヘッタ分解後の配列（エラーメッセージ用）
					nextExist  = Integer.parseInt(strHeaders[6]);	//次ファイル有無
					doSeparateData(DataRecords);
				}else{
					//次ファイル有りでデータがなかった場合 ⇒ エラー
					log.info(getStrHeader(strHeaders));
					throw new DoneException("ヘッダ異常：次のデータが存在しません。");
				}
			}
			//次ファイル無しでデータがある場合 ⇒ エラー
			DataRecords = getHeadRecord();
			if(DataRecords != null) {
				strHeaders = doSplitHeader(DataRecords);	//ヘッタ分解後の配列
				log.info(getStrHeader(strHeaders));
				throw new DoneException("ヘッダ異常：次のデータが存在します。\n"); 
			}

			//////////////エラーファイル作成されたかチェック//////////////
			boolean isFail=false;
			String msg="ヘッダ異常エラーデータ：\n";
            for(int i=0; i< fileDataList.size(); i++){
				if(Class.forName("filesplit2.FileDataError").isInstance(fileDataList.get(i))){
					FileData fileData = ((FileData) fileDataList.get(i));
					fileData.closeFile();
					msg += fileData.toString() + "\n";
					isFail = true;
				}
			}
			if(isFail == true){
				throw new DoneException(msg);
			}

			//////////////ファイル書き出し・DB書き込み//////////////
            for(int i=0; i< fileDataList.size(); i++){
                FileData fileData = ((FileData) fileDataList.get(i));				//ファイル書き出し、旧ファイル削除、DB書き込み
				fileData.closeFile();
                log.debug(fileData.toString());
            }

			//////////////DBコネクション開放//////////////
			fileSeparateDB.disconnectDB();								//DB開放

		}catch(DoneException e){
			//エラーデータ後処理
			doErrorHandling(inFileName);
			throw new DoneException("データ振り分け処理に失敗しました。"); 

		} catch (Exception e) {
			//エラーデータ後処理
			doErrorHandling(inFileName);
			throw new DoneException(e,"データ振り分け処理に失敗しました。");
		}

		log.trace("FileSplit.doExecute() End");

	}


	/**
	 *  バイト配列のヘッダ情報を、Stringの配列に変換する。
	 * index 0: 帳票コード
	 *		 1: JAコード
	 *		 2: 店舗コード
	 *		 3: 基準日
	 *		 4: データレングス
	 *       5: データ数(レコード数)
	 *       6: 次ファイル有無(次のファイルヘッダが存在するか？)
	 *
	 * @return String[]
	 * @param byteHeader ヘッダのバイト配列
	 */
	protected String[] doSplitHeader( String HeaderData ) throws DoneException{

		int intWork = 0;
		int pos = 0;
		String[] retHeader = new String[7];
		
		try{

			retHeader[0] = HeaderData.substring(pos, HEAD_LEN_CYOHYOCODE);
			pos += HEAD_LEN_CYOHYOCODE;
			retHeader[1] = HeaderData.substring(pos, pos+HEAD_LEN_JACODE);
			pos += HEAD_LEN_JACODE;
			retHeader[2] = HeaderData.substring(pos, pos+HEAD_LEN_TENCODE);
			pos += HEAD_LEN_TENCODE;
			retHeader[3] = HeaderData.substring(pos, pos+HEAD_LEN_KIJUNBI);
			pos += HEAD_LEN_KIJUNBI;
			retHeader[4] = HeaderData.substring(pos, pos+HEAD_LEN_DATALEN);
			pos += HEAD_LEN_DATALEN;
			retHeader[5] = HeaderData.substring(pos, pos+HEAD_LEN_DATASU);
			pos += HEAD_LEN_DATASU;
			retHeader[6] = HeaderData.substring(pos, pos+HEAD_LEN_EXISTNEXT);
		
			//ヘッダチェック
			intWork = Integer.parseInt(retHeader[4]);
			intWork = Integer.parseInt(retHeader[5]);
			intWork = Integer.parseInt(retHeader[6]);

			return retHeader;

		}catch(Exception e){
			throw new DoneException(e,"ヘッダ情報に異常があります。\n" + getStrHeader(retHeader)); 
		}

	}


	/**
	 *  ヘッダ情報配列のインフォメイションを返します。
	 * @return String		ヘッダ情報インフォメイション	
	 * @param 	String[]	ヘッダ情報配列
	 */
	protected String getStrHeader(String[] strHeader) throws DoneException{

		String ret = "";
		
		ret = ret + "帳票コード=" + strHeader[0];
		ret = ret + ",ＪＡコード=" + strHeader[1];
		ret = ret + ",店舗コード=" + strHeader[2];
		ret = ret + ",基準日=" + strHeader[3];
		ret = ret + ",データレングス=" + strHeader[4];
		ret = ret + ",データ数=" + strHeader[5];
		ret = ret + ",次ファイル有無=" + strHeader[6];
		
		return ret;

	}


	/**
	 *  データの振り分け処理を行います。
	 * データの処理タイプの判定を行い、FileDataListに処理詳細クラス(データも一緒に)を保管します。
	 * @param byteHeader ヘッダ情報および個別データ
	 */
	protected void doSeparateData(String strHeader) throws DoneException {

		log.trace("FileSplit.doSeparateData Start");

		String[] strHeaders = doSplitHeader(strHeader);	//ヘッタ分解後の配列
		log.debug(getStrHeader(strHeaders));

		try{

			String[] dirString = new String[3];
			//格納先ファイルを判定する
			int retCode = fileSeparateDB.getValue(	
							dirString			//リターン情報(JACode,TENCode,HTTP/FTP/DUSTBOXﾌｫﾙﾀﾞｰ名)
						  , strHeaders[0]		//（引数）帳票コード
						  , strHeaders[1]		//（引数）JAコード
						  , strHeaders[2]		//（引数）店舗コード
						  , strHeaders[3]);		//（引数）基準日
			int dataCount  = Integer.parseInt(strHeaders[5]);	//レコード件数

			if (retCode != FileSeparateDB.VALUE_RET_OK_FILEKBDEF
				&& retCode != FileSeparateDB.VALUE_RET_OK_FILEKB01
				&& retCode != FileSeparateDB.VALUE_RET_OK_FILEKB02) {	/* ＪＡ単位、店舗単位、エラー（分割不要以外） */

				//ファイル詳細クラスが格納されたLISTを検索する。
				int i=0;
				for(; i< fileDataList.size(); i++){
					FileData fileData =(FileData)fileDataList.get(i);
					if (fileData.isAddData(	//追加可能か判定する以下の条件で、
							  strHeaders[0]			//帳票コード
							, dirString[0]			//JAコード
							, dirString[1]			//店舗コード
							, strHeaders[3])) {		//基準日

						for(int j=0;j<dataCount;j++){
							//出力ファイルへデータを追加
							fileData.addData(getDataRecord());
						}
						return;					//ループを抜ける
					}
				}

				if (i == fileDataList.size()) {			//ファイル詳細クラスが見つからなかった
					FileData fileData;	//ファイル詳細クラス作成
					String strFileName1 = getFileName1(strHeaders[0],strHeaders[3],fileExtension); 
					String strFileName2 = getFileName2(strHeaders[0],strHeaders[3]);

					switch(retCode){					//作成される詳細クラスの種類判定
						case FileSeparateDB.VALUE_RET_OK :		        //正常終了のとき
						log.debug("FileDate Set [1,"+strHeaders[0]+","+dirString[0]+","+dirString[1]+","+strHeaders[3]+","+outDir+"/"+dirString[2]+","+strFileName1+","+strFileName2);
							fileData = new FileData(		//通常のファイル詳細クラス作成
									  strHeaders[0]				//帳票コード
									, dirString[0]				//JAコード（変換後）
									, dirString[1]				//店舗コード（変換後）
									, strHeaders[3]				//基準日
									, outDir+"/"+dirString[2]	//FileRootPath+送信先区分(HTTP/FTP)
									, strFileName1				//通常ファイル名 
									, strFileName2				//圧縮ファイル名
									, strCabarc					//圧縮.EXEパス
									, strEncoding);				// 文字エンコーディング
							break;
						default:					//その他エラー時（DB未登録等）
						log.debug("FileDate Set [E,"+strHeaders[0]+","+strHeaders[1]+","+strHeaders[2]+","+strHeaders[3]+","+outDir+"/"+dirString[2]+","+strFileName1+","+strFileName2);
							fileData = new FileDataError(	//エラー時のファイルクラス
									  strHeaders[0]				//帳票コード
									, strHeaders[1]				//JAコード
									, strHeaders[2]				//店舗コード
									, strHeaders[3]				//基準日
									, outDir+"/"+dirString[2]	//FileRootPath+DUSTBOX+DUSTBOXｻﾌﾞﾌｫﾙﾀﾞｰ
									, strFileName1     			//通常ファイル名 
									, strFileName2     			//圧縮ファイル名
									, strCabarc					//圧縮.EXEパス
									, strEncoding);				// 文字エンコーディング
							break;
						
					}

					fileData.openFile();			//ファイルオープン
					for(int j=0;j<dataCount;j++){
						//出力ファイルへデータを追加
						fileData.addData(getDataRecord());
					}
					fileDataList.add(fileData);			//ファイル検索LISTに追加
				}

			}else{
				if(fileDataKB0 == null){

					//分割区分０用のオブジェクトが作成されていない場合新規にオブジェクトを作成します。
					String strFileName1 = getFileName1(strHeaders[0],strHeaders[3],fileExtension); 
					String strFileName2 = getFileName2(strHeaders[0],strHeaders[3]);
					log.debug("FileDate Set [0,"+strHeaders[0]+","+dirString[0]+","+dirString[1]+","+strHeaders[3]+","+outDir+"/"+dirString[2]+","+strFileName1+","+strFileName2);
					switch(retCode){				//作成される詳細クラスの種類判定
						case FileSeparateDB.VALUE_RET_OK_FILEKBDEF :		//正常終了（ファイル区分0のとき）
						case FileSeparateDB.VALUE_RET_OK_FILEKB01 :		//正常終了（ファイル区分0のとき）
							fileDataKB0 = new FileData(	//ファイル区分０の詳細クラス作成
									  strHeaders[0]			//帳票コード
									, dirString[0]			//JAコード（変換後）
									, dirString[1]			//店舗コード（変換後）
									, strHeaders[3]			//基準日
									, outDir+"/"+dirString[2]	//FileRootPath+送信先区分(HTTP/FTP)
									, strFileName1     		//通常ファイル名 
									, strFileName2     		//圧縮ファイル名
									, strCabarc				//圧縮.EXEパス
									, strEncoding);			// 文字エンコーディング
							break;
						case FileSeparateDB.VALUE_RET_OK_FILEKB02 :		//正常終了（ファイル区分0のとき）
						fileDataKB0 = new FileData(		//ファイル区分０の詳細クラス作成
									  strHeaders[0]			//帳票コード
									, "9999"  				//JAコード
									, "999"					//店舗コード
									, strHeaders[3]			//基準日
									, outDir+"/"+dirString[2]	//FileRootPath+送信先区分(HTTP/FTP)
									, strFileName1			//通常ファイル名 
									, strFileName2	    	//圧縮ファイル名
									, strCabarc				//圧縮.EXEパス
									, strEncoding);			// 文字エンコーディング
							break;
					}

					if(fileDataKB0 != null){
						fileDataKB0.openFile();				//ファイルオープン
						fileDataList.add(fileDataKB0);		//ファイル検索LISTに追加
					}
				}

				for(int j=0;j<dataCount;j++){
					//出力ファイルへデータを追加
					fileDataKB0.addData(getDataRecord());
				}
			}

		}catch(Exception e){
			throw new DoneException("書き込みエラーが発生しました。");
        }

		log.trace("FileSplit.doSeparateData() End");

	}



	/**
	 *  オープンされたファイルからヘッダを取得して返す。
	 * @return ヘッダ
	 */
	public String getHeadRecord() throws DoneException{

		log.trace("FileSplit.getHeadRecord Start");

		String rtnHead = null;				//ヘッダレコード

		try{
			//ファイルヘッダ取得
			rtnHead = filereader.getDataRecord();

			//レコードが終わりに達していなければ処理
			if(rtnHead != null){

				//レコード長／レコード件数取得
				String[] strHeaders = doSplitHeader(rtnHead);	//ヘッダ分解後の配列

				log.trace("FileSplit.getHeadRecord End->");

				return rtnHead;

			}else{

				log.trace("FileSplit.getHeadRecord End->");

				return null;

			}

		}catch(Exception e){
			throw new DoneException(e,"ヘッダ読み込みに失敗しました。[" + rtnHead + "]");
		}

	}



	/**
	 *  オープンされたファイルからデータを取得して返す。
	 * @return データ
	 */
	public String getDataRecord() throws DoneException{

		String rtnData = null;				//データレコード

		try{
			//ファイルヘッダ取得
			rtnData = filereader.getDataRecord();

			//レコードが終わりに達していればエラー
			if(rtnData == null){
				//読み込んだデータがない場合 ⇒ DoneException
				throw new DoneException("ヘッダ情報内のレコード件数と実レコード件数が合いません。");

			}else{
				return rtnData;

			}

		}catch(Exception e){
			throw new DoneException(e,"データ読み込みに失敗しました。[" + rtnData + "]");
		}

	}




	/** 通常ファイル名を取得します。
	 *  @return ファイル名(HTTP) → [CYOHYOCODE].[KIJUNBI]
	 *           ファイル名(FTP)  →[CYOHYOCODE]
	 */
	public String getFileName1(String chohyoCD, String kijunbi, String extension){

		String ret = "";
		// ファイル受信種類を取得
		String rcvkb = "0";
		if (fileSeparateDB.getFileSeparateMap().get(chohyoCD+".RCVKB") != null){
			rcvkb = (String)fileSeparateDB.getFileSeparateMap().get(chohyoCD+".RCVKB");
		}

		if (rcvkb.equals("1")){				// HTTPの時
			// ファイル拡張子を設定
			if (extension == null){
				ret = chohyoCD + "." + kijunbi;		
			}else{
				ret = chohyoCD + "." + kijunbi + "." + extension;		
			}
		}else{									// FTPの時
			ret = chohyoCD;
		}
		/* 特殊ファイル名の指定がある場合 */
		if (!rcvkb.equals("1")){				// HTTPの時は無視
			if(fileSeparateDB.getCompressMap().get(chohyoCD+".copyName") != null){
				ret = (String)fileSeparateDB.getCompressMap().get(chohyoCD+".copyName");
			}
		}

		return ret;
	}


	/** 圧縮ファイル名を取得します。
	 *  @return ファイル名(HTTP) → [CYOHYOCODE].[KIJUNBI].cab、
	 *           ファイル名(FTP)  → [CYOHYOCODE].cab、
	 */
	public String getFileName2(String chohyoCD, String kijunbi){

		String ret = "";
		// ファイル受信種類を取得
		String rcvkb = "0";
		if (fileSeparateDB.getFileSeparateMap().get(chohyoCD+".RCVKB") != null){
			rcvkb = (String)fileSeparateDB.getFileSeparateMap().get(chohyoCD+".RCVKB");
		}
		// ファイル圧縮区分を取得
		String taten = "0";
		if (fileSeparateDB.getFileSeparateMap().get(chohyoCD+".TATEN") != null){
			taten = (String)fileSeparateDB.getFileSeparateMap().get(chohyoCD+".TATEN");
		}

		if (taten.equals("1")){				// 圧縮の時
			if (rcvkb.equals("1")){				// HTTPの時
				ret = chohyoCD + "." + kijunbi + ".cab";		
			}else{									// FTPの時
				ret = chohyoCD + ".cab";
			}
			/* 特殊ファイル名の指定がある場合 */
			if (!rcvkb.equals("1")){				// HTTPの時は無視
				if(fileSeparateDB.getCompressMap().get(chohyoCD+".compressName") != null){
					ret = (String)fileSeparateDB.getCompressMap().get(chohyoCD+".compressName");
				}
			}
		}

		return ret;
	}



	/** エラーハンドリング処理
	 * @param e Exception
	 * @param msg メッセージ
	 */
	public void doErrorHandling(String inFileName) {

		log.trace("FileSplit.doErrorHandling Start");

		if(fileDataList != null){

			File fin  = new File(inFileName);
			log.info("異常終了後処理->" + fin.getName());

			try{
				for(int i=0; i<fileDataList.size();i++){
					FileData fileData = ((FileData) fileDataList.get(i));
					if(!Class.forName("filesplit2.FileDataError").isInstance(fileData)){
						if(fileData.deleteFile(1)){
						}
					}
				}

				String outFileName = getOutDir()+"/"+fileSeparateDB.getMiscDirectory(8)+"/"+fin.getName();
				File fout = new File(outFileName);
				File dir  = new File(getOutDir()+"/"+fileSeparateDB.getMiscDirectory(8)+"/");
				dir.mkdirs();
				int len=0;
			
				BufferedInputStream  bis = new BufferedInputStream( new FileInputStream(fin)  );
				BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(fout));
				byte byteBuff[] = new byte[4096];


				while((len =  bis.read(byteBuff)) != -1) bos.write(byteBuff,0,len);

				bos.flush();
				bos.close();

				log.info("異常終了後処理 完了");

			}catch(Exception ex){
				log.info("異常終了後処理 失敗" + ex);
			}

		}

		log.trace("FileSplit.doErrorHandling End");

	}


}
