﻿/*
 * ファイル授受システム　ファイル分割ツールＷＡＨ対応版
 *   FileSplit2.java
 * 
 * Ｈｕｌｆｔ集信後処理で起動され、ファイル管理テーブル(帳票ごとに分割方法等を定義)に従い、
 * 入力還元データをファイル授受システムの提供先、帳票ごとフォルダーへ振分けを行います。
 * 
 * ＷＡＨ対応版の新規機能
 *   可変長還元データの取込み
 *   ＸＭＬ還元データ(UTF-8ｺｰﾄﾞ)の取込み
 *
 *	version		V01.00	2009/05/25	T.itoh	Open
 *	
 */

import filesplit2.FileSplit;

/**
 * ファイル授受システム　ファイル分割ツールＷＡＨ対応版
 * 
 *	@version	01.00	2009/05/25
 *	@author	T.itoh
 *
 */
public class FileSplit2 extends java.lang.Object{

	/** アプリケーションとして動かすときのメインです。
	 *
	 * @param args[0]    設定プロパティーファイル
	 *         args[1～X] 入力還元ファイル
	 *
	 */
	public static void main(String args[]) {
		try{

			FileSplit filesplit = new FileSplit();
			filesplit.init(args[0]);				/* 設定プロパティーファイル */
			for(int i=1; i < args.length; i++){
				filesplit.doExecute(args[i]);				/* ファイル分割処理 */
				System.out.println("ファイルスプリット処理終了["+args[i]+"]");
			}
		}catch(Exception e){
			System.out.println("ファイルスプリット異常終了");
			System.exit(-1);
		}
	}

}
