﻿//<!--
// ----------------------------------------------------------------
//  [名前]		DDA0000MDLoad
//
//  [パラメータ]		なし
//
//  [概要]		MainDispのonLoad。
//
//  [履歴]		2002/06/26	新規	M.Horii
// ----------------------------------------------------------------
function DDA0000MDLoad(){
	parent.SubDisp.location.href = "./sd_000.html";
	parent.CmdMenu.location.href = "./cm_000.html";
	parent.SubMenu.location.href = "./sm_000.html";
	parent.HeadDisp.location.href = "./hd_000.html";
	parent.MainDisp.location.href = "./mdDAA100.html";

}

//-->

//<!--
// ----------------------------------------------------------------
//  [名前]		DDA0000MDLoadNoR
//
//  [パラメータ]		なし
//
//  [概要]		MainDispの未受信一覧Load。
//
//  [履歴]		2013/09/01	新規	Takane
// ----------------------------------------------------------------
function DDA0000MDLoadNoR(){
	parent.SubDisp.location.href = "./sd_000.html";
	parent.CmdMenu.location.href = "./cm_000.html";
	parent.SubMenu.location.href = "./sm_000.html";
	parent.HeadDisp.location.href = "./hd_000.html";
	parent.MainDisp.location.href = "./mdDAA120.html";

}

//-->