﻿//<!--
// ----------------------------------------------------------------
//  [名前]		G01FraChg
//
//  [パラメータ]	hsURL1～4		リンク先のＵＲＬ
//
//  [概要]		各フレームの内容を変更する。
//
//  [履歴]		2000/08/03	新規	T.Obo ccccccccccc
// ----------------------------------------------------------------
function G01FraChg(hsURL1,hsURL2,hsURL3,hsURL4){
	if(hsURL1 != "") parent.CmdMenu.location.href = hsURL1;
	if(hsURL2 != "") parent.SubMenu.location.href = hsURL2;
	if(hsURL3 != "") parent.MainDisp.location.href = hsURL3;
	if(hsURL4 != "") parent.HeadDisp.location.href = hsURL4;
	//SubDispをデフォルトに戻す
	G01FraResize('');
	parent.SubDisp.location.href = "/sd_000.html";
}
// ----------------------------------------------------------------
//  [名前]		G01FraChg2
//
//  [パラメータ]	hsURL1～4		リンク先のＵＲＬ
//		hsSize			SubDispのサイズ
//
//  [概要]		各フレームの内容を変更する。
//
//  [履歴]		2000/10/16	新規	T.Obo
// ---------------------------------------------------------------G01ImgOverG01ImgOverG01ImgOver-
function G01FraChg2(hsURL1,hsURL2,hsURL3,hsURL4,hsSize){
	if(hsURL1 != "") parent.CmdMenu.location.href = hsURL1;
	if(hsURL2 != "") parent.SubMenu.location.href = hsURL2;
	if(hsURL3 != "") parent.MainDisp.location.href = hsURL3;
	if(hsURL4 != "") parent.HeadDisp.location.href = hsURL4;
	//SubDispをhsSizeに戻す
	G01FraResize(hsSize);
	parent.SubDisp.location.href = "/sd_000.html";
}

// ----------------------------------------------------------------
//  [名前]		G01ImgOver,G01ImgOut,G01ImgClick
//
//  [パラメータ]	hsImgObj		イメージオブジェクトの名前
//
//  [概要]		ボタンクリック等のイベント発生時に画像を入れ替える。
//
//  [履歴]		2000/08/25	新規	T.Obo
//				2001/01/11  G01ImgOut,G01ImgClickに押したボタンを赤くする処理追加 K.Otomo
// ----------------------------------------------------------------
var gsPushedImgObj = "nothing";

//onMouseOver時に画像を入れ替える。
function G01ImgOver(hsImgObj){

	if (gsPushedImgObj != "nothing"){
		gsPushedImgObj.src = "../img/" + gsPushedImgObj.name + "b.gif";	//押したボタンを赤く変える 2001/01/11
	}
	hsImgObj.src = "../img/" + hsImgObj.name + "b.gif";
}

//onMouseOut時に画像を入れ替える。
function G01ImgOut(hsImgObj){
	if(gsPushedImgObj != hsImgObj){
		hsImgObj.src = "../img/" + hsImgObj.name + "a.gif";
	}
}

//onClick時に画像を入れ替える。
function G01ImgClick(hsImgObj){
	if(gsPushedImgObj == hsImgObj){
		return false;		//既に押されているボタンは何もしない
	}else if(gsPushedImgObj != "nothing"){
		hsImgObj.src = "../img/" + hsImgObj.name + "b.gif";	//押したボタンを赤く変える  2001/01/11
		gsPushedImgObj.src = "/img/" + gsPushedImgObj.name + "a.gif";	//押されていたボタンを元に戻す
	}else {
		hsImgObj.src = "../img/" + hsImgObj.name + "b.gif";	//押したボタンを赤く変える  2001/01/11
	}
	gsPushedImgObj = hsImgObj;
	return true;
}


// ----------------------------------------------------------------
//  [名前]		G01JspImgOver,G01JspImgOut,G01JspImgClick
//
//  [パラメータ]	hsImgObj		イメージオブジェクトの名前
//
//  [概要]		ボタンクリック等のイベント発生時に画像を入れ替える。
//				(JSPフォーム用。URLに""を追加）
//  [履歴]		2000/10/06	新規	K.Otomo
// ----------------------------------------------------------------

//onMouseOver時に画像を入れ替える。
function G01JspImgOver(hsImgObj){
	hsImgObj.src = "../img/" + hsImgObj.name + "b.gif";
}

//onMouseOut時に画像を入れ替える。
function G01JspImgOut(hsImgObj){
	if(gsPushedImgObj != hsImgObj){
		hsImgObj.src = "../img/" + hsImgObj.name + "a.gif";
	}
}

//onClick時に画像を入れ替える。
function G01JspImgClick(hsImgObj){
	if(gsPushedImgObj == hsImgObj){
		return false;		//既に押されているボタンは何もしない
	}else if(gsPushedImgObj != "nothing"){
		gsPushedImgObj.src = "../img/" + gsPushedImgObj.name + "a.gif";	//押されていたボタンを元に戻す
	}
	gsPushedImgObj = hsImgObj;
	return true;
}



// ----------------------------------------------------------------
//  [名前]		G01ImgClickedLoad
//
//  [パラメータ]	hsImgName		イメージの名前
//
//  [概要]		画像がクリックされた状態でhtmlをロード。
//
//  [履歴]		2000/08/25	新規	T.Obo
// ----------------------------------------------------------------
function G01ImgClickedLoad(hsImgName){
	document.images[hsImgName].src = "../img/" + hsImgName + "b.gif";
	gsPushedImgObj = document.images[hsImgName];
}

// ----------------------------------------------------------------
//  [名前]		G01WinOpen
//
//  [パラメータ]		hsWinName		開くウィンドウのＵＲＬ
//			hsWinWidth	開くウィンドウの横サイズ
//			hsWinHeight	開くウィンドウの縦サイズ
//
//  [概要]		指定されたhtmlを新しいウィンドウで開く。
//
//  [履歴]		2000/08/03	新規	T.Obo
// ----------------------------------------------------------------
var gsWin = "0";
function G01WinOpen(hsWinName){
	var psURL;
	var psName;
	var psZokusei;
	var psTmpWin;

	psURL = "nw" + hsWinName+".html";
	psName = "newWin" + hsWinName;
	switch(hsWinName){
		case "Address":
			psZokusei = "width=350,height=330";
			if(gsWin != "0"){
				if(gsWin.closed){
					gsWin = window.open(psURL, psName, psZokusei);
				}else{
					gsWin.focus();
				}
			}else{
				gsWin = window.open(psURL, psName, psZokusei);
			}
			break;
		case "Tenpo":
			psZokusei = "width=250,height=250";
			if(gsWin != "0"){
				if(gsWin.closed){
					gsWin = window.open(psURL, psName, psZokusei);
				}else{
					gsWin.focus();
				}
			}else{
				gsWin = window.open(psURL, psName, psZokusei);
			}
			break;
		default:
			//default（エクセル出力）の場合はいくつでもWindowオープン可
			psZokusei = "menubar=yes,resizable=yes";
			psTmpWin = window.open(psURL, psName+G01GetTimeStamp(), psZokusei);
			break;
	}
}

// ----------------------------------------------------------------
//  [名前]		G01FraResize
//
//  [パラメータ]	size	HeadDispの縦サイズ
//
//  [概要]		フレームのサイズを変更する。
//
//  [履歴]		2000/08/03	新規	T.Obo
// ----------------------------------------------------------------
function G01FraResize(hsSize){
	var psSize;
	if(hsSize == ""){
		parent.document.all.subRow.rows = '130,*,0';	//デフォルト値
	}else{
		psSize = hsSize + ",*,0";
		parent.document.all.subRow.rows = psSize;
	}
}
// ----------------------------------------------------------------
//  [名前]		G01FraResize2
//
//  [パラメータ]	size	HeadDispの縦サイズ
//
//  [概要]		エクセル出力時にフレームのサイズを変更する。
//
//  [履歴]		2000/08/03	新規	T.Obo
// ----------------------------------------------------------------
function G01FraResize2(hsSize){
	var psSize;
	if(hsSize == ""){
		parent.document.all.subRow.rows = '130,0,*';
	}else{
		psSize = hsSize + ",0,*";
		parent.document.all.subRow.rows = psSize;
	}

}

// ----------------------------------------------------------------
//  [名前]		G01ZeroPlus
//
//  [パラメータ]		hsValue	前0をつける文字列
//			hiKeta	フィールドの桁数
//
//  [概要]		hsValueに前0をつけてhiKeta桁にする。
//
//  [履歴]		2000/11/09	新規	T.Obo
// ----------------------------------------------------------------
function G01ZeroPlus(hsValue,hiKeta){
	var piLen;
	piLen = hsValue.length;

	if(piLen == 0) return(hsValue);

	for(ZeroPlus = 0; ZeroPlus < hiKeta - piLen; ZeroPlus++){
		hsValue = "0" + hsValue;
	}
	return(hsValue);
}

// ----------------------------------------------------------------
//  [名前]		G01GetTimeStamp
//
//  [パラメータ]		なし
//
//  [概要]		タイムスタンプを取得する
//
//  [履歴]		2000/11/17	新規	T.Hira
// ----------------------------------------------------------------
function G01GetTimeStamp(){
	var now = new Date();
	var dsYMDHMS;
	var dsArrElements = new Array(6);
	dsYMDHMS = "";
	dsArrElements[0] = now.getYear().toString();
	dsArrElements[1] = (now.getMonth()+1).toString();
	dsArrElements[2] = now.getDate().toString();
	dsArrElements[3] = now.getHours().toString();
	dsArrElements[4] = now.getMinutes().toString();
	dsArrElements[5] = now.getSeconds().toString();

	for(i=0;i<6;i++){
		if(dsArrElements[i].length == 1){
			dsArrElements[i] = "0" + dsArrElements[i];
		}
		dsYMDHMS = dsYMDHMS + dsArrElements[i];
	}

	return(dsYMDHMS);
}

// ----------------------------------------------------------------
//  [名前]		G01GetMyInfo
//
//  [パラメータ]	hsImgObj	:	“i”ﾎﾞﾀﾝｵﾌﾞｼﾞｪｸﾄ
//
//  [概要]		現在のJAコードと店舗コードを表示する
//
//  [履歴]		2000/12/01	新規	T.Hira
// ----------------------------------------------------------------
function G01GetMyInfo(hsImgObj){
	var dsPrintInfo;
	var dsMYJACD;
	var dsMYTENCD;

	if(parent.MainMenu.form1.MYJACD.value != ""){
		dsMYJACD = parent.MainMenu.form1.MYJACD.value;
	}else{
		dsMYJACD = "*****";
	}

	if(parent.MainMenu.form1.MYTENCD.value != ""){
		dsMYTENCD = parent.MainMenu.form1.MYTENCD.value;
	}else{
		dsMYTENCD = "*****";
	}


	dsPrintInfo = "現在、あなたの情報は以下にセットされています。\n\n" +
			"ＪＡコード　　：　" + dsMYJACD + "\n" +
			"店舗コード　：　" + dsMYTENCD + "\n";

	alert(dsPrintInfo);
	G01ImgOut(hsImgObj);
}

// ----------------------------------------------------------------
//  [名前]		G01InframeChange
//
//  [パラメータ]		呼び出すhtml（例："/frame.html" ）
//
//  [概要]		HeadDisp内のインフレームを再読み込み
//				（CSO,CTO,CTC系画面のタイトル表示で使用）
//
//  [履歴]		2000/12/04	新規	K.Otomo
// ----------------------------------------------------------------
function G01InframeChange(frame_html){
	try{
		parent.HeadDisp.inframe.location.href = frame_html;
	}catch(e){}
}



//-->