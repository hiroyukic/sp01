package sv;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet3A extends HttpServlet {


	//public void doGot(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	public void doGet(
			HttpServletRequest request,
			HttpServletResponse response
			)
			throws ServletException,IOException {



		SampleBean bean = new SampleBean();
		bean.setMessage("ぼちぼちか");
		request.setAttribute("bean",  bean);

		//RequestDispatcher dispatcher = request.getRequestDispatcher("/servlet/sv.Servlet2B");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/sv/result.jsp");

		dispatcher.forward(request, response);


		//PrintWriter out = response.getWriter();
		//out.println("aaaaaaaaaaaaaa");

	}

}
