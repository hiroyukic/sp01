package sv;

// ダウンロードファイル状況情報　格納ビーン
//public class DownloadFileInfo {
public class DownloadFileInfo {


	// JAコード＋店舗コード＋帳票コード＋基準日　で一意にファイルが特定される。
	private String jaCode;		//3003
	private String tenpoCode;		//001
	private String cyohyoCode;	//KGSDA089
	private String kijunDate;	//H22/12/31

	// 表示項目
	private String fileName;
	private String cycle;
	private String sedai;
	private String recordSize;
	private String downloadState;

	//JAコード
	public String getjaCode(){
		return jaCode;
	}
	public void setjaCode(String foo){
		this.jaCode= foo;
	}

	//店舗コード
	public String getTenpoCode(){
		return tenpoCode;
	}
	public void setTenpoCode(String foo){
		this.tenpoCode = foo;
	}

	//帳票コード
	public String getcyohyoCode(){
		return cyohyoCode;
	}
	public void setcyohyoCode(String foo){
		this.cyohyoCode= foo;
	}

	//基準日
	public String getkijunDate(){
		return kijunDate;
	}
	public void setkijunDate(String foo){
		this.kijunDate= foo;
	}



}