package sv;

import java.util.ArrayList;
//import java.util.List;

// ダウンロード情報　格納ビーン
public class SetDownloadFileInfo {


	public ArrayList<DownloadFileInfo> set() {


		ArrayList<DownloadFileInfo> alist = new ArrayList<DownloadFileInfo>();


		DownloadFileInfo info0 = new DownloadFileInfo();
		info0.setjaCode("3003");
		info0.setTenpoCode("001");
		info0.setcyohyoCode("KGSDA228");
		info0.setkijunDate("20150223");
		alist.add(info0);

		info0 = new DownloadFileInfo();
		info0.setjaCode("3003");
		info0.setTenpoCode("001");
		info0.setcyohyoCode("KGSDA229");
		info0.setkijunDate("20150223");
		alist.add(info0);


		return alist;
	}


}