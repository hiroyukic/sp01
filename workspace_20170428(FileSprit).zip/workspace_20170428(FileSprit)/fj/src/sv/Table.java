package sv;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.beanTAAAwithTAAD;
import db.TblTAAA000;
import fw.JDBCUtil;
import fw.SystemErrorException;
import fw.UserErrorException;

public class Table extends HttpServlet {

	public void doGet(
			HttpServletRequest request,
			HttpServletResponse response
			)
			throws ServletException,IOException {

		//Bean 設定　※ファイル管理、配信管理テーブル検索の代役
		//SetDownloadFileInfo obj = new SetDownloadFileInfo();
		//ArrayList bean = obj.set() ;




		TblTAAA000 TAAA = null;
		ArrayList<beanTAAAwithTAAD> bean = null;

		try {
			TAAA = new TblTAAA000(new JDBCUtil());
			bean = TAAA.findWithTAAD("3003", "001");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (UserErrorException | SystemErrorException e) {
			e.printStackTrace();
		}

		request.setAttribute("bean",  bean);

		//RequestDispatcher dispatcher = request.getRequestDispatcher("/servlet/sv.Servlet2B");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/sv/Table.jsp");

		dispatcher.forward(request, response);

		//PrintWriter out = response.getWriter();
		//out.println("aaaaaaaaaaaaaa");
	}
}
