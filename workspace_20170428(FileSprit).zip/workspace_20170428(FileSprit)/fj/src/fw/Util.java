﻿/*
 * 汎用ユーティリティ
 *
 * 修正履歴
 * R008.1	2008/08/20	T.itoh		データ交換処理返戻書に媒体返却先を追加する。（開発番号 08-14）
 * 									（mediaNameの返却媒体名を短くする。）
 * V010.0	2012/06/30	T.itoh		新元号対応（日付関連モジュールを分割する。）
 *
 */

package pjt.fw;

import java.text.*;
import java.io.*;

/**
 * pjt.fw.Util 汎用ユーティリティ
 *
 * @varsion 1.00
 * @auther IBM_MORIOKA 1999/12/07
 *
 */
public class Util {

	/*
	 * 文字検査テーブル
	 */
	private static final String kawase = new String("ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎ" +
		"ﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜｦﾝﾞﾟ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ(),&./*-\\%｢｣$#?+=@<>:;\'[] ");
	private static final String number = new String("0123456789");
	private static final String numberAndBlank = new String("0123456789 ");

	/**
	 * Util コンストラクター・コメント。
	 */
	public Util() {
		super();
	}


	/* **********************************************************************************
	 *
	 * ファイル操作関連モジュール
	 *
	 * *********************************************************************************/

	/**
	 * ファイル名の拡張子をチェックします。
	 * 一致：'true'、不一致：'false'
	 *
	 * @param fileName String ファイル名
	 * @param ext String　	拡張子
	 * <br>
	 * 作成日 : (2002/04/18 13:00:15)
	 */
	public static boolean chkExtension(String fileName, String ext) {
		if(fileName.endsWith(ext)) {
			return true;
		}else{
			return false;
		}
	}

	/**
	 * ファイルをコピーします。<br>
	 *
	 * @param path1 String 入力ファイルパス
	 * @param path2 String 出力ファイルパス
	 * @return 正常：true　異常：false
	 *
	 * 作成日 : (2003/03/13 16:22:05)
	 */
	public static boolean fileCopy(String path1, String path2) {

		FileInputStream finstream = null;
		FileOutputStream foutstream = null;
		try {
			finstream = new FileInputStream(path1);
			foutstream = new FileOutputStream(path2);
			for (;;) {
				byte[] byteRead = new byte[1024];
				int iRead = finstream.read(byteRead);
				if (iRead == (-1))
					break;
				foutstream.write(byteRead, 0, iRead);
			}
		} catch (FileNotFoundException e) {
			System.err.println("File not exist.: " + e.toString());
			return false;
		} catch (Exception e) {
			System.err.println(e.toString());
			return false;
		} finally {
			try {
				finstream.close();
				foutstream.close();
			} catch (IOException e) {
				System.err.println("Error file close.: ");
				return false;
			}
		}

		return true;
	}

	/**
	 * パラメータとして受けた「ファイル名」の第一拡張子を削除したストリングを返します。<br>
	 * ex : [fileName.ex2.ex1] -> [fileName.ex2]
	 *
	 * @param fileName String ファイル名
	 * @return String ファイル名
	 *<br>
	 * 作成日 : (2002/06/24 13:00:15)
	 *
	 */
	public static String stripExtension(String fileName) {

		int i = fileName.lastIndexOf(".");
		String newFileName = fileName.substring(0, i);

		return newFileName;

	}


	/* **********************************************************************************
	 *
	 * 文字列操作関連モジュール
	 *
	 * *********************************************************************************/

	/**
	 * 後ろにブランクを埋め、文字列を指定された文字数にします。
	 *
	 * @param str String 対象文字列
	 * @param stringLength int 戻り値の文字数
	 * @return String 後ろがブランクで埋められた文字列
	 *
	 */
	public static String backBlankSet(String str,int stringLength) {

		int len = str.length();

		if (len >= stringLength){
			return str;
		}else{
			StringBuffer sb = new StringBuffer(str);
			for (int i=0;i<stringLength-len;i++){
				sb.append(" ");
			}
			return sb.toString();
		}
	}

	/**
	 * 文字を指定された文字数繰り返した文字列を返します。
	 *
	 * @param ch char 繰り返す文字
	 * @param val int 繰り返す文字数
	 * @return String 文字を指定された文字数繰り返した文字列
	 *
	 */
	public static String charFill(char ch,int val) {

		StringBuffer sb = new StringBuffer();
		for (int i=0;i<val;i++){
			sb.append(ch);
		}
		return sb.toString();
	}

	/**
	 * 対象文字が為替使用可能文字かどうかを検査します。
	 * 使用可能：'true'、使用不可：'false'
	 *
	 * @param ch char 検査対象文字
	 *
	 */
	public static boolean chkKawaseChar(char ch) {

		/*
		 * '\'がﾊﾟﾗﾒｰﾀとなった時の対応
		 * ※ '\' = 165 は「為替文字」とみなしtrue を返す。
		 */
		if(ch == 165) return true;

		int i = kawase.indexOf(ch);
		if (i !=- 1){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * 対象文字列に含まれる文字がすべて為替使用可能文字かどうかを検査します。
	 * 使用可能：'true'、使用不可：'false'
	 *
	 * @param str string 検査対象文字列
	 *
	 */
	public static boolean chkKawaseString(String str) {

		for (int i=0;i<str.length();i++){
			if (!(chkKawaseChar(str.charAt(i)))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 対象文字列が半角数字もしくはﾌﾞﾗﾝｸ（0123456789 ）であるかどうかを検査します。
	 * 妥当:'true'、非妥当：'false'
	 *
	 * @param str String 検査対象文字
	 *
	 */
	public static boolean chkNumericBlankString(String str) {

		for (int i = 0; i < str.length(); i++) {

			char ch = str.charAt(i);

			int j = numberAndBlank.indexOf(ch);
			if (j != -1) {
				//return true;
			} else {
				return false;
			}
		}
		return true;
	}

	/**
	 * 対象文字が半角数字（0123456789）であるかどうかを検査します。
	 * 妥当:'true'、非妥当：'false'
	 *
	 * @param ch char 検査対象文字
	 *
	 */
	public static boolean chkNumericChar(char ch) {

		int i = number.indexOf(ch);
		if (i != -1){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * 対象文字列が半角数字（0123456789）であるかどうかを検査します。
	 * 妥当:'true'、非妥当：'false'
	 *
	 * @param str String 検査対象文字列
	 *
	 */
	public static boolean chkNumericString(String str) {

		for (int i=0;i<str.length();i++){
			if (!(chkNumericChar(str.charAt(i)))){
				return false;
			}
		}
		return true;
	}

	/**
	 * 配列の比較を行います。
	 * 一致:'true'、不一致：'false'
	 *
	 * @param array1 byte[] 検査対象配列１
	 * @param array2 byte[] 検査対象配列２
	 *
	 */
	public static boolean equalsByteArray(byte[] array1,byte[] array2) {

		int length1 = array1.length;
		int length2 = array2.length;

		if (length1 != length2){
			return false;
		}else{
			for (int i=0;i<length1;i++){
				if (array1[i] != array2[i]){
					return false;
				}
			}
			return true;
		}
	}

	/**
	 * 前にブランクを埋め、文字列を指定された文字数にします。
	 *
	 * @param str String 対象文字列
	 * @param stringLength int 戻り値の文字数
	 * @return String 前がブランクで埋められた文字列
	 *
	 */
	public static String fowardBlankSet(String str,int stringLength) {

		int len = str.length();

		if (len >= stringLength){
			return str;
		}else{
			//StringBuffer sb = new StringBuffer(str);
			StringBuffer sb = new StringBuffer();
			for (int i=0;i<stringLength-len;i++){
				sb.append(" ");
			}
			sb.append(str);
			return sb.toString();
		}
	}

	/**
	 * 前に０を埋め、文字列を指定された文字数にします。
	 *
	 * @param str String 対象文字列
	 * @param stringLength int 戻り値の文字数
	 * @return String 前が０で埋められた文字列
	 *
	 */
	public static String fowardZeroSet(String str,int stringLength) {

		int len = str.length();

		if (len >= stringLength){
			return str;
		}else{
			StringBuffer sb = new StringBuffer();
			for (int i=0;i<stringLength-len;i++){
				sb.append("0");
			}
			sb.append(str);
			return sb.toString();
		}
	}

	/**
	 * String列の中に"Space"が存在するか否かﾁｪｯｸする。
	 *
	 * @param str   検査対象文字列
	 * @return int  0: space無し
	 *				1: 前にspace存在
	 *				2: 中にspace存在
	 *				4: 後にspace存在
	 *				7: 全てspace存在
	 * cf.「全銀Space」ﾁｪｯｸにて使用
	 */
	public static int isThereSpace(String str) {

		int rc = 0;
		String blanc = " ";

		if(str.trim().length() == 0 ) {
			return 7;	//全て'Space'
		}

		/*
		 * 1: 前にspace存在
		 */
		int i = str.indexOf(blanc);

		if(str.indexOf(blanc) == 0) {
			rc = 1;
		}

		/*
		 * 2: 中にspace存在
		 */
		int ii = str.trim().indexOf(blanc);

		if(str.trim().indexOf(blanc) > 0 ) {
			rc = rc + 2;
		}

		/*
		 * 4: 後にspace存在
		 */
		int i4 = str.lastIndexOf(blanc) ;
		if(str.lastIndexOf(blanc) == str.length()-1) {
			rc = rc + 4;
		}

		return rc;
	}

	/**
	 * 対象文字列 str の右にﾌﾞﾗﾝｸが存在した時、ﾌﾞﾗﾝｸ数だけ右にｼﾌﾄさせ、左にｾﾞﾛを挿入する。<br>
	 * ex. " ABC "->"00ABC"
	 *
	 * @param str 検査対象文字
	 * @return string 対象文字列 str をﾌﾞﾗﾝｸ数だけ右にｼﾌﾄした文字列。
	 *<br>
	 * ※cf.「全銀Space」ﾁｪｯｸにて使用
	 * 2003-06-25
	 *
	 */
	public static String shiftRightFowardZero(String str) {

		return Util.fowardZeroSet( str.trim(), str.length());

	}

	/**
	 * 対象文字列 str 中にﾌﾞﾗﾝｸが存在した時、"0"に置換する。
	 *
	 * @param str 検査対象文字
	 * @return string 対象文字列 str  中のﾌﾞﾗﾝｸを、"0"に置換した文字列。
	 *<br>
	 * ※cf.「全銀Space」ﾁｪｯｸにて使用
	 * 2003-06-25
	 *
	 */
	public static String space2Zero(String str) {

		StringBuffer sb = new StringBuffer();

		for (int i=0;i<str.length();i++) {
			if (str.charAt(i) == ' ' ) {
				sb.append('0');
			} else {
				sb.append(str.charAt(i));
			}
		}
		return sb.toString();
	}

	/**
	 * Long値をStringに置換します。
	 *
	 * @param num long 入力値
	 * @return string 出力文字列
	 *
	 */
	public static String numberFormat(long num) {

		String val = NumberFormat.getInstance().format(num);
		//System.out.println(val);
		return val;

	}

	/**
	 * Int値を２桁の数値に置換します。
	 *
	 * @param num int 入力値
	 * @return string 出力文字列
	 *
	 */
	public static String numberFormat00(int num) {

		DecimalFormat nf = (DecimalFormat)NumberFormat.getInstance();
		nf.applyPattern("00");
		return nf.format(num);

	}

	/**
	 * * @param
	 *  * @return
	 *
	 */
	public static String numberFormat000(long num) {

		DecimalFormat nf = (DecimalFormat)NumberFormat.getInstance();
		nf.applyPattern("000");
		return nf.format(num);

	}

	/**
	 *
	 * @return java.lang.String
	 * @param num java.lang.String
	 */
	public static String removeForeZero(String num) {
		return Long.toString(Long.parseLong(num.trim()));
	}

	/**
	 * 漢字文字列の右トリム処理を行います。
	 *
	 * @param str String 入力文字列 　
	 * @return String 入力文字列
	 *
	 */
	public static String rTrimDBBlank(String str) {

		int len = str.length();
		int i ;
		for (i=len-1;i>=0;i--){
			if (str.charAt(i) != '　'){
				break;
			}
		}

		return str.substring(0,i+1);
	}


	/* **********************************************************************************
	 *
	 * データ交換システムで使用するコード変換モジュール
	 *
	 * *********************************************************************************/

	/**
	 * データフォーマット名を取得します。<br>
	 * 作成日 : (2002/04/24 17:30:48)
	 */
	public static String frmcd2Name(String frmcds)  {

		int a = Integer.parseInt(frmcds);
		String b = "";
		switch (a) {
			case 1 : b = "JASTEM";
				break;
			case 2 : b = "全銀口座振替";
				break;
			case 3 : b = "全銀振込";
				break;
			case 10 : b = "国税";
				break;
			case 11 : b = "NHK";
				break;
			case 12 : b = "NTT口座振替";
				break;
			case 13 : b = "NTT敷地料";
				break;
			case 14 : b = "国民年金保険料";
				break;
			case 21 : b = "東北電力振替依頼";
				break;
			case 31 : b = "東北電力振替依頼伝送用";
				break;
			case 41 : b = "東北電力電柱敷地";
				break;
			case 90 : b = "全銀口座振替変更";
				break;
			case 91 : b = "NHK口座番号変更";
				break;
			case 92 : b = "NTT口座番号変更";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * データ仕様コードとフォーマット名を取得します。<br>
	 * 作成日 : (2002/04/24 17:30:48)
	 *
	 */
	public static String frmcd2Name2(String frmcds)  {

		int a = Integer.parseInt(frmcds);
		String b = "";
		switch (a) {
			case 1 : b = "１：ＪＡＳＴＥＭ";
				break;
			case 2 : b = "２：全銀口座振替";
				break;
			case 3 : b = "３：全銀振込";
				break;
			case 10 : b = "１０：国税";
				break;
			case 11 : b = "１１：ＮＨＫ";
				break;
			case 12 : b = "１２：ＮＴＴ口座振替";
				break;
			case 13 : b = "１３：ＮＴＴ敷地料";
				break;
			case 14 : b = "１４：国民年金保険料";
				break;
			case 21 : b = "２１：東北電力振替依頼";
				break;
			case 31 : b = "３１：東北電力振替依頼伝送用";
				break;
			case 41 : b = "４１：東北電力電柱敷地";
				break;
			case 90 : b = "９０：全銀口座振替変更";
				break;
			case 91 : b = "９１：ＮＨＫ口座番号変更";
				break;
			case 92 : b = "９２：ＮＴＴ口座番号変更";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * データフォーマット名からデータ仕様コードを取得します。<br>
	 * 作成日 : (2002/04/24 17:30:48)
	 */
	public static String name2Frmcd(String fmt)  {

					String a = "";
					if ( fmt.equals("JASTEM")) {
						 a = "1";
					} else
					if ( fmt.equals("全銀口座振替")) {
						 a = "2";
					} else
					if ( fmt.equals("全銀振込")) {
						 a = "3";
					} else
					if ( fmt.equals("国税")) {
						 a = "10";
					} else
					if ( fmt.equals("NHK")) {
						 a = "11";
					} else
					if ( fmt.equals("NTT口座振替")) {
						 a = "12";
					} else
					if ( fmt.equals("NTT敷地料")) {
						 a = "13";
					} else
					if ( fmt.equals("国民年金保険料")) {
						 a = "14";
					} else
					if ( fmt.equals("東北電力振替依頼")) {
						 a = "21";
					} else
					if ( fmt.equals("東北電力振替依頼伝送用")) {
						 a = "31";
					} else
					if ( fmt.equals("東北電力電柱敷地")) {
						 a = "41";
					} else
					if ( fmt.equals("全銀口座振替変更")) {
						 a = "90";
					} else
					if ( fmt.equals("NHK口座番号変更")) {
						 a = "91";
					} else
					if ( fmt.equals("NTT口座番号変更")) {
						 a = "92";
					}
					return a;
	}

	/**
	 * 顧客番号変更有無区分名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String cusumuKubn(String cuskb)  {

		int a = Integer.parseInt(cuskb);
		String b = "";
		switch (a) {
			case 0 : b = "無";
				break;
			case 1 : b = "有";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 使用用紙名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String cyohyoKubn(String cyhkb)  {

		int a = Integer.parseInt(cyhkb);
		String b = "";
		switch (a) {
			case 0 : b = "Ａ４用紙";
				break;
			case 1 : b = "Ｂ４用紙";
				break;
			case 2 : b = "専用用紙";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * オリジナルフォーマット名を取得します。<br>
	 * 作成日 : (2002/06/21 18:03:48)
	 */
	public static String formtChangeKubn(String formt)  {

		int a = Integer.parseInt(formt);
		String b = "";
		switch (a) {
			case 1  : b = "ＪＡＳＴＥＭ";
				break;
			case 2  : b = "全銀";
				break;
			default : b = "その他";
		}
		return b;
	}

	/**
	 * 返却パターン名を取得します。<br>
	 * 作成日 : (2002/06/21 18:10:45)
	 */
	public static String henPatternKubn(String henpt)  {

		int a = Integer.parseInt(henpt);
		String b = "";
		switch (a) {
			case 1  : b = "不能データ";
				break;
			case 2  : b = "全データ";
				break;
			default : b = "不要";
		}
		return b;
	}

	/**
	 * 返戻書要否区分名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String henreisyoKubn(String henkb)  {

		int a = Integer.parseInt(henkb);
		String b = "";
		switch (a) {
			case 0 : b = "不要";
				break;
			default : b = "要";
		}
		return b;
	}

	/**
	 * 委託者区分名を取得します。<br>
	 * 作成日 : (2002/06/21 18:10:45)
	 */
	public static String ItakuKubn(String B0018)  {

		int a = Integer.parseInt(B0018);
		String b = "";
		switch (a) {
			case 1  : b = "１：ＪＡ関連";
				break;
			case 2  : b = "２：企業等";
				break;
			case 3  : b = "３：市町村";
				break;
			case 4  : b = "４：県";
				break;
			case 5  : b = "５：国";
				break;
			case 6  : b = "６：ＪＡ給与";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 還元サイクル区分名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String kangenKubn(String saikb)  {

		int a = Integer.parseInt(saikb);
		String b = "";
		switch (a) {
			case 0 : b = "日次";
				break;
			case 1 : b = "月次";
				break;
			case 2 : b = "随時";
				break;
			case 3 : b = "四半期";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * \ッドの記述を挿入してください。
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String kekkalistKubun(String kekkb)  {

		int a = Integer.parseInt(kekkb);
		String b = "";
		switch (a) {
			case 1 : b = "農協計";
				break;
			case 2 : b = "委託者計";
				break;
			case 3 : b = "農協種目計";
				break;
			case 4 : b = "委託者種目計";
				break;
			case 5 : b = "農協計・種目計";
				break;
			case 6 : b = "委託者計・種目計";
				break;
			case 7 : b = "個別明細・農協計";
				break;
			case 8 : b = "個別明細・種目計";
				break;
			default : b = "その他";
		}
		return b;
	}

	/**
	 * 県委託者種別名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String kensyubecodeName(String knsyu)  {

		int a = Integer.parseInt(knsyu);
		String b = "";
		switch (a) {
			case 11 : b = "給与";
				break;
			case 12 : b = "賞与";
				break;
			case 21 : b = "総振";
				break;
			case 44 : b = "公的年金";
				break;
			case 91 : b = "振替";
				break;
			case 99 : b = "解約";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 起算日セット方法パターン名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String kisansetKubn(String kiset)  {

		int a = Integer.parseInt(kiset);
		String b = "";
		switch (a) {
			case 99 : b = "セットしない";
				break;
			case 1 : b = "顧客番号";
				break;
			case 2 : b = "支店名";
				break;
			case 3 : b = "預金者名";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 口振コード名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String kozafuricdKubn(String kofri)  {

		int a = Integer.parseInt(kofri);
		String b = "";
		switch (a) {
			case 10 : b = "ローン";
				break;
			case 11 : b = "クレジット";
				break;
			case 12 : b = "公共料金一般";
				break;
			case 13 : b = "電話";
				break;
			case 14 : b = "ＮＨＫ";
				break;
			case 15 : b = "ガス";
				break;
			case 16 : b = "水道";
				break;
			case 17 : b = "電気";
				break;
			case 20 : b = "税金一般";
				break;
			case 21 : b = "福祉一般";
				break;
			case 22 : b = "国保・社保";
				break;
			case 23 : b = "年金・恩給";
				break;
			case 24 : b = "購買";
				break;
			case 25 : b = "販売";
				break;
			case 26 : b = "共済";
				break;
			case 30 : b = "給与";
				break;
			case 31 : b = "自動集金";
				break;
			case 32 : b = "定額自動送金";
				break;
			case 33 : b = "後納手数料";
				break;
			case 34 : b = "アンサー手数料";
				break;
			case 35 : b = "協同クレジット";
				break;
			case 36 : b = "授業料";
				break;
			case 37 : b = "その他";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 返却媒体情報１名称を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String medi1Name(String medi1)  {

		int a = Integer.parseInt(medi1);
		String b = "";
		switch (a) {
			case 1 : b = "正・副";
				break;
			case 2 : b = "正のみ";
				break;
			default : b = "不要";
		}
		return b;
	}

	/**
	 * 返却媒体名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String mediaName(String media)  {

		int a = Integer.parseInt(media);
		String b = "";
		switch (a) {
			case 1 : b = "ＦＤ　";
				break;
			case 2 : b = "ＭＴ　";
				break;
			case 3 : b = "ＭＯ　";
				break;
			case 4 : b = "ＣＭＴ";
				break;
			case 5 : b = "伝送１";	/* 伝送1(ﾍﾞｰｼｯｸ) CHN R008.1 */
				break;
			case 6 : b = "伝送２";	/* 伝送2(TCP/IP) CHN R008.1 */
				break;
			case 7 : b = "Ｍ伝　";	/* ＭＴ伝送 CHN R008.1 */
				break;
			default : b = "その他";	/* 未設定 CHN R008.1 */
		}
		return b;
	}

	/**
	 * 共済年月区分名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String nentsukikubunName(String ntkbn)  {

		int a = Integer.parseInt(ntkbn);
		String b = "";
		switch (a) {
			case 1 : b = "月払い";
				break;
			case 2 : b = "年払い";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 適用カナセット方法名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String passbooksetKubn(String tuset)  {

		int a = Integer.parseInt(tuset);
		String b = "";
		switch (a) {
			case 1 : b = "顧客番号";
				break;
			case 2 : b = "変換表１";
				break;
			case 3 : b = "変換表 + 振替月";
				break;
			case 4 : b = "振替月";
				break;
			case 5 : b = "支店名";
				break;
			case 6 : b = "変換表２";
				break;
			case 7 : b = "指定日";
				break;
			case 8 : b = "特殊設定";
				break;
			case 99 : b = "委託者情報";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 資料送付先名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String sofusakiKubn(String sofkb)  {

		int a = Integer.parseInt(sofkb);
		String b = "";
		switch (a) {
			case 0 : b = "ＪＡ宛";
				break;
			case 1 : b = "委託者宛";
				break;
			case 2 : b = "推進課宛";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 出納コード名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String suitocodeKubn(String suito)  {

		int a = Integer.parseInt(suito);
		String b = "";
		switch (a) {
			case  2 : b = "盛岡";
				break;
			case  3 : b = "花巻";
				break;
			case  4 : b = "北上";
				break;
			case  5 : b = "水沢";
				break;
			case  7 : b = "一関";
				break;
			case  8 : b = "千厩";
				break;
			case  9 : b = "大船渡";
				break;
			case 10 : b = "遠野";
				break;
			case 11 : b = "釜石";
				break;
			case 12 : b = "宮古";
				break;
			case 14 : b = "久慈";
				break;
			case 15 : b = "二戸";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * スケジュール自動生成区分名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String suketorokuKubn(String skjkb)  {

		int a = Integer.parseInt(skjkb);
		String b = "";
		switch (a) {
			case 1 : b = "要";
				break;
			default : b = "不要";
		}
		return b;
	}

	/**
	 * 古月処理タイプ名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String syoritypeKubn(String taipu)  {

		int a = Integer.parseInt(taipu);
		String b = "";
		switch (a) {
			case 0 : b = "処理しない";
				break;
			case 1 : b = "古月処理";
				break;
			case 2 : b = "ターミナル１";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 県委託者種別名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String syubecodeName(String syucd)  {

		int a = Integer.parseInt(syucd);
		String b = "";
		switch (a) {
			case 00 : b = "無変換";
				break;
			case 11 : b = "給与";
				break;
			case 12 : b = "賞与";
				break;
			case 21 : b = "総振";
				break;
			case 44 : b = "公的年金";
				break;
			case 91 : b = "振替";
				break;
			case 99 : b = "解約";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 帳票出力形態名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String syutsuryokuKubn(String outkb)  {

		int a = Integer.parseInt(outkb);
		String b = "";
		switch (a) {
			case 0 : b = "ＣＳＶ";
				break;
			case 1 : b = "ＰＤＦ１(ﾉﾝﾚｺｰﾄﾞ)";
				break;
			case 2 : b = "ＰＤＦ２(ﾏﾙﾁﾚｺｰﾄﾞ)";
				break;
			case 3 : b = "ＰＤＦ３(ﾚｺｰﾄﾞ)";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 帳票出力表示制御区分名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String syutsuseigyoKubn(String outkb)  {

		int a = Integer.parseInt(outkb);
		String b = "";
		switch (a) {
			case 0 : b = "委託者別";
				break;
			case 1 : b = "帳票別";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 適用コードセット方法名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String tekicdpatternKubn(String tepkb)  {

		int a = Integer.parseInt(tepkb);
		String b = "";
		switch (a) {
			case 1 : b = "顧客番号";
				break;
			case 2 : b = "変換表１";
				break;
			case 3 : b = "支店名";
				break;
			case 4 : b = "変換表２";
				break;
			case 99 : b = "委託者情報";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 電話料金郡区分名を取得します。
	 * 作成日 : (2002/04/24 17:30:48)
	 */
	public static String frmcdGunkbName(String gunkbs)  {

		int a = Integer.parseInt(gunkbs);
		String b = "";
		switch (a) {
			case 1 : b = "電話料金　【Ａ群】";
				break;
			case 2 : b = "電話料金　【Ｂ群】";
				break;
			case 3 : b = "電話料金　【Ｃ群】";
				break;
			case 4 : b = "電話料金　【Ｄ群】";
				break;
			case 5 : b = "電話料金　【Ｅ群】";
				break;
			case 6 : b = "電話料金　【Ｆ群】";
				break;
			default : b = "";
		}
		return b;
	}

	/**
	 * 全銀チェックレベル区分名を取得します。<br>
	 * 作成日 : (2002/06/21 17:30:48)
	 */
	public static String lebelName(String lebel)  {

		int a = Integer.parseInt(lebel);
		String b = "";
		switch (a) {
			case 0 : b = "厳密チェック";
				break;
			case 1 : b = "柔軟チェック１";
				break;
			case 2 : b = "柔軟チェック２";
				break;
			case 3 : b = "柔軟チェック３";
				break;
			default : b = "該当なし";
		}
		return b;
	}

	/**
	 * 処理ステータス名を取得します。<br>
	 *
	 * @param status String 処理ステータス
	 * @return String 処理ステータス名
	 *
	 */
	public static String statuscode2name(String status)  {

		String[][] searches =
			{
				{"0","未処理"},
				{"10","取込処理中"},
				{"11","項目ﾁｪｯｸ済"},
				{"12","取込保留"},
				{"13","取込保留"},
				{"14","マルチ保留"},
				{"19","取込処理済"},
				{"20","件数金額ﾁｪｯｸ済"},
				{"25","送信ﾌｧｲﾙ作成済"},
				{"30","ホスト送信済"},
				{"40","振替停止済"},
				{"51","返却ﾌｧｲﾙ取込済"},
				{"52","ﾒﾃﾞｨｺﾝﾃﾞｰﾀ作成済"},
				{"53","帳票作成済"},
				{"60","返却媒体作成済"},
				{"130","ホスト送信済"},
				{"151","返却ﾌｧｲﾙ取込済"},
				{"152","ﾒﾃﾞｨｺﾝﾃﾞｰﾀ作成済"},
				{"153","帳票作成済"},
				{"160","返却媒体作成済"},
				{"-1","テスト取込処理済"},
				{"-11","エラー"},
				{"-12","空"},
				{"-13","エラー"},
				{"-14","エラー"},
				{"-51","エラー"},
				{"-52","エラー"},
				{"-53","エラー"},
				{"-151","エラー"},
				{"-152","エラー"},
				{"-153","エラー"},
			} ;

		String 	statusmei = null ;
		int searCount = searches.length ;
		for (int i = 0; i < searCount; i++) {
			if (status.equals(searches[i][0])) {
				statusmei = searches[i][1] ;
				break ;
			}
		}

		return statusmei ;

	}


	/**
	 * String.split の代用メソッド<br>
	 * カンマ(',') をデリミタとして使用。<br>
	 * 【背景】
	 * java.lang.String.split() は、 JDK 1.4 以上で使用可能。<br>
	 * 現行の WebSphere は、IBM1.2.2 で運用されているため splitメソッドは使用不可。 <br>
	 *
	 * 作成日 : (2015/02/12 17:00:00)
	 */
	public static String[] split(String s)  {

		int cnt=0,index;
		String parsed[],tmp;

		// Strip trailing spaces...
		while(s.endsWith(" ")) s=s.substring(0,s.length()-1);

		// Find number of words in string
		for(int i=0; i<s.length(); i++)
		//if(s.charAt(i)==' ') cnt++;
		if(s.charAt(i)==',') cnt++;
		parsed=new String[cnt+1];

		tmp=s;
		for(int i=0; i<cnt+1; i++) {
			//index=tmp.indexOf(" ");
			index=tmp.indexOf(",");
			if(index!=-1) {
				parsed[i]=tmp.substring(0,index);
				tmp=tmp.substring(index+1);
			}
			else parsed[i]=tmp;
		}
		return parsed;
	}

}
