﻿/*
 * 暦変換ユーティリティ
 *
 * 修正履歴
 * V010.0	2012/05/30	T.itoh		元号変更対応準備のため新規作成しました。
 * 			2014/12/11	chiba		プロパティファイルにて元号管理
 *
 */

package pjt.fw;

import java.text.SimpleDateFormat;
import java.util.*;

//import javax.swing.JFrame;

//import pjt.de.bat.testWork;

public class UtilWareki {

	/*
	 * 暦変換テーブル(ADD V010.0)
	 * 新元号が決定した場合は以下の登録を行います。
	 * 元号名称：JPnameの"ＸＸ"を新元号に変更
	 * 元号記号：JPinitialの"X"を新元号記号に変更
	 * 新元号開始日：JPcalendarの(2100, 1 - 1, 1)「2100年1月1日」を新元号開始日に変更
	 */
	static Vector JPname = new Vector();
	static Vector JPinitial = new Vector();
	static Vector JPcalendar = new Vector();

	static PropertyResourceBundle properties = null;
	static String fieldPropertyFileName = "wareki";

	/**
	 * 暦変換テーブルを初期化します。
	 *
	 *
	 */
	static {

//		// 元号名称テーブル
//		JPname.add("明治");
//		JPname.add("大正");
//		JPname.add("昭和");
//		JPname.add("平成");
//		JPname.add("ＸＸ");
//
//		// 元号記号テーブル
//		JPinitial.add("M");
//		JPinitial.add("T");
//		JPinitial.add("S");
//		JPinitial.add("H");
//		JPinitial.add("X");
//
//		// 元号カレンダー（元号の開始日を設定）
//		JPcalendar.add(new GregorianCalendar(1868, 9 - 1, 8));
//		JPcalendar.add(new GregorianCalendar(1912, 7 - 1, 30));
//		JPcalendar.add(new GregorianCalendar(1926, 12 - 1, 25));
//		JPcalendar.add(new GregorianCalendar(1989, 1 - 1, 8));
//		JPcalendar.add(new GregorianCalendar(2100, 1 - 1, 1));

		// 元号プロパティファイル読み込み (2014.12.11)
		utilInit();

	}


	/**
	 * 暦変換ユーティリティ - 初期化メソッド
	 * 【概要】和暦プロパティファイルを読み込み、元号、開始日等を取得する。
	 *
	 * @return void
	 */
	static void utilInit() {
		String msg = null;

		try {
			// loadProperty メソッド実行
			try {
				properties = (PropertyResourceBundle) PropertyResourceBundle.getBundle(fieldPropertyFileName);
			} catch (MissingResourceException e) {
			    msg = " 和暦プロパティファイル(wareki.property) が読み込めません。ファイルを確認して下さい。: ";
			    Logger.L0.writeLog(msg);
			    System.err.println(msg);
				Logger.L0.printStackTrace(e);
		    	throw new SystemErrorException();
			}

			java.util.Enumeration enum1;
			enum1 = properties.getKeys();

			// キー格納用リスト
			List strList = new ArrayList();
			String key =null;
			String val =null;

			// 元号開始日設定用変数
			int yyyy  ;
			int mm = 0;
			int dd = 0;

			// プロパティファイルのキー一覧取得
			while (enum1.hasMoreElements()) {
				key = (String) enum1.nextElement();
				strList.add(key);
			}
			// キーをソート
			Collections.sort(strList);

			// KEY ⇒ VALUE取得（元号、略称、開始日）
			Iterator itr = strList.iterator();
			while (itr.hasNext()) {
				key = (String)itr.next();
				val=properties.getString(key);
				// カンマでパース java.lang.String.split() は、 JDK 1.4 以上で使用可能。
				//String[] strAry = val.split(",");
				String[] strAry = Util.split(val);

			    // (1) 元号
			    JPname.add(strAry[0]);

			    // (2) 元号略称
			    JPinitial.add(strAry[1]);

			    // (3) 元号開始日
			    yyyy = Integer.parseInt(strAry[2].substring(0,4));
			    mm = Integer.parseInt(strAry[2].substring(4,6));
			    dd = Integer.parseInt(strAry[2].substring(6));
			    // "日付"妥当性チェック
			    if(CheckDate(yyyy, mm, dd) == false) {
			    	msg = " 元号開始日の設定に誤りがあります。" + fieldPropertyFileName + ".property の設定内容を確認して下さい。: " + (String)strAry[2];
			    	Logger.L0.writeLog(msg);
			    	System.err.println(msg);
			    	throw new SystemErrorException();
			    }
			    // カレンダー設定
			    JPcalendar.add(new GregorianCalendar(yyyy, mm - 1, dd));
			}

		} catch (Exception e) {
			msg = "Exception in \"utilInit\", at pjt.fw.UtilWareki.java.";
		    Logger.L0.writeLog(msg);
		    System.err.println(msg);
			Logger.L0.printStackTrace(e);
			JPname = null;
			JPinitial = null;
			JPcalendar = null;
			properties = null;
			return ;
		}
	}


	/**
	 * 元号記号付和暦(gyymmdd)を西暦(yyyymmdd)で返します。
	 * 入力日付は正しいことが前提になっています。
	 *
	 * @param	wareki String 和暦(gyymmdd)
	 * @return	String 西暦(yyyymmdd)
	 *
	 */
	public static String getUSDate(String wareki) {

		// 入力日付が７桁以外はエラーとします。
		if (wareki.length() != 7) {
			return null;
		}

		// 元号記号を取得します。
		String era = wareki.substring(0, 1);
		era = era.toUpperCase();
		int pos = JPinitial.indexOf(era);
		if (pos == -1) {
			return null;
		}

		// 年月日を数値に変換します。数字以外が混入している場合はエラーとします。
		int yy = 0;
		int mm = 0;
		int dd = 0;
		try {
			yy = Integer.parseInt(wareki.substring(1, 3).trim());
			mm = Integer.parseInt(wareki.substring(3, 5).trim());
			dd = Integer.parseInt(wareki.substring(5, 7).trim());
		} catch (NumberFormatException e) {
			return null;
		}

		// 元号記号にマッチした元号カレンダーから開始年を取得し、
		// 入力和暦年との和を出力西暦年とします。
		GregorianCalendar cal = (GregorianCalendar)JPcalendar.get(pos);
		int fy = yy + cal.get(Calendar.YEAR) - 1;

		// 出力年月日(yyyymmdd)を編集します。
		String seireki = addZero(fy, 4) + addZero(mm, 2) + addZero(dd, 2);

		return seireki;

	}


	/**
	 * 西暦(yyyymmdd)を元号記号付和暦(gyymmdd)で返します。
	 * 入力日付は正しいことが前提になっています。
	 *
	 * @param	seireki String 西暦(yyyymmdd)
	 * @return	String 元号付和暦(gyymmdd)
	 *
	 */
	public static String getJPDate(String seireki) {


		// 入力日付が８桁以外はエラーとします。
		if (seireki.length() != 8) {
			return null;
		}

		// 年月日を数値に変換します。数字以外が混入している場合はエラーとします。
		int yy = 0;
		int mm = 0;
		int dd = 0;
		try {
			yy = Integer.parseInt(seireki.substring(0, 4));
			mm = Integer.parseInt(seireki.substring(4, 6));
			dd = Integer.parseInt(seireki.substring(6, 8));
		} catch (NumberFormatException e) {
			return null;
		}

		// 入力年月日と元号カレンダーを比較し、
		// 入力年月日が大きいか等しい場合該当元号します。
		String wareki = null;
		int chgint = Integer.parseInt(seireki);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		for (int i = JPcalendar.size() - 1; i >= 0; i--) {
			GregorianCalendar cal = (GregorianCalendar)JPcalendar.get(i);
			int calint = Integer.parseInt(sdf.format(cal.getTime()));
			if (chgint >= calint) {
				int fy = yy - cal.get(Calendar.YEAR) + 1;

				// 出力年月日(gyymmdd)を編集します。
				wareki = JPinitial.get(i).toString();
				wareki = wareki + addZero(fy, 2) + addZero(mm, 2) + addZero(dd, 2);
				break;
			}
		}

		return wareki;
	}


	/**
	 * 元号記号を返します。
	 *
	 * @param	Index int テーブルインデックス
	 * @return	String 元号記号
	 *
	 */
	public static String getJPinitial(int Index) {

		// テーブルインデックスの元号記号を返します。
		// テーブルインデックスが存在しない場合はnullを返します。
		try {
			return (String)JPinitial.get(Index);
		} catch (Exception e) {
			return null;
		}

	}


	/**
	 * 元号記号から元号名称を返します。
	 *
	 * @param	String str 元号記号
	 * @return	String 元号名称
	 *
	 */
	public static String getJPname(String str) {

		// 元号記号を取得します。
		String era = str.toUpperCase();
		int pos = JPinitial.indexOf(era);

		// テーブルインデックスの元号名称を返します。
		// テーブルインデックスが存在しない場合はスペースを返します。
		try {
			return (String)JPname.get(pos);
		} catch (Exception e) {
			return "";
		}

	}


	/**
	 * 値を指定した桁数になるように前に"0"を付けて返します。
	 *
	 * @param	data int 値
	 * @param	figures	int	桁数
	 * @return	String 指定した桁数の値
	 *
	 */
	private static String addZero(int data, int figures) {
		String s = Integer.toString(data);
		while (s.length() < figures) {
			s = "0" + s;
		}
		return s;
	}


	/**
	 * 日付の妥当性チェックを行う。
	 * 妥当:'true'、非妥当：'false'
	 *
	 * @param yy int 西暦年 {1900-}
	 * @param mm int 月 {1-12}
	 * @param dd int 日 {1-31}
	 * <br>
	 * 作成日 : (2014/12/10 10:00:00)
	 *
	 */
	public static boolean CheckDate(int yy,int mm,int dd) {

		if(mm < 1 || 12 < mm) return false;
		if(dd < 1 || 31 < dd) return false;

		//実在日への変換
		Calendar cl = new GregorianCalendar(yy, mm -1, dd);

		//System.out.println("mm =" + mm);
		//System.out.println("cl.get(Calendar.MONTH) =" + cl.get(Calendar.MONTH));

		//実在日チェック
		if (cl.get(Calendar.YEAR) != yy
			| cl.get(Calendar.MONTH) != mm -1
			| cl.get(Calendar.DATE) != dd) {
			return false;
		} else {
			return true;
		}

	}


	/**
	 * MAIN.
	 * <br>
	 * 作成日 : (2014/12/10 10:00:00)
	 *
	 */
	  public static void main(String[] args){
		  String date8 = "20141212";
		  System.out.println("getJPDate=" + UtilWareki.getJPDate(date8));
		  System.out.println("-");
		  System.out.println("getJPinitial 0=" + UtilWareki.getJPinitial(0));
		  System.out.println("getJPinitial 1=" + UtilWareki.getJPinitial(1));
		  System.out.println("getJPinitial 2=" + UtilWareki.getJPinitial(2));
		  System.out.println("getJPinitial 3=" + UtilWareki.getJPinitial(3));
		  System.out.println("getJPinitial 4=" + UtilWareki.getJPinitial(4));
		  System.out.println("-");
		  System.out.println("getJPname M=" + UtilWareki.getJPname("M"));
		  System.out.println("getJPname T=" + UtilWareki.getJPname("T"));
		  System.out.println("getJPname S=" + UtilWareki.getJPname("S"));
		  System.out.println("getJPname H=" + UtilWareki.getJPname("H"));
		  System.out.println("getJPname X=" + UtilWareki.getJPname("X"));
		  System.out.println("-");
		  System.out.println("getUSDate=" + UtilWareki.getUSDate("M010110"));
		  System.out.println("getUSDate=" + UtilWareki.getUSDate("T010730"));
		  System.out.println("getUSDate=" + UtilWareki.getUSDate("S011225"));
		  System.out.println("getUSDate=" + UtilWareki.getUSDate("S640110"));
		  System.out.println("getUSDate=" + UtilWareki.getUSDate("H010108"));
	  }

}
