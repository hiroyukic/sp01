﻿package fw;

import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;

/**
 * 環境パラメータ管理ビーン<BR>
 * <BR>
 * 環境依存パラメータを取得するビーンで、環境依存のパラメータの集中管理を目的としています。<BR>
 * 環境設定ファイル（省略時:"fj.properties"）から設定値を取得します。<BR>
 * ファイル名およびファイル形式は、java.util.PropertyResourceBundleクラスの実装に準じます。
 *
 * @see java.util.PropertyResourceBundle
 * @author
 * @since 2017/04/18
 *
 */
public class EnvParm {

	private String fieldPropertyFileName = new String("fj");
	private PropertyResourceBundle properties = null;

	/**
	 * PropertyFileNameプロパティに設定されたファイル名で初期化を行います。
	 */
	public EnvParm() {
		super();
		String propertyFileName = System.getProperty("fj.propertyFile.name");
		if (propertyFileName != null) {
			fieldPropertyFileName = propertyFileName;
		}

		/* PropertyFileNameプロパティに設定されたファイルを取得 */
		loadProperty();
	}

	/**
	 * 引数で指定されたプロパティ・ファイルを使用して初期化を行います。
	 *
	 * @param propertyFile
	 *            java.lang.String 環境設定ファイルとして使用するファイル名（.properties拡張子は指定しない）
	 */
	public EnvParm(String propertyFile) {

		fieldPropertyFileName = propertyFile;
		loadProperty();

	}

	/**
	 * 引数で指定されたプロパティのキーの値を検索します。
	 *
	 * @return java.lang.String 指定されたキーの値。（存在しない場合はnull)
	 * @param key
	 *            java.lang.String プロパティのキー名
	 */
	public String getProperty(String key) {

		/* getProperty メソッドを実行します。 */
		if (properties != null) {
			try {
				return properties.getString(key);
			} catch (MissingResourceException e) {
				return null;
			}
		}
		return null;

	}

	/**
	 * 引数で指定されたプロパティのキーの値を検索します。
	 *
	 * @return java.lang.String 指定されたキーの値。（存在しない場合、defaultValue)
	 * @param key
	 *            java.lang.String プロパティのキー名
	 * @param defaultValue
	 *            java.lang.String キーが存在しない場合のディフォルト値
	 */
	public String getProperty(String key, String defaultValue) {
		/* getProperty メソッドを実行します。 */
		String work = null;

		if (properties != null) {
			// return properties.getProperty(key, defaultValue);
			try {
				work = properties.getString(key);
			} catch (MissingResourceException e) {
				return defaultValue;
			}

			if (work == null) {
				work = defaultValue;
			}
			return work;
		}
		return null;
	}

	/**
	 * propertyFileName プロパティー (java.lang.String) 値を取得します。
	 *
	 * @return propertyFileName プロパティーの値。
	 * @see #setPropertyFileName
	 */
	public String getPropertyFileName() {
		return fieldPropertyFileName;
	}

	/**
	 * PropertyFileNameプロパティに設定されたファイルを取得します。
	 */
	public void loadProperty() {
		/* loadProperty メソッドを実行します。 */
		try {
			properties = (PropertyResourceBundle) PropertyResourceBundle.getBundle(fieldPropertyFileName);
		} catch (MissingResourceException e) {
			// Logger.L0.writeLog(fieldPropertyFileName + " file not found");

			// System.err.println(fieldPropertyFileName + " file not found");

			// Logger.L0.printStackTrace(e);

			// e.printStackTrace();

			System.out.println("loadProperty:プロパティファイルが無い。 " + fieldPropertyFileName);

			properties = null;
		}
		return;
	}

	/**
	 * プロパティ・ファイルに含まれるキー名を全て検索します。
	 *
	 * @return java.util.Enumeration プロパティ・ファイルに含まれるキー名の列挙
	 */
	public Enumeration propertyNames() {
		/* propertyNames メソッドを実行します。 */
		if (properties != null) {
			return properties.getKeys();
		}
		return null;
	}

	/**
	 * propertyFileName プロパティー (java.lang.String) 値を設定します。
	 *
	 * @param propertyFileName
	 *            プロパティーの新しい値です。
	 * @see #getPropertyFileName
	 */
	public void setPropertyFileName(String propertyFileName) {
		fieldPropertyFileName = propertyFileName;
	}

	/**
	 * テストドライバ
	 *
	 * @see "fj.properties"ファイルは、src直下に配置する。
	 */
	public static void main(String[] args) {
		// fieldPropertyFileName = propertyFileName;
		EnvParm param = new EnvParm("fj");


		String paramName = "fj.JdbcUtil.JdbcDriverName";
		String prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);

		paramName = "fj.JdbcUtil.JdbcURL";
		prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);

		paramName = "fj.JdbcUtil.JdbcUserID";
		prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);

		paramName = "fj.JdbcUtil.JdbcPassword";
		prm = param.getProperty(paramName);
		System.out.println(paramName + ":" + prm);


	}

}
