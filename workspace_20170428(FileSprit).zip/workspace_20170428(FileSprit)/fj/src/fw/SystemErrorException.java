﻿package fw;

/**
 * 回復不能エラーの場合にこの例外をthrowする。
 *
 * @author  c
 * @since 2017/04/18
 */
public class SystemErrorException extends Exception {

	private Throwable exception = null;
	private String msgId = "";
	private String msgText = null;
	private static String objUserMsg = "usermsg";

	/**
	 * SystemErrorException デフォルトコンストラクター
	 */
	public SystemErrorException() {
		super();
	}

	/**
	 * メッセージのみをセットして例外をthrowする場合に使用する。
	 *
	 * @param s
	 *            java.lang.String メッセージ
	 */
	public SystemErrorException(String s) {
		super(s);
	}

	/**
	 * 他の例外をcatchした時に、メッセージ付きで例外をthrowする場合に使用する。
	 *
	 * @param msgid
	 *            java.lang.String メッセージ
	 * @param e
	 *            java.lang.Exception catchした例外
	 */
	public SystemErrorException(String s, Throwable e) {

		super(e.getMessage() + ":" + s);
		if (e instanceof SystemErrorException) {
			// if (((SystemErrorException)e).getThrowable() != null){
			exception = ((SystemErrorException) e).getThrowable();
			msgId = ((SystemErrorException) e).getMsgId();
			// }
		} else {
			exception = e;
		}

	}

	/**
	 * 他の種類の例外を再度throwする場合に使用する。
	 *
	 * @param e
	 *            java.lang.Exception catchした例外
	 */
	public SystemErrorException(Throwable e) {
		super(e.getMessage());
		if (e instanceof SystemErrorException) {
			// if (((SystemErrorException)e).getThrowable() != null){
			exception = ((SystemErrorException) e).getThrowable();
			msgId = ((SystemErrorException) e).getMsgId();
			// }
		} else {
			exception = e;
		}
	}

	/**
	 * メッセージ番号をセットして例外をthrowする場合に使用する。
	 *
	 * @param msgId
	 *            java.lang.String メッセージ番号
	 * @return pjt.fw.SystemErrorException 生成したインスタンス
	 */
	public static SystemErrorException getInstanceWithMsgId(String msgId) {

		SystemErrorException systemError = new SystemErrorException();
		systemError.msgId = msgId;
		return systemError;

	}

	/**
	 * メッセージ番号とメッセージをセットして例外をthrowする場合に使用する。
	 *
	 * @return pjt.fw.SystemErrorException 生成したインスタンス
	 * @param msgId
	 *            java.lang.String メッセージ番号
	 * @param msg
	 *            java.lang.String メッセージ
	 */
	public static SystemErrorException getInstanceWithMsgId(String msgId, String msg) {

		SystemErrorException systemError = new SystemErrorException(msg);
		systemError.msgId = msgId;
		return systemError;

	}

	/**
	 * 他の例外をcatchした時に、メッセージ番号とメッセージをセットして例外をthrowする場合に使用する。
	 *
	 * @return pjt.fw.SystemErrorException 生成したインスタンス
	 * @param msgId
	 *            java.lang.String メッセージ番号
	 * @param msg
	 *            java.lang.String メッセージ
	 * @param e
	 *            java.lang.Throwable catchした例外
	 */
	public static SystemErrorException getInstanceWithMsgId(String msgId, String msg, Throwable e) {

		SystemErrorException systemError = new SystemErrorException(msg, e);
		systemError.msgId = msgId;
		return systemError;

	}

	/**
	 * 他の種類の例外をメッセージ番号をセットして再度throwする場合に使用する。
	 *
	 * @return pjt.fw.SystemErrorException 生成したインスタンス
	 * @param msgId
	 *            java.lang.String メッセージ番号
	 * @param e
	 *            java.lang.Throwable catchした例外
	 */
	public static SystemErrorException getInstanceWithMsgId(String msgId, Throwable e) {

		SystemErrorException systemError = new SystemErrorException(e);
		systemError.msgId = msgId;
		return systemError;

	}

	/**
	 * メッセージ番号を取得する。メッセージ番号がセットされていない場合は""を返する。
	 *
	 * @return java.lang.String メッセージ番号。未設定の場合は""。
	 */
	public String getMsgId() {
		return msgId;
	}

	/**
	 * メッセージ番号に対応したメッセージをusermsg.propertiesから取得して返する。
	 * 「メッセージ番号:メッセージ:詳細メッセージ」の形式で返する。
	 * メッセージがusermsg.propertiesから取得できなかった場合は空文字列がセットされます。
	 * 詳細メッセージはExceptionのコンストラクターで指定された詳細メッセージとなります。
	 *
	 * @return java.lang.String
	 */
	public String getMsgText() {

		if (msgText == null && msgId != null && !msgId.equals("")) {
			try {
				//PJTFactory factory = PJTFactory.instance();
				//TableMgr table = factory.createTableMgr();
				//msgText = table.getValue(objUserMsg, msgId);
				//if (msgText == null)
					msgText = "";
			//} catch (SystemErrorException e) {
			} catch (Exception e) {
				msgText = "";
			}
		}
		String detail = getMessage();
		if (detail == null)
			detail = "";

		return msgId + ":" + msgText + ":" + detail;

	}

	/**
	 * このクラスが保持している例外クラスを取得する。
	 *
	 * @return java.lang.Throwable 例外オブジェクト
	 */
	public Throwable getThrowable() {
		return exception;
	}

	/**
	 * スタックトレースダンプを標準エラー出力に出力する。 このクラスが例外クラスを保持している場合はその例外クラスのスタックトレースをダンプする。
	 * 作成日 : (2002/02/19 15:28:37)
	 */
	public void printStackTrace() {

		if (exception == null) {
			super.printStackTrace();
		} else {
			exception.printStackTrace();
		}

	}

	/**
	 * スタックトレースダンプを指定されたプリントストリームに出力する。
	 * このクラスが例外クラスを保持している場合はその例外クラスのスタックトレースをダンプする。
	 *
	 * @param s
	 *            java.io.PrintStream 出力先となるプリントストリーム
	 */
	public void printStackTrace(java.io.PrintStream s) {

		if (exception == null) {
			super.printStackTrace(s);
		} else {
			exception.printStackTrace(s);
		}

	}

	/**
	 * スタックトレースダンプを指定されたPrintWriterに出力する。
	 * このクラスが例外クラスを保持している場合はその例外クラスのスタックトレースをダンプする。
	 *
	 * @param s
	 *            java.io.PrintWriter 出力先となるPrintWriter
	 */
	public void printStackTrace(java.io.PrintWriter s) {

		if (exception == null) {
			super.printStackTrace(s);
		} else {
			exception.printStackTrace(s);
		}

	}
}
