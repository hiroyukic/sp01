package bean;

public class beanTAAAwithTAAD {

	// TAAA000
    private String AAAJACD;
    private String AAATENCD;
    private String AAACYOCD ;
    private String AAANEWKJ ;
    private String AAANEWSE;
	// TAAD000
    private String AADCYONM ;
    private String AADCYCLE ;
    private String AADSEDAI ;
    private String AADRCVKB ;
    //private String AADTATEN ;
    private String AADZIPKB ;
    private String AADSOUFU;

	/**
	 * @return aAATENCD
	 */
	public String getAAAJACD() {
		return AAAJACD;
	}

	/**
	 * @param aAATENCD セットする aAATENCD
	 */
	public void setAAAJACD(String aAAJACD) {
		AAAJACD = aAAJACD;
	}


	/**
	 * @return aAATENCD
	 */
	public String getAAATENCD() {
		return AAATENCD;
	}


	/**
	 * @param aAATENCD セットする aAATENCD
	 */
	public void setAAATENCD(String aAATENCD) {
		AAATENCD = aAATENCD;
	}


	/**
	 * @return aAACYOCD
	 */
	public String getAAACYOCD() {
		return AAACYOCD;
	}


	/**
	 * @param aAACYOCD セットする aAACYOCD
	 */
	public void setAAACYOCD(String aAACYOCD) {
		AAACYOCD = aAACYOCD;
	}


	/**
	 * @return aAANEWKJ
	 */
	public String getAAANEWKJ() {
		return AAANEWKJ;
	}


	/**
	 * @param aAANEWKJ セットする aAANEWKJ
	 */
	public void setAAANEWKJ(String aAANEWKJ) {
		AAANEWKJ = aAANEWKJ;
	}


	/**
	 * @return aAANEWSE
	 */
	public String getAAANEWSE() {
		return AAANEWSE;
	}


	/**
	 * @param aAANEWSE セットする aAANEWSE
	 */
	public void setAAANEWSE(String aAANEWSE) {
		AAANEWSE = aAANEWSE;
	}


	/**
	 * @return aADCYONM
	 */
	public String getAADCYONM() {
		return AADCYONM;
	}


	/**
	 * @param aADCYONM セットする aADCYONM
	 */
	public void setAADCYONM(String aADCYONM) {
		AADCYONM = aADCYONM;
	}


	/**
	 * @return aADCYCLE
	 */
	public String getAADCYCLE() {
		return AADCYCLE;
	}


	/**
	 * @param aADCYCLE セットする aADCYCLE
	 */
	public void setAADCYCLE(String aADCYCLE) {
		AADCYCLE = aADCYCLE;
	}


	/**
	 * @return aADSEDAI
	 */
	public String getAADSEDAI() {
		return AADSEDAI;
	}


	/**
	 * @param aADSEDAI セットする aADSEDAI
	 */
	public void setAADSEDAI(String aADSEDAI) {
		AADSEDAI = aADSEDAI;
	}


	/**
	 * @return aADRCVKB
	 */
	public String getAADRCVKB() {
		return AADRCVKB;
	}


	/**
	 * @param aADRCVKB セットする aADRCVKB
	 */
	public void setAADRCVKB(String aADRCVKB) {
		AADRCVKB = aADRCVKB;
	}


	/**
	 * 圧縮区分
	 * @return aADTATEN
	 */
	public String getAADZIPKB() {
		return AADZIPKB;
	}


	/**
	 * 圧縮区分
	 * @param aADTATEN セットする aADTATEN
	 */
	public void setAADZIPKB(String aADTATEN) {
		AADZIPKB = aADTATEN;
	}


	/**
	 * @return aADSOUFU
	 */
	public String getAADSOUFU() {
		return AADSOUFU;
	}


	/**
	 * @param aADSOUFU セットする aADSOUFU
	 */
	public void setAADSOUFU(String aADSOUFU) {
		AADSOUFU = aADSOUFU;
	}

	/**
	 * 要素のチェックプリントメソッド
	 *
	 * @param
	 */
	public void print() {
		System.out.print(this.getAAAJACD());
		System.out.print(", ");
		System.out.print(this.getAAATENCD());
		System.out.print(", ");
		System.out.print(this.getAAACYOCD());
		System.out.print(", ");
		System.out.print(this.getAAANEWKJ());
		System.out.print(", ");
		System.out.print(this.getAAANEWSE());
		System.out.print(", ");

		System.out.print(this.getAADCYONM());
		System.out.print(", ");
		System.out.print(this.getAADCYCLE());
		System.out.print(", ");
		System.out.print(this.getAADSEDAI());
		System.out.print(", ");
		System.out.print(this.getAADRCVKB());
		System.out.print(", ");
		System.out.print(this.getAADZIPKB());
		System.out.print(", ");
		System.out.print(this.getAADSOUFU());
		System.out.println("");
	}


}