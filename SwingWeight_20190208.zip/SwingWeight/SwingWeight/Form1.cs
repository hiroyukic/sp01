﻿using System;
using System.Collections;
using System.Collections.Generic;
//using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SwingWeight
{






    public partial class Form1 : Form
    {

        //スタックを宣言する
        Stack stack = new System.Collections.Stack();
        
        
        //.Stack<string>();




        public Form1()
        {
            InitializeComponent();


            chart1.ChartAreas[0].AxisY.IsMarginVisible = false;  // マージンをなくす
            //chart1.ChartAreas[0].AxisY.ScaleView.Size = 5;
            chart1.ChartAreas[0].AxisY.Maximum= 400;
            chart1.ChartAreas[0].AxisY.Minimum= 250;

            chart1.ChartAreas[0].AxisX.IsMarginVisible = false;  // マージンをなくす
            chart1.ChartAreas[0].AxisX.Maximum= 34;
            chart1.ChartAreas[0].AxisX.Minimum= 28;

            PlotInit();


            // 仮入力
            textBox1.Text = "309.5";
            textBox2.Text = "31.2";

        }


        // チャート初期化
        private void PlotInit()
        {
            // 1.Seriesの追加
            chart1.Series.Clear();
            chart1.Series.Add("300");

            // 2.グラフのタイプの設定
            chart1.Series["300"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            // 3.座標の入力
            double swingWeight = 0.0;
            for (double theta = 28.0; theta <= 35.0; theta += 1.0)
            {
                swingWeight = 300;
                chart1.Series["300"].Points.AddXY(theta, swingWeight);
                //System.Diagnostics.Debug.WriteLine(theta + ", " + swingWeight);
            }
        }

        // ボタンクリック
        private void button1_Click(object sender, EventArgs e)
        {


                //.Dispose();

            //入力情報
            Double weight = 0.0;
            Double balancePoint = 0.0;
            try {
                weight = Double.Parse (textBox1.Text);
                balancePoint  = Double.Parse (textBox2.Text);
            } catch {
                return;
            }

            //振動周期（ラケット長）
            double vibrationFreq = 1.38;


            //検査条件をスタック内で重複しないかチェック

            string foo = makeStackKey(weight, balancePoint, vibrationFreq);
            if(stack.Contains(foo))
            {
                return;
            }

            //チャート初期化
            chart1.Series.Clear();


            //スタック：最新の入力情報をTopに持ってくる
            stack.Push (makeStackKey(weight, balancePoint, vibrationFreq));



            //foreachで列挙する
            foreach (String str in stack)
            {
                Console.WriteLine(str);
                string[] arr = str.Split('_');
                Console.WriteLine("{0}", string.Join(", ", arr));

                // SwingWeight演算（プロット)
                weight = Convert.ToDouble(arr[0]);
                balancePoint  = Convert.ToDouble(arr[1]);
                vibrationFreq   = Convert.ToDouble(arr[2]);
                //プロット列生成
                PlotSinCos (weight, balancePoint, vibrationFreq);
            }
            //PlotSinCos(345, 32, vibrationFreq);
            //PlotSinCos(344, 31, vibrationFreq);
        }


        private void PlotSinCos(Double weight, Double balancePoint, Double vibrationFreq)
        {
            //ラベル
            String label0 = weight.ToString();

            // 1.Seriesの追加
            //chart1.Series.Clear();

            chart1.Series.Add(label0);

            //chart1.Series.Add("sin");
            //chart1.Series.Add("cos");
            //chart1.Series.Add("cos2");

            // 2.グラフのタイプの設定
            chart1.Series[label0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            //chart1.Series["sin"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            //chart1.Series["cos"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            //chart1.Series["cos2"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            // 3.座標の入力
            //for (double theta = 0.0; theta <= 2 * Math.PI; theta += Math.PI / 360)
            //{
            //    chart1.Series["sin"].Points.AddXY(theta, Math.Sin(theta));
            //    chart1.Series["cos"].Points.AddXY(theta, Math.Cos(theta));

            //                chart1.Series["cos2"].Points.AddXY(theta, Math.Cos(theta*2));
            //           }


            //double vibrationFreq = 1.38;
            double swingWeight = 0.0;

            // 3.座標の入力  ※バランスポイント（Ｘ軸）で走査
            //for (double theta = 28.0; theta <= 35.0; theta += 1.0)
            for (double bp = 28.0; bp <= 35.0; bp += 1.0)
            {
                //chart1.Series["sin"].Points.AddXY(theta, Math.Sin(theta));
                //chart1.Series["cos"].Points.AddXY(bp, Math.Cos(bp));
                //chart1.Series["cos2"].Points.AddXY(theta, Math.Cos(theta * 2));

                //SW演算
                swingWeight = getDataSet4SwingWeight(weight / 1000, bp, vibrationFreq);

                //プロット
                chart1.Series[label0].Points.AddXY(bp, swingWeight);

                System.Diagnostics.Debug.WriteLine(balancePoint + ", " + swingWeight);


            }


            // 固有ＳＷ演算
            swingWeight = getDataSet4SwingWeight(weight / 1000, balancePoint, vibrationFreq);

            // ポイント用ラベル
            String label_sw = label0 + "_" + string.Format("{0:000.00}\r\n", swingWeight);

#if DEBUG
            System.Diagnostics.Debug.WriteLine("swingWeight=" + swingWeight);
#endif
            // Chartコントロールにデータを追加する
            //jchart1.Series.Add(label0+"_" + label_sw);
            chart1.Series.Add(label_sw);

            //chart1.Series[label0+"A"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.BoxPlot;
            //chart1.Series[label0+"A"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bubble;

            //chart1.Series[label0+"_" + label_sw].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            //chart1.Series[label0+"_" + label_sw].Points.AddXY(balancePoint , swingWeight );
            chart1.Series[label_sw].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            chart1.Series[label_sw].Points.AddXY(balancePoint , swingWeight );
        }




    // ------------------------------------------------------------------------
    // <summary>
    //     スイングウエイトの算出関数</summary>
    // <param name="weight">
    //     質量[g]</param>
    // <param name="glength">
    //     バランスポイント[cm]</param>
    // <param name="cycleTime">
    //     振動周期[sec]</param>  
    // ------------------------------------------------------------------------
        private double getDataSet4SwingWeight(Double weight, Double glength, Double cycleTime)
        {

            //Dim ds As New DataSet
            //Dim dt As New DataTable

            Double Ig1;
            Double Ig2;

            Ig1 = (weight * 980 * glength * System.Math.Pow(cycleTime, 2)) / (4 * System.Math.Pow(3.1415, 2));
            Ig2 = weight * System.Math.Pow(glength, 2);

            //'慣性モーメント　Ig = Ig1 - Ig2
            Double Ig;
            Ig = Ig1 - Ig2;

            //'慣性モーメント（軸まわり）　Io = Ig + Lg^2 * M
            Double Io;

            //'Io = Ig + ((glength - 7.5) ^ 2) * weight
            //'2019.01.14 補正　※Lafino測定値　309.5g/31.2cm/sw:285
            //Io = Ig + ((glength - 10.8) ^ 2) * weight
            Io = Ig + (System.Math.Pow((glength - 10.8), 2)) * weight;
            //System.Diagnostics.Debug.WriteLine(Io)

            return Io;

        }




        private string makeStackKey(Double weight, Double balancePoint, Double vibrationFreq)
        {
            return (weight.ToString() + "_" + balancePoint.ToString() + "_" + vibrationFreq.ToString());
        }

}
}
