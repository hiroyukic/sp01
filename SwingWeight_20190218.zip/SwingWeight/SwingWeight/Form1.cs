﻿using System;
using System.Collections;
using System.Collections.Generic;
//using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SwingWeight
{
    public partial class Form1 : Form
    {
        //キュー（FIFO)
        Queue queue = new System.Collections.Queue();

        public Form1()
        {
            InitializeComponent();

            chart1.ChartAreas[0].AxisY.IsMarginVisible = false;  // マージンをなくす
            chart1.ChartAreas[0].AxisY.Maximum = 400;
            chart1.ChartAreas[0].AxisY.Minimum = 250;
            chart1.ChartAreas[0].AxisY.Interval = 10;

            chart1.ChartAreas[0].AxisX.IsMarginVisible = false;  // マージンをなくす
            chart1.ChartAreas[0].AxisX.Maximum = 34;
            chart1.ChartAreas[0].AxisX.Minimum = 28;

            chart1.ChartAreas[0].AxisX.Title = "Balance Point  [cm]";     // X軸タイトル設定
            chart1.ChartAreas[0].AxisY.Title = "Swing Weight  [kg c㎡]"; // Y軸タイトル設定
            //chart1.ChartAreas[0].AxisY2.Title = "Swing Weight [[kg c㎡]"; // Y軸タイトル設定

            //5 毎に補助線を表示
            //chart1.ChartAreas[0].AxisY.MinorGrid.Enabled = true;  //'True に設定しないと表示しない
            //chart1.ChartAreas[0].AxisY.MinorGrid.Interval = 5;
            //chart1.ChartAreas[0].AxisY.MinorGrid.LineDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
            //chart1.ChartAreas[0].AxisY.MinorGrid.LineColor = Color.LimeGreen;

            PlotInit();

            // 仮入力
            //textBox1.Text = "309.5";
            //textBox2.Text = "31.2";

            //this.comboBox1x.SelectedIndex = 0;
            this.comboBox1.SelectedIndex = 0;
            //this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            // タブ２ (Readme)
            listBox2.Items.Add("<< 入力 >>");
            listBox2.Items.Add("  Length Type   : ラケットの長さ[cm]。ロングサイズの場合、\"Long\" を選択。");
            listBox2.Items.Add("  Weight        : ラケットの重量[g]。");
            listBox2.Items.Add("  Balance Point : グリップエンドから重心位置までの長さ[cm]。");
            listBox2.Items.Add(" ");
            listBox2.Items.Add("<< Swing Weight 概略 >>");
            listBox2.Items.Add("  Swing Weight は、ラケットの回転のし易さを表す指標です。物理的には、「慣性モーメント」がこれにあたります。");
            listBox2.Items.Add("  このツールでは、「慣性モーメント和の定理」を基に計算した y軸の各運動点のモーメントを、ポイント0点の");
            listBox2.Items.Add("  \"Swing Weight\"とみなしています。あくまでも近似計算値です。実測値とは異なります。");
            listBox2.Items.Add("  ※1 \"ポイント0点\"は、SW計測器に倣いグリップエンドから10cmの座標");
        }


        // チャート初期化
        private void PlotInit()
        {
            String initialTitle = "Swing Weight Value";
            // 1.Seriesの追加
            chart1.Series.Clear();
            chart1.Series.Add(initialTitle);

            // 2.グラフのタイプの設定
            chart1.Series[initialTitle].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            // 3.座標の入力
            double swingWeight = 0.0;
            for (double theta = 28.0; theta <= 35.0; theta += 1.0)
            {
                chart1.Series[initialTitle].Points.AddXY(theta, swingWeight);
            }
        }

        // ボタンクリック
        private void button1_Click(object sender, EventArgs e)
        {
            //入力情報　　※ラケット重量・バランス
            Double weight = 0.0;
            Double balancePoint = 0.0;
            try
            {
                weight = Double.Parse(textBox1.Text);
                balancePoint = Double.Parse(textBox2.Text);
                //表示
            }
            catch
            {
                listBox1.Items.Add("Error:入力エラー");
                return;
            }

            //振動周期（ラケット長） 
            //Normal:1.38, Long:1.40
            double vibrationFreq = 1.38;    //Normal
            if (this.comboBox1.SelectedIndex == 1)
            {
                // Long設定
                vibrationFreq = 1.40;
            }

            //検査条件をスタック内で重複しないかチェック
            string foo = makeStackKey(weight, balancePoint, vibrationFreq);
            if (queue.Contains(foo))
            {
                listBox1.Items.Add(" * Can't calculate.");
                return;
            }

            //計算パラメータ表示
            listBox1.Items.Add("-");
            listBox1.Items.Add(" Length Type = " + comboBox1.Text);
            listBox1.Items.Add(" Weight = " + weight);
            listBox1.Items.Add(" Balance Point = " + balancePoint);

            //ドット用演算
            double swingWeight = getDataSet4SwingWeight(weight / 1000, balancePoint, vibrationFreq);
            listBox1.Items.Add(" SwingWeight  = " + string.Format("{0:000.00} [kg c㎡]\r\n", swingWeight));
            if (swingWeight < 250 || swingWeight > 400)
            {
                listBox1.Items.Add(" * The SwingWeight value is out of the drawing area.");
            }
            if (balancePoint < 28 || balancePoint > 34)
            {
                listBox1.Items.Add(" * The SwingWeight value is out of the drawing area.");
            }

            //チャート初期化
            chart1.Series.Clear();

            // キュー：FIFO
            queue.Enqueue(makeStackKey(weight, balancePoint, vibrationFreq));
            chart1.Series.Clear();

            //foreachで列挙する
            foreach (String str in queue)
            {
                Console.WriteLine(str);
                string[] arr = str.Split('_');
                Console.WriteLine("{0}", string.Join(", ", arr));
                // SwingWeight演算（プロット)
                weight = Convert.ToDouble(arr[0]);
                balancePoint = Convert.ToDouble(arr[1]);
                vibrationFreq = Convert.ToDouble(arr[2]);
                //プロット列生成
                PlotSinCos(weight, balancePoint, vibrationFreq);
            }
        }


        private void PlotSinCos(Double weight, Double balancePoint, Double vibrationFreq)
        {
            // 1.Seriesの追加
            String label0 = weight.ToString() + "_" + balancePoint.ToString() + "_" + vibrationFreq;
            chart1.Series.Add(label0);

            // 2.グラフのタイプの設定
            chart1.Series[label0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            // 3.座標の入力  ※バランスポイント（Ｘ軸）で走査
            double swingWeight = 0.0;
            for (double bp = 28.0; bp <= 35.0; bp += 1.0)
            {
                //SW演算
                swingWeight = getDataSet4SwingWeight(weight / 1000, bp, vibrationFreq);
                //プロット
                chart1.Series[label0].Points.AddXY(bp, swingWeight);
                //System.Diagnostics.Debug.WriteLine(balancePoint + ", " + swingWeight);
            }

            // 引数固有ＳＷ演算
            swingWeight = getDataSet4SwingWeight(weight / 1000, balancePoint, vibrationFreq);


            String s_swingweight = string.Format("{0:000.00}\r\n", swingWeight);
            Double d_swingweight = double.Parse(s_swingweight);


            // ポイント用ラベル
            String label_sw = label0 + "_" + string.Format("{0:000.00}\r\n", swingWeight);
#if DEBUG
            System.Diagnostics.Debug.WriteLine("swingWeight=" + swingWeight);
#endif
            // Chartコントロールにデータを追加する
            chart1.Series.Add(label_sw);
            chart1.Series[label_sw].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;

            chart1.Series[label_sw].Points.AddXY(balancePoint, s_swingweight);

            //SW値表示
            chart1.Series[label_sw].IsValueShownAsLabel = true;
            chart1.Series[label_sw].LabelForeColor = Color.Red;
        }

        // ------------------------------------------------------------------------
        // <summary>
        //     スイングウエイトの算出関数</summary>
        // <param name="weight">
        //     質量[g]</param>
        // <param name="glength">
        //     バランスポイント[cm]</param>
        // <param name="cycleTime">
        //     振動周期[sec]</param>  
        // ------------------------------------------------------------------------
        private double getDataSet4SwingWeight(Double weight, Double glength, Double cycleTime)
        {
            Double Ig1;
            Double Ig2;

            Ig1 = (weight * 980 * glength * System.Math.Pow(cycleTime, 2)) / (4 * System.Math.Pow(3.1415, 2));
            Ig2 = weight * System.Math.Pow(glength, 2);

            //'慣性モーメント　Ig = Ig1 - Ig2
            Double Ig;
            Ig = Ig1 - Ig2;

            //'慣性モーメント（軸まわり）　Io = Ig + Lg^2 * M
            Double Io;

            //'Io = Ig + ((glength - 7.5) ^ 2) * weight
            //'2019.01.14 補正　※Lafino測定値　309.5g/31.2cm/sw:285
            //Io = Ig + ((glength - 10.8) ^ 2) * weight
            Io = Ig + (System.Math.Pow((glength - 10.7), 2)) * weight;
            //System.Diagnostics.Debug.WriteLine(Io)

            return Io;
        }


        private string makeStackKey(Double weight, Double balancePoint, Double vibrationFreq)
        {
            return (weight.ToString() + "_" + balancePoint.ToString() + "_" + vibrationFreq.ToString());
        }

        // ------------------------------------------------------------------------
        // <summary> 印刷プレビュー</summary>
        // ------------------------------------------------------------------------
        private void button2_Click(object sender, EventArgs e)
        {
            //印刷プレビュー
            Print Pr = new Print();
            Pr.setTitle(textBox3.Text);

            Pr.PrintForm(this);   //引数＝フォーム名
        }

        // ------------------------------------------------------------------------
        // <summary> クリア　ボタン</summary>
        // ------------------------------------------------------------------------
        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            PlotInit();
            queue.Clear();
        }

    } //Class
} //nameSpace}
