


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/InputServlet")
public class Test extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        this.doPost(req, res);
        res.setContentType("text/html; charset=UTF-8");

    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        res.setContentType("text/html; charset=UTF-8");

        // テキストボックスからデータを受け取る
        String input = req.getParameter("param");

        // 今までの入力分を取得
        String oldData = req.getParameter("oldData");
        if (null == oldData)
            oldData = "";

        String AllData = (oldData + input);

        req.setAttribute("AllData", AllData);
        req.setAttribute("input", input);
        req.setAttribute("oldData", oldData);
        RequestDispatcher dispathcer = req
                .getRequestDispatcher("Output.jsp");
//                .getRequestDispatcher("Table.jsp");
        dispathcer.forward(req, res);

    }

}