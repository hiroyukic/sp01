package jp.tuyano;

public class PersonalData {
	private String name = null;
	private String mail = null;
	private String tel = null;
	
	public PersonalData(){
		this("","","");
	}
	
	public PersonalData(String n,String m,String t){
		this.setName(n);
		this.setMail(m);
		this.setTel(t);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = this.getSanitizedString(name);
	}
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = this.getSanitizedString(mail);
	}
	
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = this.getSanitizedString(tel);
	}

	// ����������
	private String getSanitizedString(String s){
		String str = s;
		if (s == null) return null;
		str = str.replace("<","&lt;");
		str = str.replace(">","&gt;");
		str = str.replace("\"","&quot;");
		return str;
	}
}
