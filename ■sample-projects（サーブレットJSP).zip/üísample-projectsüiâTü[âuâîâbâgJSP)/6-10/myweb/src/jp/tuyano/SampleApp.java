package jp.tuyano;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SampleApp extends JFrame
		implements ActionListener {

	private static final long serialVersionUID = 1L;
	JTextArea a1,a2;

	public SampleApp() {
		setSize(400, 350);
		JPanel p = new JPanel();
		this.setLayout(new BorderLayout());
		p.setLayout(new GridLayout(2,1));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		a1 = new JTextArea();
		a2 = new JTextArea();
		JButton b1 = new JButton("ok");
		b1.addActionListener(this);
		p.add(a1);
		p.add(a2);
		this.add(p,BorderLayout.CENTER);
		this.add(b1,BorderLayout.SOUTH);
	}

	public static void main(String[] args) {
		new SampleApp().setVisible(true);
	}

	public String getSourceCode(String s){
		String src = "package jp.tuyano;\n";
		src += "import java.io.*;\n";
		src += "import javax.servlet.*;\n";
		src += "import javax.servlet.http.*;\n";
		src += "public class MyServlet extends HttpServlet {\n";
		src += "protected void doGet(HttpServletRequest request,\n";
		src += "HttpServletResponse response)\n";
		src += "throws ServletException, IOException {\n";
		src += "sendToClient(request,response);\n}\n";
		src += "protected void doPost(HttpServletRequest request,\n";
		src += "HttpServletResponse response)\n";
		src += "throws ServletException, IOException {\n";
		src += "sendToClient(request,response);\n}\n";
		src += "public void sendToClient(HttpServletRequest request,\n";
		src += "HttpServletResponse response)\n";
		src += "throws ServletException, IOException {\n";
		src += "ServletOutputStream out = response.getOutputStream();\n";
		    
		String s0 = s.replace("<%","");
		s0 = s0.replace("%>", "");
		s0 = s0.replace("<", "out.println(\"<");
		s0 = s0.replace(">", ">\");");
		
		src += s0 + "}\n}\n";
		return src;
	}

	public void actionPerformed(ActionEvent e) {
		String s = a1.getText();
		s = this.getSourceCode(s);
		a2.setText(s);
	}
}
