package jp.tuyano;

import java.text.NumberFormat;

public class ReadyData {

	public static DataObjects createData(){
		String[] names = new String[]{"T-�V���c(��)","T-�V���c(��)","Y�V���c","�X���b�N�X(��)","�C��(��)","�C��(��)"};
		int[] prices = new int[]{1700,1800,2200,3700,600,600};

		DataObjects data = new DataObjects();
		for(int i = 0;i < names.length;i++)
			data.add(names[i],prices[i]);
		return data;
	}
	
	public static int getTotal(DataObjects obs){
		int res = 0;
		if (obs != null)
			for(DataObject ob:obs)
				res += ob.getPrice();
		return res;
	}
	
	public static String getTotalString(DataObjects obs){
		int n = getTotal(obs);
		NumberFormat format = NumberFormat.getCurrencyInstance();
		return format.format(n);
	}
}
