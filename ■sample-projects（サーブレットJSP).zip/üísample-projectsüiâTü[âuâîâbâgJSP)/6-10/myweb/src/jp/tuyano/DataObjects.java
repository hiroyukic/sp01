package jp.tuyano;

import java.util.ArrayList;
import java.util.Iterator;

public class DataObjects implements Iterable<DataObject> {
	private ArrayList<DataObject> list = null;
	
	public DataObjects(){
		list = new ArrayList<DataObject>();
	}
	
	public void add(DataObject obj){
		list.add(obj);
	}
	
	public void add(String s,int n){
		this.add(new DataObject(s,n));
	}
	
	public void remove(String name){
		for (DataObject ob:list){
			if (ob.getName().equals(name)){
				list.remove(ob);
				break;
			}
		}
	}
	
	public DataObject getByName(String name){
		DataObject obj = null;
		for (DataObject ob:list){
			if (ob.getName().equals(name)){
				obj = ob;
				break;
			}
		}
		return obj;
	}
	
	public int getSize(){
		return list.size();
	}
	
	@Override
	public Iterator<DataObject> iterator() {
		return list.iterator();
	}
}

