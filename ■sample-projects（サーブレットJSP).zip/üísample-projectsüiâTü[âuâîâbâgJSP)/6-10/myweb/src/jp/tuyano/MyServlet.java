package jp.tuyano;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {
	static final long serialVersionUID = 1L;

	public MyServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("Shift_JIS");
		response.setContentType("text/html;charset=Shift_JIS");
		PrintWriter out = response.getWriter();
		out.println("<html><body>�����̃y�[�W�ɂ͒��ڃA�N�Z�X�ł��܂���B</body></html>");
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("Shift_JIS");
		response.setContentType("text/html;charset=Shift_JIS");
		this.checkData(request);
		
		HttpSession  session = request.getSession();
		ServletContext context = this.getServletContext();
		String[] arr = request.getParameterValues("sel");
		DataObjects mydata = (DataObjects)session.getAttribute("data");
		DataObjects appdata = (DataObjects)context.getAttribute("data");
		for(String s:arr){
			DataObject ob = appdata.getByName(s);
			if (ob != null) mydata.add(ob);
		}
		session.setAttribute("data", mydata);
		RequestDispatcher dispatcher = context.getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
	}
		
	public void checkData(HttpServletRequest request){
		HttpSession session = request.getSession();
		ServletContext context = this.getServletContext();
		if (session.getAttribute("data") == null)
			session.setAttribute("data", new DataObjects());
		if (context.getAttribute("data") == null)
			context.setAttribute("data", ReadyData.createData());
	}
	
	// ����������
	private String getSanitizedString(String s){
		String str = s;
		if (s == null) return null;
		str = str.replace("<","&lt;");
		str = str.replace(">","&gt;");
		str = str.replace("\"","&quot;");
		return str;
	}
}
