package jp.tuyano;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String filepath = "data.txt";
	private static final int _ID = 0;
	private static final int _NAME = 1;
	private static final int _COMMENT = 2;
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		// ����͉����s��Ȃ�
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("Shift_JIS");
		response.setContentType("text/html;charset=Shift_JIS");
		String path = this.getServletContext().getRealPath(filepath);
		
		ServletInputStream input = null;
		InputStreamReader reader = null;
		BufferedReader breader = null;
		ServletOutputStream output = null;
		OutputStreamWriter writer = null;
		BufferedWriter bwriter = null;
		
		input = request.getInputStream();
		reader = new InputStreamReader(input);
		breader = new BufferedReader(reader);
		String id = breader.readLine().trim();
		
		String[] finddata = getIDData(id,getAllData(path));
		String result = "";
		if (finddata != null)
			result = finddata[_ID] + ", " + finddata[_NAME] + ", " + finddata[_COMMENT];
		
		output = response.getOutputStream();
		writer = new OutputStreamWriter(output);
		bwriter = new BufferedWriter(writer);
		bwriter.write(result);
		bwriter.flush();
		
		breader.close();
		bwriter.close();
	}
	
	public ArrayList<String[]> getAllData(String path){
		ArrayList<String[]> result = new ArrayList<String[]>();
		FileReader reader = null;
		BufferedReader breader = null;
		try {
			reader = new FileReader(path);
			breader = new BufferedReader(reader);
			String tmp = null;
			while((tmp = breader.readLine()) != null){
				result.add(tmp.split("\t"));
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				breader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public String[] getIDData(String id,ArrayList<String[]> list){
		String[] result = null;
		for (String[] tmp:list){
			if (tmp[0].equals(id)) result = tmp;
		}
		return result;
	}
}
