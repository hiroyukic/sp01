package jp.tuyano;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.*;

public class LoginFilter implements Filter {
	private String valname = null;
	private String errorURL = null;
	
	@Override
	public void init(FilterConfig conf)
			throws ServletException {
		valname = conf.getInitParameter("login");
		errorURL = conf.getInitParameter("errorURL");
	}
	
	@Override
	public void doFilter(ServletRequest request,
			ServletResponse response,
			FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest hrequest = (HttpServletRequest)request;
		HttpSession session = hrequest.getSession();
		String login = (String)session.getAttribute(valname);
		if (login == null){
			RequestDispatcher dispacher = request.getRequestDispatcher(errorURL);
			dispacher.forward(request,response);
		}
		chain.doFilter(request, response);
	}
	
	@Override
	public void destroy() {}
}
