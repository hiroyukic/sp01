package jp.tuyano;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class LoginTag extends SimpleTagSupport {
	private String redirect = "./login.jsp";
	private String text_color = "#FF0000";
	private String bg_color = "#FFAAAA";

	
	public String getRedirect() {
		return redirect;
	}
	public void setRedirect(String redirect) {
		this.redirect = redirect;
	}
	public String getText_color() {
		return text_color;
	}
	public void setText_color(String text_color) {
		this.text_color = text_color;
	}
	public String getBg_color() {
		return bg_color;
	}
	public void setBg_color(String bg_color) {
		this.bg_color = bg_color;
	}

	@Override
	public void doTag() throws JspException, IOException {
		super.doTag();
		PageContext application = (PageContext)this.getJspContext();
		HttpServletRequest request = (HttpServletRequest)application.getRequest();
		HttpSession session = application.getSession();
		JspWriter out = application.getOut();
		
		String login = (String)session.getAttribute("login");
		if (login != null){
			out.println("<div style=\"color:" + this.getText_color() + ";background-color:" + this.getBg_color() + ";\">");
			out.println("[LOGIN: " + login + "]");
			out.println("</div>");
		} else {
			try {
				application.forward(this.getRedirect());
			} catch (ServletException e) {
				e.printStackTrace();
				out.println(e.getMessage());
			}
		}
	}

}
