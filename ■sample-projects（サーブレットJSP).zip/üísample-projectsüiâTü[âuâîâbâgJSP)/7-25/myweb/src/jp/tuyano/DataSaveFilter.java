package jp.tuyano;

import java.io.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;

public class DataSaveFilter implements Filter {
	private ServletContext context = null;
	
	@Override
	public void init(FilterConfig fconf)
			throws ServletException {
		context = fconf.getServletContext();
	}

	@Override
	public void doFilter(ServletRequest request,
			ServletResponse response,
			FilterChain chain)
			throws IOException, ServletException {
		String path = context.getRealPath("./WEB-INF/log.txt");
		FileWriter writer = null;
		BufferedWriter bwriter = null;
		writer = new FileWriter(path,true);
		bwriter = new BufferedWriter(writer);
		GregorianCalendar cal = new GregorianCalendar();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String data = format.format(cal.getTime());
		data += "  " + request.getRemoteAddr() + "\n";
		bwriter.write(data);
		bwriter.flush();
		bwriter.close();
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		// �����ł͓��ɉ������Ȃ�
	}
}
