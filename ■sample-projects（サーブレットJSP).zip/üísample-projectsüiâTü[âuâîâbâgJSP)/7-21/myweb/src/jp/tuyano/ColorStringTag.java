package jp.tuyano;

import java.io.IOException;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class ColorStringTag extends BodyTagSupport {
	private static final long serialVersionUID = 1L;
	private String style = "";
	private String RGB = "r";

	@Override
	public int doStartTag() throws JspException {
		PageContext context = this.pageContext;
		JspWriter out = context.getOut();
		try {
			out.print("<span style=\"" + this.getStyle() + "\">");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return BodyTagSupport.EVAL_BODY_BUFFERED;
	}

	@Override
	public void doInitBody() throws JspException {
		super.doInitBody();
	}

	@Override
	public int doAfterBody() throws JspException {
		try {
			BodyContent bodyContent = this.getBodyContent();
			JspWriter out = bodyContent.getEnclosingWriter();
			String s = bodyContent.getString();
			bodyContent.clearBody();
			int rgb = 0;
			rgb = this.getRGB().equals("r") ? 0 : rgb;
			rgb = this.getRGB().equals("g") ? 1 : rgb;
			rgb = this.getRGB().equals("b") ? 2 : rgb;
			String[] arr = new String[]{"FF","FF","FF"};
			String[] data = new String[]{"00","11","22","33","44","55","66","77","88","99","AA","BB","CC","DD","EE"};
			double d = (double)data.length / (double)(s.length());
			for(int i = 0;i < s.length();i++){
				int n = (int)(i * d);
				arr[0] = data[n];
				arr[1] = data[n];
				arr[2] = data[n];
				arr[rgb] = "FF";
				String rgbstr = arr[0] + arr[1] + arr[2];
				bodyContent.print("<span style=\"color:#" + rgbstr + ";\">");
				bodyContent.print(s.charAt(i));
				bodyContent.print("</span>");
			}
			bodyContent.writeOut(out);
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return BodyTagSupport.SKIP_BODY;
	}

	@Override
	public int doEndTag() throws JspException {
		PageContext context = this.pageContext;
		JspWriter out = context.getOut();
		try {
			out.print("</span>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return BodyTagSupport.EVAL_PAGE;
	}

	public String getStyle() {
		return this.style;
	}

	public void setStyle(String str) {
		this.style = str;
	}

	public String getRGB() {
		return this.RGB;
	}

	public void setRGB(String rgb) {
		this.RGB = rgb.toLowerCase();
	}
}
