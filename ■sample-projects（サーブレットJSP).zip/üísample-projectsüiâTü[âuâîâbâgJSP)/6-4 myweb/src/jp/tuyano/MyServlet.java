package jp.tuyano;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {
	static final long serialVersionUID = 1L;

	public MyServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("Shift_JIS");
		response.setContentType("text/html;charset=Shift_JIS");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("������́AGET�̕\���ł��B");
		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("Shift_JIS");
		response.setContentType("text/html;charset=Shift_JIS");
		String s = request.getParameter("text1");
		s = this.getSanitizedString(s);
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("��POST�������F" + s);
		out.println("</body></html>");
	}
	
	// ����������
	private String getSanitizedString(String s){
		String str = s;
		if (s == null) return null;
		str = str.replace("<","&lt;");
		str = str.replace(">","&gt;");
		str = str.replace("\"","&quot;");
		return str;
	}
}
