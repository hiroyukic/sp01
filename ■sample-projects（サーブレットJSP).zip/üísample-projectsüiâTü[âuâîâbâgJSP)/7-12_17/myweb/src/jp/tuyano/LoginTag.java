package jp.tuyano;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class LoginTag extends SimpleTagSupport {

	@Override
	public void doTag() throws JspException, IOException {
		super.doTag();
		PageContext application = (PageContext)this.getJspContext();
		HttpServletRequest request = (HttpServletRequest)application.getRequest();
		HttpSession session = application.getSession();
		JspWriter out = application.getOut();
		String login = (String)session.getAttribute("login");
		if (login != null){
			out.println("<div style=\"color:#FF0000;background-color:#FFCCCC;\">");
			out.println("[LOGIN: " + login + "]");
			out.println("</div>");
		} else {
			try {
				application.forward("login.jsp");
			} catch (ServletException e) {
				e.printStackTrace();
				out.println(e.getMessage());
			}
		}
	}
}
