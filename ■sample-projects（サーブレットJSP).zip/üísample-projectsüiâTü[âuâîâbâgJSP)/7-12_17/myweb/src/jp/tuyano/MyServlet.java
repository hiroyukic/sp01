package jp.tuyano;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		// ����͉����s��Ȃ�
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("Shift_JIS");
		response.setContentType("text/html;charset=Shift_JIS");
		String id = request.getParameter("id");
		HttpSession session = request.getSession();
		session.setAttribute("login",this.getSanitizedString(id));
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatch = request.getRequestDispatcher("./index.jsp");
		dispatch.forward(request,response);
	}
	
	// ����������
	private String getSanitizedString(String s){
		String str = s;
		if (s == null) return null;
		str = str.replace("<","&lt;");
		str = str.replace(">","&gt;");
		str = str.replace("\"","&quot;");
		return str;
	}
}
